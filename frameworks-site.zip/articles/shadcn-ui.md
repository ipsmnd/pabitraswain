# shadcn/ui

> Copy-and-own components built on Radix UI and Tailwind CSS.

| Field | Detail |
|---|---|
| Type | component collection |
| Category | CSS frameworks and UI libraries |
| Best for | fully customizable components |
| Official site | [ui.shadcn.com](https://ui.shadcn.com) |

## Overview

shadcn/ui is not a normal npm library. It is a collection of beautifully designed components (built on Radix UI and Tailwind CSS) that a CLI copies directly into your project. You own the code, so you can change anything.

## Key features

- **Copy-and-own** — components live in your repo.
- **Built on Radix UI** primitives for accessibility.
- **Tailwind CSS** styling — easy to restyle.
- **CLI** — `npx shadcn add button`.
- **Blocks and charts** ready to paste.

## Quick start

```bash
npx shadcn@latest init
npx shadcn@latest add button card
```

## Example

```tsx
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function Service() {
  return (
    <Card>
      <CardHeader><CardTitle>Web Design</CardTitle></CardHeader>
      <CardContent><Button>Learn more</Button></CardContent>
    </Card>
  );
}
```

## When to choose it

- You want full control over component code and design.
- You use React with Tailwind CSS (Next.js, Vite).

## Think twice if

- You want updates delivered automatically through npm.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ui.shadcn.com).*
