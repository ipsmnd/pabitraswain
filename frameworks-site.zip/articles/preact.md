# Preact

> A roughly 3 KB, React-compatible alternative.

| Field | Detail |
|---|---|
| Type | UI library |
| Category | Popular frontend frameworks |
| Best for | React APIs at tiny size |
| Official site | [preactjs.com](https://preactjs.com) |

## Overview

Preact is a fast, roughly 3 KB alternative to React with the same modern API. With the `preact/compat` layer, many React libraries work unchanged. It is popular for widgets, embedded apps and sites where every kilobyte counts.

## Key features

- **Tiny size** — about 3 KB gzipped.
- **React-compatible API** — hooks, components and JSX.
- **preact/compat** — run many React packages as they are.
- **Preact Signals** — optional fine-grained reactive state.

## Quick start

```bash
npm init preact
cd my-app
npm run dev
```

## Example

```jsx
import { useState } from 'preact/hooks';

export function Counter() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount(count + 1)}>
      Clicked {count} times
    </button>
  );
}
```

## When to choose it

- You want React skills with a much smaller bundle.
- You are building an embeddable widget for other people's websites.

## Think twice if

- You depend on newest React-only features such as Server Components.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://preactjs.com).*
