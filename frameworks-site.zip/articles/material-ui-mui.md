# Material UI (MUI)

> React components implementing Material Design.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | polished React dashboards |
| Official site | [mui.com](https://mui.com) |

## Overview

Material UI (MUI) is a large React component library that implements Google's Material Design. It is widely used for dashboards and business apps, and MUI X adds advanced components like data grids, date pickers and charts.

## Key features

- **Comprehensive components** — buttons, dialogs, tables, menus.
- **Theming** with `createTheme`.
- **`sx` prop** for one-off styles.
- **MUI X** — Data Grid, Date Pickers, Charts.

## Quick start

```bash
npm install @mui/material @emotion/react @emotion/styled
```

## Example

```jsx
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';

export default function Service() {
  return (
    <Card sx={{ maxWidth: 320 }}>
      <CardContent>Web Design</CardContent>
      <Button variant="contained">Learn more</Button>
    </Card>
  );
}
```

## When to choose it

- You build polished React dashboards or admin panels.
- You like the Material Design look.

## Think twice if

- You want a non-Material, highly custom brand look with little effort.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mui.com).*
