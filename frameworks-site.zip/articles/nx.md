# Nx

> Monorepo build system with caching and code generation.

| Field | Detail |
|---|---|
| Type | build system |
| Category | Angular ecosystem |
| Best for | large multi-project workspaces |
| Official site | [nx.dev](https://nx.dev) |

## Overview

Nx is a build system and monorepo tool. It understands how projects in one repository depend on each other, caches build and test results, and runs only what a change affects. It supports Angular, React, Vue, Node and more, with code generators for each.

## Key features

- **Smart caching** — never rebuild the same thing twice (local or remote).
- **Affected commands** — test only projects your change touches.
- **Project graph** — visualise dependencies.
- **Generators and plugins** for many frameworks.

## Quick start

```bash
npx create-nx-workspace@latest my-workspace
```

## Example

```bash
# run the dev server of one app
nx serve shop

# test only what changed
nx affected -t test

# see the dependency graph in your browser
nx graph
```

## When to choose it

- You have many apps and libraries in one repository.
- CI builds are getting slow.

## Think twice if

- You have a single small project — the setup is overkill.

## Related

- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [AnalogJS](#analogjs) — Vite-powered meta-framework for Angular with file-based routing and SSR.
- [Ionic](#ionic) — Cross-platform UI toolkit for hybrid mobile and PWA apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nx.dev).*
