# Gatsby

> React static-site generator built around a GraphQL data layer.

| Field | Detail |
|---|---|
| Type | static site generator |
| Category | React-based frameworks |
| Best for | content sites with many data sources |
| Official site | [gatsbyjs.com](https://www.gatsbyjs.com) |

## Overview

Gatsby is a React-based static-site generator. It pulls content from Markdown, CMSs and APIs into a single GraphQL data layer, then builds fast static pages with image optimisation and a large plugin library.

> **Status note:** Development has slowed a lot since Netlify acquired Gatsby in 2023.

## Key features

- **GraphQL data layer** — query any data source the same way.
- **Plugin ecosystem** — sources, images, SEO, PWA.
- **Static output** — fast and easy to host on a CDN.

## Quick start

```bash
npm init gatsby
cd my-site
npm run develop
```

## Example

```jsx
import { graphql } from 'gatsby';

export default function Blog({ data }) {
  return data.allMarkdownRemark.nodes.map(n => <h2 key={n.id}>{n.frontmatter.title}</h2>);
}

export const query = graphql`
  query { allMarkdownRemark { nodes { id frontmatter { title } } } }
`;
```

## When to choose it

- You maintain an existing Gatsby site.
- You need to combine many content sources into one static site.

## Think twice if

- You are starting fresh — Next.js or Astro are more actively developed today.

## Related

- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.
- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.
- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.
- [React Router](#react-router) — The standard React router, with a framework mode since v7.
- [Expo](#expo) — Toolchain and platform for building React Native apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.gatsbyjs.com).*
