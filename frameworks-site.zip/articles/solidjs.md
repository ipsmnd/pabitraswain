# SolidJS

> Fine-grained reactivity with JSX and no virtual DOM.

| Field | Detail |
|---|---|
| Type | UI library |
| Category | Popular frontend frameworks |
| Best for | top-tier runtime performance |
| Official site | [solidjs.com](https://www.solidjs.com) |

## Overview

SolidJS looks like React — JSX and familiar function components — but works very differently underneath. Components run only once, and fine-grained *signals* update exactly the DOM nodes that depend on them, with no virtual DOM. This makes Solid one of the fastest UI libraries in benchmarks.

## Key features

- **Signals** — `createSignal` and `createMemo` drive precise updates.
- **No virtual DOM** — direct, surgical DOM updates.
- **JSX** — easy move for React developers.
- **SolidStart** — official meta-framework for routing and SSR.

## Quick start

```bash
npm create solid@latest
cd my-app
npm install
npm run dev
```

## Example

```jsx
import { createSignal } from 'solid-js';

function Counter() {
  const [count, setCount] = createSignal(0);
  return (
    <button onClick={() => setCount(count() + 1)}>
      Clicked {count()} times
    </button>
  );
}
```

## When to choose it

- Runtime performance is a top priority.
- You like JSX but want simpler, more predictable reactivity.

## Think twice if

- You rely on React-only libraries — they will not work directly.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.solidjs.com).*
