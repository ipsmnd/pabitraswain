# Bulma

> Flexbox-based, CSS-only framework with no JavaScript.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | simple, readable styling |
| Official site | [bulma.io](https://bulma.io) |

## Overview

Bulma is a modern CSS-only framework based on Flexbox. It has no JavaScript at all, readable class names like `button is-primary`, and a simple column system.

## Key features

- **CSS only** — no JavaScript dependencies.
- **Flexbox columns** — `columns` and `column`.
- **Readable modifiers** — `is-primary`, `is-large`.
- **CSS variables** for theming (v1).

## Quick start

```bash
npm install bulma
```

## Example

```html
<div class="columns">
  <div class="column">
    <div class="box">
      <h3 class="title is-4">Web Design</h3>
      <button class="button is-primary">Learn more</button>
    </div>
  </div>
</div>
```

## When to choose it

- You want simple, readable styling with no JavaScript.

## Think twice if

- You need interactive components like modals and dropdowns ready to use.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://bulma.io).*
