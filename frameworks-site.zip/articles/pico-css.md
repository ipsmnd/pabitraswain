# Pico CSS

> Minimal framework that styles semantic HTML with few classes.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | clean pages with almost no CSS |
| Official site | [picocss.com](https://picocss.com) |

## Overview

Pico CSS is a minimal framework that styles plain, semantic HTML. Write normal `<nav>`, `<article>`, `<form>` and `<button>` tags and they look good automatically — with almost no classes and built-in light/dark mode.

## Key features

- **Class-light** — semantic HTML is styled directly.
- **Automatic dark mode**.
- **Responsive typography and spacing**.
- **Small** — one CSS file.

## Quick start

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
```

## Example

```html
<main class="container">
  <article>
    <h2>Contact</h2>
    <form>
      <input type="email" placeholder="Email">
      <button type="submit">Send</button>
    </form>
  </article>
</main>
```

## When to choose it

- You want clean pages, docs or prototypes with almost no CSS.

## Think twice if

- You need a large set of complex components.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://picocss.com).*
