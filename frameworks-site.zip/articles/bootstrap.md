# Bootstrap

> Popular responsive grid and component framework.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | fast, consistent layouts |
| Official site | [getbootstrap.com](https://getbootstrap.com) |

## Overview

Bootstrap is the world's most popular CSS framework. It gives you a responsive 12-column grid, ready-made components (navbars, cards, modals, forms) and utility classes, so you can build a clean, consistent layout very quickly.

## Key features

- **Responsive grid** — `container`, `row` and `col-*` classes.
- **Components** — buttons, navbars, modals, carousels and more.
- **Utilities** for spacing, colours and flexbox.
- **Sass variables and CSS variables** for theming, including dark mode.

## Quick start

```bash
npm install bootstrap

# or use the CDN:
# <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
```

## Example

```html
<div class="container">
  <div class="row g-3">
    <div class="col-md-6">
      <div class="card p-3">
        <h5 class="card-title">Web Design</h5>
        <a href="#" class="btn btn-primary">Learn more</a>
      </div>
    </div>
  </div>
</div>
```

## When to choose it

- You want professional-looking pages fast.
- You are building admin panels, business sites or prototypes.

## Think twice if

- You want a very unique design — Bootstrap sites can look alike unless customised.

## Related

- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://getbootstrap.com).*
