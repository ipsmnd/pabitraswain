# Turbopack

> Rust-based incremental bundler built for Next.js.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | large Next.js apps |
| Official site | [nextjs.org/docs/app/api-reference/turbopack](https://nextjs.org/docs/app/api-reference/turbopack) |

## Overview

Turbopack is an incremental bundler written in Rust and built into Next.js by Vercel. It only recomputes what changed, which keeps dev servers and builds fast in very large apps. It is now the default bundler in recent Next.js versions.

## Key features

- **Incremental computation** — work is cached at function level.
- **Fast HMR** in large codebases.
- **Built into Next.js** — no separate install.

## Quick start

```bash
npx create-next-app@latest my-app
# Turbopack is used by default in recent Next.js versions.
# On older versions:  next dev --turbopack
```

## Example

```json
// package.json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build"
  }
}
```

## When to choose it

- You build large Next.js applications.

## Think twice if

- You are not using Next.js — it is not a general standalone bundler for other projects.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Parcel](#parcel) — Zero-configuration bundler.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nextjs.org/docs/app/api-reference/turbopack).*
