# Vue.js

> Progressive framework with approachable templates and reactivity.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | a gentle learning curve |
| Official site | [vuejs.org](https://vuejs.org) |

## Overview

Vue is a progressive framework: you can drop it into one page or build a full single-page app with it. Single-File Components keep template, logic and styles together, and its reactivity system tracks changes automatically. Many developers find Vue the easiest of the big frameworks to learn.

## Key features

- **Single-File Components** — `.vue` files hold template, script and style in one place.
- **Composition API and Options API** — choose the style that suits your team.
- **Automatic reactivity** — `ref()` and `reactive()` update the DOM when values change.
- **Official tools** — Vue Router, Pinia for state, and Vite for builds.

## Quick start

```bash
npm create vue@latest
cd my-app
npm install
npm run dev
```

## Example

```vue
<script setup>
import { ref } from 'vue'
const count = ref(0)
</script>

<template>
  <button @click="count++">Clicked {{ count }} times</button>
</template>
```

## When to choose it

- You want a gentle learning curve with HTML-like templates.
- You want to add interactivity to an existing site step by step.

## Think twice if

- Your team already has deep React experience and a React component library.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vuejs.org).*
