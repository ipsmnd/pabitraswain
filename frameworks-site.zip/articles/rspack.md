# Rspack

> Rust-based, webpack-compatible bundler.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | faster builds without rewriting webpack config |
| Official site | [rspack.rs](https://rspack.rs) |

## Overview

Rspack is a Rust-based bundler from ByteDance that is compatible with most webpack configuration and loaders. It lets teams get much faster builds without rewriting their webpack setup. Rsbuild is its easy, batteries-included layer.

## Key features

- **webpack-compatible** config and most loaders/plugins.
- **Much faster builds** thanks to Rust.
- **Rsbuild** — simple zero-config layer on top.
- **Module Federation** support.

## Quick start

```bash
npm create rspack@latest
```

## Example

```js
// rspack.config.js — looks just like webpack
module.exports = {
  entry: './src/index.js',
  module: {
    rules: [{ test: /\.css$/, type: 'css' }],
  },
};
```

## When to choose it

- You have a slow webpack project and want speed without a rewrite.

## Think twice if

- You are starting fresh with no webpack history — Vite may be simpler.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Parcel](#parcel) — Zero-configuration bundler.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://rspack.rs).*
