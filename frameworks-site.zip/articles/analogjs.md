# AnalogJS

> Vite-powered meta-framework for Angular with file-based routing and SSR.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | Angular ecosystem |
| Best for | full-stack Angular apps |
| Official site | [analogjs.org](https://analogjs.org) |

## Overview

Analog is a full-stack meta-framework for Angular, built on Vite. It brings file-based routing, server-side rendering, static generation, API routes and Markdown content to Angular — similar to what Next.js does for React.

## Key features

- **File-based routing** with `.page.ts` files.
- **SSR and SSG** out of the box.
- **API routes** powered by Nitro.
- **Vite-powered** dev server and builds.
- **Markdown content** routes for blogs.

## Quick start

```bash
npm create analog@latest my-app
cd my-app
npm start
```

## Example

```ts
// src/app/pages/index.page.ts
import { Component } from '@angular/core';

@Component({
  standalone: true,
  template: `<h1>Hello from Analog</h1>`,
})
export default class HomePage {}
```

## When to choose it

- You know Angular and want Next.js-style routing and SSR.
- You want Vite speed in an Angular project.

## Think twice if

- Your enterprise prefers only official Angular tooling.

## Related

- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Nx](#nx) — Monorepo build system with caching and code generation.
- [Ionic](#ionic) — Cross-platform UI toolkit for hybrid mobile and PWA apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://analogjs.org).*
