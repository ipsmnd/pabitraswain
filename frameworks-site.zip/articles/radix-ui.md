# Radix UI

> Unstyled, accessible React primitives.

| Field | Detail |
|---|---|
| Type | primitives |
| Category | CSS frameworks and UI libraries |
| Best for | building your own design system |
| Official site | [radix-ui.com](https://www.radix-ui.com) |

## Overview

Radix UI Primitives are unstyled, accessible React components — dialogs, dropdowns, tabs, tooltips and more. They handle keyboard navigation, focus and ARIA for you, while you add any styling you like. Many design systems, including shadcn/ui, are built on them.

## Key features

- **Unstyled** — bring your own CSS or Tailwind.
- **Accessibility handled** — focus, keyboard, ARIA.
- **Composable parts** like `Dialog.Trigger` and `Dialog.Content`.
- **Radix Themes** — optional styled layer.

## Quick start

```bash
npm install radix-ui
```

## Example

```jsx
import { Dialog } from 'radix-ui';

export default function Contact() {
  return (
    <Dialog.Root>
      <Dialog.Trigger>Contact me</Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="overlay" />
        <Dialog.Content className="modal">
          <Dialog.Title>Let's work together</Dialog.Title>
          <Dialog.Close>Close</Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
```

## When to choose it

- You are building your own design system in React.

## Think twice if

- You want pre-styled components — try shadcn/ui or Mantine.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.radix-ui.com).*
