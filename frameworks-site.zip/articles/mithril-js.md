# Mithril.js

> Tiny SPA framework with routing and XHR built in.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | minimal, fast single-page apps |
| Official site | [mithril.js.org](https://mithril.js.org) |

## Overview

Mithril is a tiny client-side framework (around 10 KB) that still includes routing and an HTTP request utility. Its API is small enough to learn in an afternoon, and it uses a fast virtual DOM.

## Key features

- **Small and complete** — virtual DOM, router and XHR in one package.
- **Hyperscript** — `m('div', ...)` or optional JSX.
- **Automatic redraws** after events and requests.

## Quick start

```bash
npm install mithril
```

## Example

```js
import m from 'mithril';

let count = 0;
const Counter = {
  view: () => m('button', { onclick: () => count++ },
    `Clicked ${count} times`)
};

m.mount(document.body, Counter);
```

## When to choose it

- You want a full SPA toolkit with a very small footprint.
- You prefer plain JavaScript over a big framework.

## Think twice if

- You need lots of community component libraries.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mithril.js.org).*
