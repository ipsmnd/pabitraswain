# Marko

> HTML-based language with streaming server rendering.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | content-heavy, fast-loading sites |
| Official site | [markojs.com](https://markojs.com) |

## Overview

Marko is an HTML-based UI language created at eBay. It streams HTML from the server as soon as parts are ready and sends only the JavaScript needed for interactive parts. Marko 6 introduced a simpler *Tags API*.

## Key features

- **HTML-first syntax** — templates look like enhanced HTML.
- **Streaming SSR** — users see content sooner.
- **Partial hydration** — only interactive parts ship JavaScript.
- **Proven at scale** — powers eBay.

## Quick start

```bash
npm init marko
cd my-app
npm run dev
```

## Example

```html
<let/count=0>

<button onClick() { count++ }>
  Clicked ${count} times
</button>
```

## When to choose it

- You build content-heavy, high-traffic sites where load speed matters.
- You like writing templates that look like HTML.

## Think twice if

- You need a large hiring pool or many ready-made UI kits.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://markojs.com).*
