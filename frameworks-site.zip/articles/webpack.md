# Webpack

> Highly configurable module bundler with a vast plugin ecosystem.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | complex or legacy builds |
| Official site | [webpack.js.org](https://webpack.js.org) |

## Overview

webpack is the long-established module bundler behind many existing apps. It turns JavaScript, CSS, images and more into optimised bundles using *loaders* and *plugins*, and is extremely configurable.

## Key features

- **Loaders** — handle CSS, images, TypeScript, etc.
- **Plugins** — huge ecosystem for every need.
- **Code splitting and lazy loading**.
- **Module Federation** — share code between separate apps.

## Quick start

```bash
npm install -D webpack webpack-cli
```

## Example

```js
// webpack.config.js
module.exports = {
  entry: './src/index.js',
  output: { filename: 'bundle.js', path: __dirname + '/dist' },
  module: {
    rules: [{ test: /\.css$/, use: ['style-loader', 'css-loader'] }],
  },
};
```

## When to choose it

- You maintain a webpack project or need Module Federation.
- You need very fine control over the build.

## Think twice if

- You are starting fresh — Vite is simpler and faster.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Parcel](#parcel) — Zero-configuration bundler.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://webpack.js.org).*
