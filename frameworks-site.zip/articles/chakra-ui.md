# Chakra UI

> Accessible, themeable React component library.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | accessible React interfaces |
| Official site | [chakra-ui.com](https://chakra-ui.com) |

## Overview

Chakra UI is an accessible, themeable component library for React. Components accept style props (like `p="4"` or `color="teal.500"`), and a token-based theme system makes consistent design and dark mode easy.

## Key features

- **Accessible by default** (WAI-ARIA).
- **Style props** directly on components.
- **Theme tokens** and colour palettes.
- **Dark mode** support.

## Quick start

```bash
npm install @chakra-ui/react @emotion/react
```

## Example

```jsx
import { ChakraProvider, defaultSystem, Button, Box } from '@chakra-ui/react';

export default function App() {
  return (
    <ChakraProvider value={defaultSystem}>
      <Box p="6" borderRadius="xl" bg="gray.900">
        <Button colorPalette="teal">Save</Button>
      </Box>
    </ChakraProvider>
  );
}
```

## When to choose it

- You want accessible React components with quick styling.

## Think twice if

- You are not using React.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://chakra-ui.com).*
