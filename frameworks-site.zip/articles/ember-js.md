# Ember.js

> Convention-over-configuration framework for ambitious web apps.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | long-lived, stable products |
| Official site | [emberjs.com](https://emberjs.com) |

## Overview

Ember is a convention-over-configuration framework for ambitious web apps. It provides a full stack of tools — router, data layer, testing and a CLI — and follows a strict release cycle with long-term-support versions, so apps can stay healthy for many years.

## Key features

- **Ember CLI** — generators, builds and testing out of the box.
- **Strong conventions** — every Ember app has a familiar structure.
- **Glimmer components** with `@tracked` state.
- **LTS releases** — predictable, stable upgrades.

## Quick start

```bash
npx ember-cli new my-app
cd my-app
npm start
```

## Example

```js
import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { on } from '@ember/modifier';

export default class Counter extends Component {
  @tracked count = 0;
  increment = () => this.count++;

  <template>
    <button {{on "click" this.increment}}>Clicked {{this.count}} times</button>
  </template>
}
```

## When to choose it

- You value stability and clear conventions over flexibility.
- You maintain a large app that must live for many years.

## Think twice if

- You are learning your first framework — the job market is smaller.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://emberjs.com).*
