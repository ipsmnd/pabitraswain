# Quasar

> Vue framework for web, mobile and desktop apps from one codebase.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Vue-based frameworks |
| Best for | one team, many platforms |
| Official site | [quasar.dev](https://quasar.dev) |

## Overview

Quasar is a Vue framework with a large Material-style component library and a CLI that builds the same code as an SPA, SSR site, PWA, mobile app (Capacitor/Cordova), desktop app (Electron) or browser extension.

## Key features

- **70+ components** — tables, forms, dialogs, layouts.
- **One codebase, many targets** — web, mobile, desktop.
- **Quasar CLI** with build modes.
- **Built-in theming and RTL support**.

## Quick start

```bash
npm init quasar
cd my-app
quasar dev
```

## Example

```vue
<template>
  <q-page padding>
    <q-input v-model="name" label="Your name" />
    <q-btn color="primary" label="Save" @click="save" />
  </q-page>
</template>
```

## When to choose it

- One small team must ship web, mobile and desktop.
- You want a big ready-made component set for Vue.

## Think twice if

- You want a very custom, non-Material look.

## Related

- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.
- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.
- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.
- [VuePress](#vuepress) — The original Vue-powered documentation generator.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://quasar.dev).*
