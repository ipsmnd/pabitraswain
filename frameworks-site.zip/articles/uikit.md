# UIKit

> Modular front-end framework from YOOtheme.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | lightweight modular UI |
| Official site | [getuikit.com](https://getuikit.com) |

## Overview

UIkit, from YOOtheme, is a lightweight, modular front-end framework. It provides a grid, many components and JavaScript behaviours controlled through simple HTML attributes like `uk-grid` and `uk-modal`.

## Key features

- **Modular** — use only the parts you need.
- **Attribute-driven JavaScript** — `uk-slider`, `uk-modal`, `uk-scrollspy`.
- **Less/Sass theming**.
- **Animations and sliders** built in.

## Quick start

```bash
npm install uikit
```

## Example

```html
<div class="uk-child-width-1-2@m" uk-grid>
  <div><div class="uk-card uk-card-default uk-card-body">Web Design</div></div>
  <div><div class="uk-card uk-card-primary uk-card-body">UI/UX</div></div>
</div>
<button class="uk-button uk-button-primary">Learn more</button>
```

## When to choose it

- You want modular UI with built-in sliders and animations.
- You build WordPress/Joomla themes (popular with YOOtheme).

## Think twice if

- You prefer utility-first styling.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://getuikit.com).*
