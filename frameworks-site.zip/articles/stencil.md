# Stencil

> Compiler that generates web components, from the Ionic team.

| Field | Detail |
|---|---|
| Type | compiler |
| Category | Popular frontend frameworks |
| Best for | design systems shipped as web components |
| Official site | [stenciljs.com](https://stenciljs.com) |

## Overview

Stencil is a compiler from the Ionic team that turns TypeScript and JSX components into standard Web Components. It adds lazy loading and framework wrappers, which makes it popular for company design systems that must work in React, Angular and Vue at the same time.

## Key features

- **Outputs standard Web Components**.
- **TypeScript + JSX** authoring with decorators.
- **Lazy loading** of components.
- **Framework output targets** — wrappers for React, Angular and Vue.

## Quick start

```bash
npm init stencil
cd my-components
npm start
```

## Example

```tsx
import { Component, State, h } from '@stencil/core';

@Component({ tag: 'my-counter' })
export class MyCounter {
  @State() count = 0;
  render() {
    return <button onClick={() => this.count++}>Clicked {this.count} times</button>;
  }
}
```

## When to choose it

- You are building a design system used by teams on different frameworks.

## Think twice if

- You are building one normal web app — a regular framework is simpler.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://stenciljs.com).*
