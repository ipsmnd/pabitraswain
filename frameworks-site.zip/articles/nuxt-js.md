# Nuxt.js

> Full-stack Vue framework with SSR, file-based routing and modules.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | Vue-based frameworks |
| Best for | production Vue websites |
| Official site | [nuxt.com](https://nuxt.com) |

## Overview

Nuxt is the full-stack framework for Vue, similar to what Next.js is for React. It adds file-based routing, server rendering, auto-imports, a server engine (Nitro) for API routes, and a large module ecosystem.

## Key features

- **File-based routing** in `pages/`.
- **Universal rendering** — SSR, SSG or hybrid per route.
- **Auto-imports** of components and composables.
- **Nitro server** — API routes that deploy almost anywhere.
- **Modules** — content, images, i18n, UI and more.

## Quick start

```bash
npm create nuxt@latest my-app
cd my-app
npm run dev
```

## Example

```vue
<!-- pages/index.vue -->
<script setup>
const { data: posts } = await useFetch('/api/posts')
</script>

<template>
  <ul>
    <li v-for="p in posts" :key="p.id">{{ p.title }}</li>
  </ul>
</template>
```

## When to choose it

- You want an SEO-friendly, production Vue website.
- You like conventions and auto-imports.

## Think twice if

- You need only a small client-side Vue widget.

## Related

- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.
- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.
- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.
- [VuePress](#vuepress) — The original Vue-powered documentation generator.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nuxt.com).*
