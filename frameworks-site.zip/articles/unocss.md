# UnoCSS

> Instant, on-demand atomic CSS engine.

| Field | Detail |
|---|---|
| Type | utility engine |
| Category | CSS frameworks and UI libraries |
| Best for | customizable utility CSS |
| Official site | [unocss.dev](https://unocss.dev) |

## Overview

UnoCSS is an instant, on-demand atomic CSS engine. It generates only the utility classes you use, and you can enable presets (such as a Tailwind-compatible one), icons or attribute mode. It is extremely fast and highly customisable.

## Key features

- **On-demand generation** — very fast builds.
- **Presets** — Tailwind-like, icons, attributify, typography.
- **Custom rules** in a few lines.
- **Works with Vite, Nuxt, Astro and more**.

## Quick start

```bash
npm install -D unocss
```

## Example

```ts
// vite.config.ts
import UnoCSS from 'unocss/vite'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [UnoCSS()],
})

// main.ts
// import 'virtual:uno.css'
```

## When to choose it

- You want Tailwind-style utilities with full control over rules.
- You use Vite or Nuxt.

## Think twice if

- You want the largest community and plugin set — Tailwind is bigger.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://unocss.dev).*
