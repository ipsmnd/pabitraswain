# Alpine.js

> Lightweight interactivity written as HTML attributes.

| Field | Detail |
|---|---|
| Type | UI library |
| Category | Popular frontend frameworks |
| Best for | sprinkling behaviour on server-rendered pages |
| Official site | [alpinejs.dev](https://alpinejs.dev) |

## Overview

Alpine.js adds interactivity directly in your HTML using attributes like `x-data`, `x-show` and `@click`. There is no build step — just add one script tag. It is ideal for dropdowns, tabs, modals and small widgets on server-rendered pages (Laravel, Django, WordPress, static HTML).

## Key features

- **No build step** — include one script and start.
- **HTML attributes** — `x-data`, `x-bind`, `x-on`, `x-model`, `x-for`.
- **Very small** — around 15 KB.
- **Pairs well with htmx and Tailwind CSS**.

## Quick start

```html
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
```

## Example

```html
<div x-data="{ count: 0, open: false }">
  <button @click="count++">Clicked <span x-text="count"></span> times</button>

  <button @click="open = !open">Toggle menu</button>
  <ul x-show="open"><li>Home</li><li>About</li></ul>
</div>
```

## When to choose it

- Your pages are rendered by a server or CMS and need a little interactivity.
- You want to avoid a JavaScript build pipeline.

## Think twice if

- You are building a large single-page application.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://alpinejs.dev).*
