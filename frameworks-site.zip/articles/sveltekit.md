# SvelteKit

> The official application framework for Svelte with routing and SSR.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | Svelte ecosystem |
| Best for | full-stack Svelte apps |
| Official site | [svelte.dev/docs/kit](https://svelte.dev/docs/kit) |

## Overview

SvelteKit is the official application framework for Svelte. It adds file-based routing, server-side rendering, data loading, form actions and adapters that deploy to Node, Vercel, Netlify, Cloudflare and static hosting.

## Key features

- **File-based routing** with `+page.svelte` files.
- **Load functions** for server and universal data.
- **Form actions** with progressive enhancement.
- **Adapters** for almost any host.

## Quick start

```bash
npx sv create my-app
cd my-app
npm install
npm run dev
```

## Example

```svelte
<!-- src/routes/+page.svelte -->
<script>
  // data comes from +page.server.js:
  // export async function load() { return { posts: await getPosts() }; }
  let { data } = $props();
</script>

{#each data.posts as post}
  <h2>{post.title}</h2>
{/each}
```

## When to choose it

- You like Svelte and need a full website or app.
- You want SSR and great performance with little code.

## Think twice if

- You need many enterprise-grade third-party component libraries.

## Related

- [Elder.js](#elder-js) — SEO-focused Svelte static-site generator; no longer actively maintained.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://svelte.dev/docs/kit).*
