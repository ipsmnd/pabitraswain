# Remix

> Web-standards React framework whose features now live in React Router v7.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | React-based frameworks |
| Best for | data-loading-first apps |
| Official site | [remix.run](https://remix.run) |

## Overview

Remix is a React framework built on web standards — HTML forms, HTTP caching and the Fetch API. Its best ideas (nested routes, `loader` and `action` functions) were merged into React Router v7, so Remix-style apps are now built with React Router's *framework mode*. The Remix team is working on a new, separate Remix 3.

> **Status note:** Remix v2 features now live in React Router v7. Check remix.run for the latest on Remix 3.

## Key features

- **Nested routing** — each route segment loads its own data.
- **Loaders and actions** — server functions for reading and writing data.
- **Progressive enhancement** — forms work even before JavaScript loads.
- **Web-standard APIs** — Request, Response and FormData.

## Quick start

```bash
npx create-react-router@latest my-app
cd my-app
npm run dev
```

## Example

```tsx
// app/routes/user.tsx
export async function loader({ params }) {
  return { user: await getUser(params.id) };
}

export default function User({ loaderData }) {
  return <h1>{loaderData.user.name}</h1>;
}
```

## When to choose it

- You like web-standard, form-driven data flows.
- You are maintaining a Remix v2 app or upgrading it to React Router v7.

## Think twice if

- You expect the classic Remix package to be the long-term path — new apps should start on React Router.

## Related

- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.
- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.
- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.
- [React Router](#react-router) — The standard React router, with a framework mode since v7.
- [Expo](#expo) — Toolchain and platform for building React Native apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://remix.run).*
