# Angular

> Google’s TypeScript-first, batteries-included application framework.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks · Angular ecosystem |
| Best for | enterprise-scale apps |
| Official site | [angular.dev](https://angular.dev) |

## Overview

Angular is Google's complete, TypeScript-first framework. It ships with a router, forms, an HTTP client, dependency injection, testing tools and a powerful CLI, so large teams can work in one consistent structure. Modern Angular uses standalone components and Signals for fast, fine-grained reactivity.

## Key features

- **Batteries included** — router, forms, HttpClient, animations and i18n are official packages.
- **Signals** — simple reactive values that update only what changed.
- **Angular CLI** — generates components, services and builds with one command.
- **Dependency injection** — clean, testable services shared across the app.
- **SSR and hydration** — server rendering via `@angular/ssr`.

## Quick start

```bash
npm install -g @angular/cli
ng new my-app
cd my-app
ng serve
```

## Example

```ts
import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-counter',
  template: `<button (click)="count.set(count() + 1)">
    Clicked {{ count() }} times
  </button>`,
})
export class Counter {
  count = signal(0);
}
```

## When to choose it

- You are building a large, long-lived enterprise application with many developers.
- You like having one official way to do routing, forms and testing.

## Think twice if

- You need a tiny bundle for a simple marketing page.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://angular.dev).*
