# Parcel

> Zero-configuration bundler.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | quick setups |
| Official site | [parceljs.org](https://parceljs.org) |

## Overview

Parcel is a zero-configuration bundler. Point it at an HTML file and it automatically handles JavaScript, TypeScript, CSS, images and more — no config file needed.

## Key features

- **Zero config** — works out of the box.
- **Fast** — Rust-based compiler and caching.
- **Automatic transforms** for TS, JSX, Sass, images.

## Quick start

```bash
npm install -D parcel
```

## Example

```bash
# start a dev server from an HTML entry
npx parcel src/index.html

# build for production
npx parcel build src/index.html
```

## When to choose it

- You want a quick setup with no configuration.

## Think twice if

- You need a framework-specific setup — Vite templates are more common.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://parceljs.org).*
