# Ionic

> Cross-platform UI toolkit for hybrid mobile and PWA apps.

| Field | Detail |
|---|---|
| Type | mobile toolkit |
| Category | Angular ecosystem |
| Best for | web-skilled teams shipping mobile apps |
| Official site | [ionicframework.com](https://ionicframework.com) |

## Overview

Ionic is a UI toolkit of mobile-styled components (built as Web Components) for building iOS, Android and PWA apps with web technology. It works with Angular, React or Vue, and uses Capacitor to access native device features.

## Key features

- **Adaptive components** — look native on iOS and Android.
- **Works with Angular, React and Vue**.
- **Capacitor** — camera, files, push notifications.
- **Ionic CLI** for creating and running apps.

## Quick start

```bash
npm install -g @ionic/cli
ionic start my-app tabs
cd my-app
ionic serve
```

## Example

```html
<ion-header>
  <ion-toolbar><ion-title>Profile</ion-title></ion-toolbar>
</ion-header>
<ion-content class="ion-padding">
  <ion-input label="Name" placeholder="Enter your name"></ion-input>
  <ion-button expand="block">Save</ion-button>
</ion-content>
```

## When to choose it

- A web-skilled team needs to ship mobile apps.
- You want one codebase for app stores and a PWA.

## Think twice if

- Your app needs heavy native performance such as 3D games.

## Related

- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [AnalogJS](#analogjs) — Vite-powered meta-framework for Angular with file-based routing and SSR.
- [Nx](#nx) — Monorepo build system with caching and code generation.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ionicframework.com).*
