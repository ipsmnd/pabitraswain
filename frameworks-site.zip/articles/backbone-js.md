# Backbone.js

> Minimal MVC-style structure with models and views; now mostly legacy.

| Field | Detail |
|---|---|
| Type | library |
| Category | Popular frontend frameworks |
| Best for | maintaining older codebases |
| Official site | [backbonejs.org](https://backbonejs.org) |

## Overview

Backbone.js was one of the first popular JavaScript MVC libraries. It gives structure with Models, Collections, Views and a Router, and depends on Underscore.js (and usually jQuery). Today it is mostly found in older, still-running codebases.

> **Status note:** Backbone receives very few updates today. Use it for maintenance, not for new apps.

## Key features

- **Models and Collections** with change events.
- **Views** that listen to models and re-render.
- **Router** for hash or history URLs.
- **Very small and simple**.

## Quick start

```bash
npm install backbone underscore jquery
```

## Example

```js
const Counter = Backbone.Model.extend({ defaults: { count: 0 } });

const CounterView = Backbone.View.extend({
  events: { click: 'inc' },
  initialize() { this.listenTo(this.model, 'change', this.render); },
  inc() { this.model.set('count', this.model.get('count') + 1); },
  render() { this.$el.text(`Clicked ${this.model.get('count')} times`); return this; }
});
```

## When to choose it

- You maintain or extend an existing Backbone application.
- You want to understand where modern MVC frameworks came from.

## Think twice if

- You are starting a new project — choose a modern framework instead.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://backbonejs.org).*
