# Expo

> Toolchain and platform for building React Native apps.

| Field | Detail |
|---|---|
| Type | mobile toolkit |
| Category | React-based frameworks |
| Best for | iOS, Android and web from one codebase |
| Official site | [expo.dev](https://expo.dev) |

## Overview

Expo is a framework and platform for React Native. It lets you build iOS, Android and web apps from one JavaScript/TypeScript codebase, test instantly on your phone with Expo Go, and build or update apps in the cloud with EAS.

## Key features

- **Expo Router** — file-based navigation for mobile and web.
- **Expo SDK** — camera, notifications, location and more.
- **EAS Build and Update** — cloud builds and over-the-air updates.
- **Expo Go** — preview on a real device without Xcode or Android Studio.

## Quick start

```bash
npx create-expo-app@latest my-app
cd my-app
npx expo start
```

## Example

```tsx
import { Text, View, Pressable } from 'react-native';
import { useState } from 'react';

export default function Home() {
  const [count, setCount] = useState(0);
  return (
    <View style={{ padding: 40 }}>
      <Pressable onPress={() => setCount(count + 1)}>
        <Text>Tapped {count} times</Text>
      </Pressable>
    </View>
  );
}
```

## When to choose it

- You know React and want to ship real mobile apps.
- You want one codebase for iOS, Android and web.

## Think twice if

- Your app needs heavy custom native code from day one (still possible, but more work).

## Related

- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.
- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.
- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.
- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.
- [React Router](#react-router) — The standard React router, with a framework mode since v7.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://expo.dev).*
