# Rollup

> ES-module bundler favoured for libraries.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | publishing libraries |
| Official site | [rollupjs.org](https://rollupjs.org) |

## Overview

Rollup is an ES-module bundler known for clean, efficient output and excellent tree-shaking. It is the favourite tool for publishing JavaScript libraries and is used inside Vite for production builds.

## Key features

- **Excellent tree-shaking**.
- **Multiple output formats** — ESM, CommonJS, UMD.
- **Simple plugin API** (also used by Vite).

## Quick start

```bash
npm install -D rollup
```

## Example

```js
// rollup.config.js
export default {
  input: 'src/index.js',
  output: [
    { file: 'dist/index.mjs', format: 'es' },
    { file: 'dist/index.cjs', format: 'cjs' },
  ],
};
```

## When to choose it

- You are publishing an npm library.

## Think twice if

- You want a dev server for an app — use Vite.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Parcel](#parcel) — Zero-configuration bundler.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://rollupjs.org).*
