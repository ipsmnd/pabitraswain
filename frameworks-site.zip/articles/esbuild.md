# esbuild

> Extremely fast bundler written in Go.

| Field | Detail |
|---|---|
| Type | bundler |
| Category | Frontend build tools |
| Best for | speed-critical builds |
| Official site | [esbuild.github.io](https://esbuild.github.io) |

## Overview

esbuild is an extremely fast JavaScript and TypeScript bundler and minifier written in Go — often 10–100× faster than older tools. Vite and many other tools use it internally.

## Key features

- **Extremely fast** bundling and minifying.
- **TypeScript and JSX** out of the box.
- **Simple CLI and JS API**.

## Quick start

```bash
npm install -D esbuild
```

## Example

```bash
npx esbuild src/app.jsx --bundle --minify --sourcemap --outfile=dist/app.js
```

## When to choose it

- Speed is critical, e.g. scripts, CLIs or simple bundles.

## Think twice if

- You need advanced features like rich HMR — use Vite, which uses esbuild inside.

## Related

- [Vite](#vite) — Fast dev server and bundler using native ES modules.
- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Parcel](#parcel) — Zero-configuration bundler.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://esbuild.github.io).*
