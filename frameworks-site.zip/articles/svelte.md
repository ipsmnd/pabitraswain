# Svelte

> Compiler-based framework that ships very little runtime code.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | small, fast bundles |
| Official site | [svelte.dev](https://svelte.dev) |

## Overview

Svelte is a compiler. Instead of shipping a large runtime to the browser, it turns your components into small, efficient JavaScript at build time. Svelte 5 introduced *runes* such as `$state` and `$derived`, which make reactivity explicit and easy to read.

## Key features

- **Compile-time framework** — very little framework code reaches the browser.
- **Runes** — `$state`, `$derived` and `$effect` for clear reactivity.
- **Scoped CSS by default** — styles in a component never leak out.
- **Built-in transitions and animations**.

## Quick start

```bash
npx sv create my-app
cd my-app
npm install
npm run dev
```

## Example

```svelte
<script>
  let count = $state(0);
</script>

<button onclick={() => count++}>
  Clicked {count} times
</button>
```

## When to choose it

- You want small bundles and very little boilerplate.
- You enjoy writing close to plain HTML, CSS and JavaScript.

## Think twice if

- You need the biggest possible library ecosystem or hiring pool.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://svelte.dev).*
