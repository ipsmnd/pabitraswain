# React.js

> Meta’s component-based library built on JSX and hooks.

| Field | Detail |
|---|---|
| Type | UI library |
| Category | Popular frontend frameworks |
| Best for | large apps with a huge ecosystem |
| Official site | [react.dev](https://react.dev) |

## Overview

React is the most widely used library for building user interfaces. You describe the UI as small, reusable components written in JSX, and React updates the page efficiently when your data changes. It focuses only on the view layer, so routing, data fetching and styling are chosen separately or provided by a framework such as Next.js.

## Key features

- **Components and JSX** — UI is built from functions that return HTML-like markup.
- **Hooks** — `useState`, `useEffect` and friends add state and side effects to components.
- **React Compiler** — automatically memoises components so you write less optimisation code.
- **Server Components** — render parts of the UI on the server when used with a framework like Next.js.
- **Huge ecosystem** — libraries exist for almost every need, and React Native reuses the same model for mobile.

## Quick start

```bash
npm create vite@latest my-app -- --template react
cd my-app
npm install
npm run dev
```

## Example

```jsx
import { useState } from 'react';

export default function Counter() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount(count + 1)}>
      Clicked {count} times
    </button>
  );
}
```

## When to choose it

- You want the largest job market and the most third-party libraries.
- You plan to share skills between web and mobile (React Native / Expo).

## Think twice if

- You want routing, forms and HTTP built in — React leaves those choices to you.

## Related

- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://react.dev).*
