# VuePress

> The original Vue-powered documentation generator.

| Field | Detail |
|---|---|
| Type | static site generator |
| Category | Vue-based frameworks |
| Best for | Markdown-centred doc sites |
| Official site | [vuepress.vuejs.org](https://vuepress.vuejs.org) |

## Overview

VuePress is the original Vue-powered documentation generator. VuePress 2 supports Vue 3 and Vite and is maintained by the community; for new documentation sites, the Vue team recommends its successor, VitePress.

## Key features

- **Markdown-centred** pages with Vue components.
- **Themes and plugins**.
- **Static output** with SPA navigation.

## Quick start

```bash
npm init vuepress my-docs
cd my-docs
npm run docs:dev
```

## Example

```md
---
title: Getting started
---

# Welcome

This page is written in **Markdown**.

<MyVueComponent />
```

## When to choose it

- You maintain an existing VuePress site.

## Think twice if

- You are starting fresh — VitePress is faster and more active.

## Related

- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.
- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.
- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.
- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vuepress.vuejs.org).*
