# Qwik

> Resumable framework that loads JavaScript only when needed.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | instant startup on slow devices |
| Official site | [qwik.dev](https://qwik.dev) |

## Overview

Qwik is built for instant page loads. Its key idea is *resumability*: the server sends HTML plus a tiny loader, and the browser downloads the JavaScript for an interaction only when the user actually triggers it. There is no expensive hydration step on start-up.

## Key features

- **Resumability** — no hydration; the app resumes where the server left off.
- **Lazy loading by default** — the `$` suffix marks code that can be loaded on demand.
- **Qwik City** — file-based routing, loaders and actions.
- **JSX syntax** — familiar to React developers.

## Quick start

```bash
npm create qwik@latest
cd my-app
npm start
```

## Example

```tsx
import { component$, useSignal } from '@builder.io/qwik';

export default component$(() => {
  const count = useSignal(0);
  return (
    <button onClick$={() => count.value++}>
      Clicked {count.value} times
    </button>
  );
});
```

## When to choose it

- Your users are on slow phones or networks and start-up speed matters most.
- You are building content-heavy e-commerce or marketing sites.

## Think twice if

- You need a mature ecosystem of ready-made components.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://qwik.dev).*
