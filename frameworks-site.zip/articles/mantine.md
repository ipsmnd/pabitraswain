# Mantine

> Full-featured React components and hooks library.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | productive React apps |
| Official site | [mantine.dev](https://mantine.dev) |

## Overview

Mantine is a full-featured React component library with 100+ components and 50+ hooks. It has great documentation, built-in dark mode, and extra packages for forms, dates, notifications and charts.

## Key features

- **100+ components** and many useful hooks.
- **Dark mode and theming** built in.
- **Extra packages** — form, dates, notifications, charts.
- **CSS modules based** styling.

## Quick start

```bash
npm install @mantine/core @mantine/hooks
```

## Example

```jsx
import '@mantine/core/styles.css';
import { MantineProvider, Button, Card, Text } from '@mantine/core';

export default function App() {
  return (
    <MantineProvider defaultColorScheme="dark">
      <Card padding="lg" radius="lg">
        <Text fw={700}>Web Design</Text>
        <Button mt="md">Learn more</Button>
      </Card>
    </MantineProvider>
  );
}
```

## When to choose it

- You want to be productive quickly in React with good docs.

## Think twice if

- You are not using React.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mantine.dev).*
