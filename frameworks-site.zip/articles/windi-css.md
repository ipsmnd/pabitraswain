# Windi CSS

> Early on-demand Tailwind alternative; now deprecated.

| Field | Detail |
|---|---|
| Type | utility engine |
| Category | CSS frameworks and UI libraries |
| Best for | understanding utility-CSS history |
| Official site | [windicss.org](https://windicss.org) |

## Overview

Windi CSS was an early on-demand alternative to Tailwind CSS that made dev builds much faster. Its ideas were adopted by Tailwind's JIT engine and by UnoCSS, and the project has been sunset.

> **Status note:** Windi CSS was sunset in 2023. Migrate to Tailwind CSS or UnoCSS.

## Key features

- **On-demand utility generation** (influenced Tailwind JIT).
- **Tailwind-compatible classes**.
- **Attributify mode** — later carried into UnoCSS.

## Quick start

```bash
# Deprecated — for new projects install Tailwind CSS or UnoCSS instead
npm install -D unocss
```

## Example

```html
<!-- Windi-style utilities still work the same way in Tailwind/UnoCSS -->
<button class="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-500">
  Learn more
</button>
```

## When to choose it

- You want to understand the history of utility-first CSS.

## Think twice if

- Any new project — it is no longer maintained.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://windicss.org).*
