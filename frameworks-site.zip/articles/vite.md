# Vite

> Fast dev server and bundler using native ES modules.

| Field | Detail |
|---|---|
| Type | build tool |
| Category | Frontend build tools |
| Best for | almost any modern project |
| Official site | [vite.dev](https://vite.dev) |

## Overview

Vite is a fast build tool and dev server. In development it serves your code as native ES modules, so the server starts instantly and changes appear immediately (hot module replacement). For production it creates optimised bundles. It is the default tool for Vue, Svelte, Solid and many React projects.

## Key features

- **Instant dev server** and fast HMR.
- **Templates** for React, Vue, Svelte, Solid, Preact, Lit and vanilla JS.
- **TypeScript, JSX and CSS** support built in.
- **Plugin system** compatible with Rollup plugins.

## Quick start

```bash
npm create vite@latest my-app
cd my-app
npm install
npm run dev
```

## Example

```js
// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 3000 },
});
```

## When to choose it

- Almost any new frontend project.
- You want fast feedback while coding.

## Think twice if

- You have a very complex legacy webpack setup you can't migrate yet.

## Related

- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.
- [Parcel](#parcel) — Zero-configuration bundler.
- [Rollup](#rollup) — ES-module bundler favoured for libraries.
- [esbuild](#esbuild) — Extremely fast bundler written in Go.
- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.
- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vite.dev).*
