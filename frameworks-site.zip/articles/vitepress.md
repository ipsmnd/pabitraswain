# VitePress

> Vite and Vue powered generator for documentation sites.

| Field | Detail |
|---|---|
| Type | static site generator |
| Category | Vue-based frameworks |
| Best for | docs and technical blogs |
| Official site | [vitepress.dev](https://vitepress.dev) |

## Overview

VitePress is a static-site generator powered by Vite and Vue, designed for documentation. You write Markdown, and it produces a fast, searchable docs site with a polished default theme. The docs for Vue, Vite and many other projects use it.

## Key features

- **Markdown-first** with Vue components inside Markdown.
- **Fast dev server** thanks to Vite.
- **Great default docs theme** — sidebar, search, dark mode.
- **Static output** — host anywhere.

## Quick start

```bash
npm add -D vitepress
npx vitepress init
npm run docs:dev
```

## Example

```ts
// .vitepress/config.mts
import { defineConfig } from 'vitepress'

export default defineConfig({
  title: 'MND Docs',
  themeConfig: {
    nav: [{ text: 'Guide', link: '/guide/' }],
    sidebar: [{ text: 'Intro', link: '/guide/' }]
  }
})
```

## When to choose it

- You need a documentation site or technical blog quickly.
- You like writing in Markdown.

## Think twice if

- You need a full web application.

## Related

- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.
- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.
- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.
- [VuePress](#vuepress) — The original Vue-powered documentation generator.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vitepress.dev).*
