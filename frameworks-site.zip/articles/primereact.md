# PrimeReact

> Large React UI suite with many data components.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | feature-rich business UIs |
| Official site | [primereact.org](https://primereact.org) |

## Overview

PrimeReact is a large React UI suite with 80+ components, including a powerful DataTable, charts, calendars and file uploads. It offers styled themes or an unstyled mode you can style with Tailwind.

## Key features

- **80+ components** for business apps.
- **DataTable** — sorting, filtering, paging, editing.
- **Themes or unstyled mode**.
- **Sister libraries** — PrimeVue and PrimeNG.

## Quick start

```bash
npm install primereact
```

## Example

```jsx
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

export default function Projects({ rows }) {
  return (
    <DataTable value={rows} paginator rows={5}>
      <Column field="name" header="Project" sortable />
      <Column field="type" header="Type" />
    </DataTable>
  );
}
```

## When to choose it

- You need feature-rich data components quickly.

## Think twice if

- You only need a few simple components.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://primereact.org).*
