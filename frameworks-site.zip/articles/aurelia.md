# Aurelia

> Standards-focused framework with convention-based binding.

| Field | Detail |
|---|---|
| Type | framework |
| Category | Popular frontend frameworks |
| Best for | clean, plain-JavaScript classes |
| Official site | [aurelia.io](https://aurelia.io) |

## Overview

Aurelia is a standards-focused framework where your components are plain JavaScript or TypeScript classes with HTML templates. Its convention-based binding means very little framework-specific code. Aurelia 2 is the current major version.

## Key features

- **Plain classes** — little framework code inside your components.
- **Two-way binding** with clear syntax like `value.bind` and `click.trigger`.
- **Dependency injection and router** included.
- **Standards-based** — uses modern web APIs.

## Quick start

```bash
npx makes aurelia
cd my-app
npm start
```

## Example

```html
<!-- my-app.ts:  export class MyApp { count = 0; increment() { this.count++; } } -->

<button click.trigger="increment()">
  Clicked ${count} times
</button>
```

## When to choose it

- You want clean, framework-light code.
- Your team likes conventions and two-way binding.

## Think twice if

- You need a large community and many tutorials.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://aurelia.io).*
