# Lit

> Small library for building standards-based web components.

| Field | Detail |
|---|---|
| Type | UI library |
| Category | Popular frontend frameworks |
| Best for | framework-agnostic components |
| Official site | [lit.dev](https://lit.dev) |

## Overview

Lit is a small library from Google for building fast, standard Web Components. Components made with Lit are real custom HTML elements, so they work in plain HTML and inside React, Vue, Angular or any other framework.

## Key features

- **Standards-based** — builds on Custom Elements and Shadow DOM.
- **Reactive properties** — re-render when values change.
- **Tagged template literals** — `html` templates with no compiler needed.
- **Small** — about 5 KB.

## Quick start

```bash
npm install lit
```

## Example

```js
import { LitElement, html } from 'lit';

class MyCounter extends LitElement {
  static properties = { count: { type: Number } };
  constructor() { super(); this.count = 0; }
  render() {
    return html`<button @click=${() => this.count++}>
      Clicked ${this.count} times</button>`;
  }
}
customElements.define('my-counter', MyCounter);
```

## When to choose it

- You need components that work in any framework or in plain HTML.
- You are building a design system shared by several teams.

## Think twice if

- You want a full app framework with routing and data loading.

## Related

- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.
- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.
- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.
- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.
- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.
- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://lit.dev).*
