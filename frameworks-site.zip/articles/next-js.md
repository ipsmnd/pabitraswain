# Next.js

> Vercel’s full-stack React framework with SSR, SSG and the App Router.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | React-based frameworks |
| Best for | production React websites |
| Official site | [nextjs.org](https://nextjs.org) |

## Overview

Next.js, made by Vercel, is the most popular full-stack framework for React. It adds file-based routing, server rendering, static generation, API routes and image optimisation. The App Router is built around React Server Components, so data can be fetched directly inside components on the server.

## Key features

- **App Router** — folders in `app/` become routes, with layouts and loading states.
- **Server Components and Server Actions** — fetch data and handle forms on the server.
- **SSR, SSG and ISR** — choose rendering per page.
- **Built-in optimisation** — images, fonts and scripts.
- **Turbopack** — fast Rust-based bundler for dev and builds.

## Quick start

```bash
npx create-next-app@latest my-app
cd my-app
npm run dev
```

## Example

```tsx
// app/page.tsx — a Server Component
export default async function Page() {
  const res = await fetch('https://api.example.com/posts');
  const posts = await res.json();
  return (
    <ul>
      {posts.map((p) => <li key={p.id}>{p.title}</li>)}
    </ul>
  );
}
```

## When to choose it

- You want a production-ready React website with good SEO.
- You plan to deploy to Vercel or any Node.js host.

## Think twice if

- You only need a small client-side widget — plain React with Vite is lighter.

## Related

- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.
- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.
- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.
- [React Router](#react-router) — The standard React router, with a framework mode since v7.
- [Expo](#expo) — Toolchain and platform for building React Native apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nextjs.org).*
