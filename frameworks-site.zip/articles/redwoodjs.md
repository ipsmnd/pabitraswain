# RedwoodJS

> Opinionated full-stack framework combining React, GraphQL and Prisma.

| Field | Detail |
|---|---|
| Type | meta-framework |
| Category | React-based frameworks |
| Best for | startups wanting one integrated stack |
| Official site | [redwoodjs.com](https://redwoodjs.com) |

## Overview

RedwoodJS is an opinionated full-stack framework that combines React, GraphQL and Prisma in one project, with generators for pages, services and database models. Its *Cells* pattern handles loading, empty, error and success states for data automatically.

> **Status note:** The core team has shifted focus to the newer RedwoodSDK; check redwoodjs.com for the current status of each project.

## Key features

- **Full-stack in one repo** — `web` and `api` sides.
- **Cells** — declarative data fetching with built-in states.
- **Prisma** for the database, **GraphQL** for the API.
- **Generators** — scaffold CRUD pages in seconds.

## Quick start

```bash
yarn create redwood-app my-app
cd my-app
yarn rw dev
```

## Example

```jsx
// web/src/components/PostsCell.jsx
export const QUERY = gql`query { posts { id title } }`;

export const Loading = () => <div>Loading…</div>;
export const Empty = () => <div>No posts yet</div>;
export const Success = ({ posts }) => (
  <ul>{posts.map(p => <li key={p.id}>{p.title}</li>)}</ul>
);
```

## When to choose it

- A startup team wants one integrated, opinionated stack.

## Think twice if

- You don't want GraphQL in your app.

## Related

- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.
- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.
- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.
- [React Router](#react-router) — The standard React router, with a framework mode since v7.
- [Expo](#expo) — Toolchain and platform for building React Native apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://redwoodjs.com).*
