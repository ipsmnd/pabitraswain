# DaisyUI

> Tailwind plugin that adds ready-made component classes.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | Tailwind with less markup |
| Official site | [daisyui.com](https://daisyui.com) |

## Overview

daisyUI is a plugin for Tailwind CSS that adds ready-made component class names such as `btn`, `card` and `modal`. You keep Tailwind utilities but write much less markup, and switch between many built-in themes.

## Key features

- **Component classes** — `btn`, `card`, `navbar`, `modal`.
- **Many themes** including dark mode.
- **Pure CSS** — works with any framework.
- **Still fully customisable** with Tailwind utilities.

## Quick start

```bash
npm install -D daisyui@latest

# in your CSS (Tailwind v4):
# @import "tailwindcss";
# @plugin "daisyui";
```

## Example

```html
<div class="card bg-base-200 w-80 shadow">
  <div class="card-body">
    <h2 class="card-title">Web Design</h2>
    <div class="card-actions justify-end">
      <button class="btn btn-primary">Learn more</button>
    </div>
  </div>
</div>
```

## When to choose it

- You use Tailwind but want shorter markup and themes.

## Think twice if

- You don't use Tailwind CSS.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://daisyui.com).*
