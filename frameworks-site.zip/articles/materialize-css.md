# Materialize CSS

> Framework implementing Google’s Material Design.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | Material-style sites |
| Official site | [materializecss.github.io/materialize](https://materializecss.github.io/materialize/) |

## Overview

Materialize is a CSS framework that implements Google's Material Design look — cards, shadows, ripple 'waves' effects and floating buttons. The original project is no longer maintained; a community fork continues development.

> **Status note:** Use the community fork (`@materializecss/materialize`), not the old `materialize-css` package.

## Key features

- **Material Design styling**.
- **Components** — cards, modals, tabs, toasts.
- **Waves** ripple effect.
- **Responsive grid**.

## Quick start

```bash
npm install @materializecss/materialize
```

## Example

```html
<div class="row">
  <div class="col s12 m6">
    <div class="card">
      <div class="card-content"><span class="card-title">Web Design</span></div>
      <div class="card-action"><a class="btn waves-effect">Learn more</a></div>
    </div>
  </div>
</div>
```

## When to choose it

- You want a quick Material-style look without React.

## Think twice if

- You use React — Material UI (MUI) is far more complete.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://materializecss.github.io/materialize/).*
