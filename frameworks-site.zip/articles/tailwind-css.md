# Tailwind CSS

> Utility-first framework for styling directly in markup.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | custom designs at speed |
| Official site | [tailwindcss.com](https://tailwindcss.com) |

## Overview

Tailwind CSS is a utility-first framework: instead of writing custom CSS, you combine small classes like `flex`, `p-4` and `text-blue-600` directly in your HTML. Only the classes you actually use end up in the final CSS file, so it stays small. Version 4 made setup simpler with a single CSS import.

## Key features

- **Utility classes** for layout, spacing, colour and typography.
- **Responsive and state variants** — `md:`, `hover:`, `dark:`.
- **Tiny production CSS** — unused classes are removed.
- **CSS-first config** in v4 using `@theme`.

## Quick start

```bash
npm install tailwindcss @tailwindcss/vite

# then in your main CSS file:
# @import "tailwindcss";
```

## Example

```html
<div class="max-w-sm rounded-2xl bg-slate-900 p-6 shadow-lg">
  <h3 class="text-xl font-bold text-white">Web Design</h3>
  <p class="mt-2 text-slate-400">Functional, user-first interfaces.</p>
  <button class="mt-4 rounded-xl bg-blue-600 px-4 py-2 text-white hover:bg-blue-500">
    Learn more
  </button>
</div>
```

## When to choose it

- You want fully custom designs without writing much CSS.
- You use React, Vue or Svelte components.

## Think twice if

- You dislike long class lists in HTML.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://tailwindcss.com).*
