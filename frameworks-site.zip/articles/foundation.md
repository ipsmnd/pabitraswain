# Foundation

> Responsive framework from ZURB aimed at flexible, accessible sites.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | advanced responsive layouts |
| Official site | [get.foundation](https://get.foundation) |

## Overview

Foundation by ZURB is a responsive front-end framework focused on flexibility and accessibility. It offers an XY grid, Sass mixins, components and a separate framework for HTML emails.

> **Status note:** Updates are infrequent compared with Bootstrap or Tailwind.

## Key features

- **XY Grid** — flexible responsive layouts.
- **Sass-based** customisation.
- **Accessible components** with JavaScript plugins.
- **Foundation for Emails**.

## Quick start

```bash
npm install foundation-sites
```

## Example

```html
<div class="grid-container">
  <div class="grid-x grid-margin-x">
    <div class="cell medium-6">Left</div>
    <div class="cell medium-6">Right</div>
  </div>
  <a class="button primary" href="#">Learn more</a>
</div>
```

## When to choose it

- You maintain a Foundation site or need its email framework.

## Think twice if

- You are starting new — Bootstrap or Tailwind have more active communities.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://get.foundation).*
