# Ant Design

> Enterprise-grade React UI system with a rich component set.

| Field | Detail |
|---|---|
| Type | component library |
| Category | CSS frameworks and UI libraries |
| Best for | admin and data-heavy apps |
| Official site | [ant.design](https://ant.design) |

## Overview

Ant Design is an enterprise-grade React UI system from Ant Group. It has a very rich component set — especially tables, forms and data-entry controls — making it a favourite for admin panels and data-heavy apps.

## Key features

- **60+ components** focused on business apps.
- **Powerful Table and Form**.
- **Design tokens** for theming.
- **Built-in internationalisation**.

## Quick start

```bash
npm install antd
```

## Example

```jsx
import { Button, Table } from 'antd';

const columns = [{ title: 'Name', dataIndex: 'name' }, { title: 'Role', dataIndex: 'role' }];
const data = [{ key: 1, name: 'Pabitra', role: 'Developer' }];

export default function Team() {
  return (
    <>
      <Button type="primary">Add member</Button>
      <Table columns={columns} dataSource={data} />
    </>
  );
}
```

## When to choose it

- You build admin dashboards with many tables and forms.

## Think twice if

- You want a lightweight or very custom-looking marketing site.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ant.design).*
