# Gridsome

> Vue static-site generator using GraphQL; largely unmaintained today.

| Field | Detail |
|---|---|
| Type | static site generator |
| Category | Vue-based frameworks |
| Best for | reading about older Vue JAMstack projects |
| Official site | [gridsome.org](https://gridsome.org) |

## Overview

Gridsome was a Vue-powered static-site generator inspired by Gatsby, with a GraphQL data layer for Markdown, CMS and API content. It never moved to Vue 3 and is largely unmaintained today.

> **Status note:** Gridsome is based on Vue 2 (end of life) and receives no active development.

## Key features

- **GraphQL data layer**.
- **Static output** for JAMstack hosting.
- **Plugins** for CMS and Markdown sources.

## Quick start

```bash
npx @gridsome/cli create my-site
cd my-site
npx gridsome develop
```

## Example

```vue
<page-query>
query { allPost { edges { node { id title } } } }
</page-query>

<template>
  <Layout>
    <h2 v-for="e in $page.allPost.edges" :key="e.node.id">{{ e.node.title }}</h2>
  </Layout>
</template>
```

## When to choose it

- You are reading or maintaining an older Vue 2 JAMstack project.

## Think twice if

- You are starting a new site — use Nuxt or VitePress instead.

## Related

- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.
- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.
- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.
- [VuePress](#vuepress) — The original Vue-powered documentation generator.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://gridsome.org).*
