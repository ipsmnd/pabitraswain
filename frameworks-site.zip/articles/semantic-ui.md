# Semantic UI

> Framework using human-friendly, natural-language class names.

| Field | Detail |
|---|---|
| Type | CSS framework |
| Category | CSS frameworks and UI libraries |
| Best for | readable class names |
| Official site | [fomantic-ui.com](https://fomantic-ui.com) |

## Overview

Semantic UI uses human-friendly class names that read like sentences, such as `ui primary button`. The original project stopped active development; the community fork Fomantic-UI continues it.

> **Status note:** The original Semantic UI is inactive — use Fomantic-UI for updates.

## Key features

- **Natural-language class names**.
- **Large set of components and themes**.
- **jQuery-based behaviours** for interactive parts.

## Quick start

```bash
npm install fomantic-ui-css
```

## Example

```html
<div class="ui card">
  <div class="content">
    <div class="header">Web Design</div>
  </div>
  <button class="ui primary button">Learn more</button>
</div>
```

## When to choose it

- You like readable class names and maintain a Semantic/Fomantic site.

## Think twice if

- You want a framework without jQuery.

## Related

- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.
- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.
- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.
- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.
- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.
- [UIKit](#uikit) — Modular front-end framework from YOOtheme.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://fomantic-ui.com).*
