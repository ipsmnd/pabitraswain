# React Router

> The standard React router, with a framework mode since v7.

| Field | Detail |
|---|---|
| Type | routing library |
| Category | React-based frameworks |
| Best for | client-side routing and data loading |
| Official site | [reactrouter.com](https://reactrouter.com) |

## Overview

React Router is the standard routing library for React. Since version 7 it works in three modes: *declarative* (simple `<Routes>`), *data* (loaders and actions) and *framework* (full Remix-style app with SSR and file-based route config).

## Key features

- **Nested routes and layouts**.
- **Loaders and actions** for data in data and framework modes.
- **Framework mode** — SSR, code splitting and type-safe routes.
- **URL params, search params and navigation hooks**.

## Quick start

```bash
npm install react-router
```

## Example

```jsx
import { createBrowserRouter, RouterProvider } from 'react-router';

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/users/:id', element: <User />,
    loader: ({ params }) => getUser(params.id) },
]);

root.render(<RouterProvider router={router} />);
```

## When to choose it

- You build a React SPA and need routing.
- You want Remix-style data loading without Next.js.

## Think twice if

- You already use Next.js — it has its own router.

## Related

- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.
- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.
- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.
- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.
- [Expo](#expo) — Toolchain and platform for building React Native apps.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://reactrouter.com).*
