# Elder.js

> SEO-focused Svelte static-site generator; no longer actively maintained.

| Field | Detail |
|---|---|
| Type | static site generator |
| Category | Svelte ecosystem |
| Best for | studying content-site architecture |
| Official site | [elderguide.com/tech/elderjs](https://elderguide.com/tech/elderjs/) |

## Overview

Elder.js is an SEO-focused static-site generator built on Svelte, designed for very large content sites with thousands of pages and partial hydration of interactive parts. It is no longer actively maintained.

> **Status note:** Elder.js has not had significant updates for several years.

## Key features

- **Built for SEO** and large sites.
- **Partial hydration** of Svelte components.
- **Hooks system** to customise every build step.

## Quick start

```bash
npx degit Elderjs/template elderjs-app
cd elderjs-app
npm install
npm start
```

## Example

```js
// src/routes/blog/route.js
module.exports = {
  all: async () => [{ slug: 'hello-world' }],
  permalink: ({ request }) => `/blog/${request.slug}/`,
  data: async ({ request }) => ({ title: request.slug }),
};
```

## When to choose it

- You want to study how large content sites are architected.

## Think twice if

- You are starting a new project — SvelteKit or Astro are better choices.

## Related

- [SvelteKit](#sveltekit) — The official application framework for Svelte with routing and SSR.

---

*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://elderguide.com/tech/elderjs/).*
