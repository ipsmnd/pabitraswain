# Pabitra Swain — Portfolio

Personal portfolio built with **React 18 + Vite**, **Tailwind CSS v3**, **React Router v6**, **Framer Motion**, **React Icons** and **EmailJS**.
All content comes from plain JavaScript data files — no backend.

## Folder structure

```
portfolio/
├── public/                 favicon.svg, resume.pdf, og-avatar.webp, images/, _redirects (Netlify)
├── src/
│   ├── assets/             images you import from code
│   ├── components/         Navbar, Footer, Hero, SectionTitle, ProjectCard, ProjectModal, SkillBar,
│   │                       Timeline, ArticleCard, Markdown, ThemeToggle, ScrollToTop, Loader, Modal,
│   │                       Seo, PageTransition, Reveal, Counter, Services, Testimonials, SocialLinks, StarField
│   ├── pages/              Home, About, Skills, Projects, Articles, ArticleDetail, Experience, Contact, NotFound
│   ├── data/               projects.js, skills.js, articles.js, experience.js, socials.js
│   ├── hooks/              useTheme.js, useScrollAnimation.js, useDebounce.js
│   ├── css/                index.css (Tailwind + @layer components), animations.css
│   ├── scripts/            utils.js, formValidation.js, emailService.js, constants.js
│   ├── App.jsx             routes (lazy-loaded) + layout
│   └── main.jsx            entry point
├── tailwind.config.js      custom palette, fonts, animations
├── postcss.config.js
├── vite.config.js
├── vercel.json             SPA rewrites for Vercel
└── package.json
```

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
npm run preview    # serve the build locally
```

### How this project was set up (for reference)

```bash
npm create vite@latest portfolio -- --template react
cd portfolio
npm install react-router-dom framer-motion react-icons @emailjs/browser react-markdown remark-gfm
npm install -D tailwindcss@3 postcss autoprefixer @tailwindcss/typography
npx tailwindcss init -p
```

## Customise content

| What | Where |
|---|---|
| Name, email, phone, intro, bio, stats, services, testimonials, nav | `src/scripts/constants.js` |
| Projects (add an object to add a card) | `src/data/projects.js` + image in `public/images/projects/` |
| Skills and design styles | `src/data/skills.js` |
| Articles (Markdown in `content`) | `src/data/articles.js` |
| Work history and education | `src/data/experience.js` |
| Social links | `src/data/socials.js` |
| Colours, fonts | `tailwind.config.js` |
| Resume | replace `public/resume.pdf` |

- **Projects**: set `liveUrl` / `githubUrl` to show the Live demo / Source buttons in the project modal; leave `''` to hide them.
- **Articles**: links like `[Vue.js](#vue-js)` inside Markdown automatically go to `/articles/vue-js`.
- **Images**: use `.webp`, about 900px wide.

## Contact form (EmailJS)

1. Create a free account at emailjs.com, add an email service and a template.
2. In the template use the variables `{{from_name}}`, `{{reply_to}}`, `{{subject}}`, `{{message}}`.
3. Copy `.env.example` to `.env` and fill in the three IDs.
4. Restart `npm run dev`.

Without these keys the form still works: it opens the visitor's email app with the message filled in.

## Deploy

**Vercel**: push to GitHub → "Add New Project" on vercel.com → import the repo → framework preset *Vite* → add the three `VITE_EMAILJS_*` variables → Deploy. `vercel.json` makes deep links like `/articles/react-js` work.

**Netlify**: "Add new site" → import the repo → build command `npm run build`, publish directory `dist` → add the env variables → Deploy. `public/_redirects` handles deep links.

After deploying, set `SITE.url` in `src/scripts/constants.js` to your real domain so canonical and Open Graph URLs are correct.
