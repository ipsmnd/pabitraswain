Put images you import from code here (e.g. import logo from './assets/logo.svg').
Photos referenced by URL in src/data live in /public/images.
