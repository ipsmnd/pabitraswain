/**
 * Sends the contact form with EmailJS.
 * Set VITE_EMAILJS_SERVICE_ID, VITE_EMAILJS_TEMPLATE_ID and
 * VITE_EMAILJS_PUBLIC_KEY in a .env file (see .env.example).
 * If they are missing, we open the visitor's email app instead,
 * so the form still works on a fresh install.
 */
import { SITE } from './constants';

const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID;
const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

export const isEmailConfigured = Boolean(SERVICE_ID && TEMPLATE_ID && PUBLIC_KEY);

/** @returns {Promise<{ method: 'emailjs' | 'mailto' }>} */
export async function sendContactMessage({ name, email, subject, message }) {
  if (!isEmailConfigured) {
    const body = `${message}\n\n— ${name} (${email})`;
    window.location.href = `mailto:${SITE.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    return { method: 'mailto' };
  }

  // Loaded only when needed, keeping it out of the main bundle.
  const emailjs = (await import('@emailjs/browser')).default;
  await emailjs.send(
    SERVICE_ID,
    TEMPLATE_ID,
    // These names must match the variables in your EmailJS template.
    { from_name: name, reply_to: email, subject, message, to_email: SITE.email },
    { publicKey: PUBLIC_KEY },
  );
  return { method: 'emailjs' };
}
