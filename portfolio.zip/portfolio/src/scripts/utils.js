/** Small, framework-free helpers shared across the app. */

/** Join class names, skipping falsy values. */
export const cn = (...classes) => classes.filter(Boolean).join(' ');

/** Estimated minutes to read a piece of text (200 words per minute). */
export function readingTime(text = '') {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
}

/** Format an ISO date (YYYY-MM-DD) like "1 Nov 2026". */
export function formatDate(iso) {
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

/** Turn any string into a URL/id-safe slug. */
export const slugify = (s = '') =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

/** Two-letter monogram for cards without an image (e.g. "Vue.js" -> "VU"). */
export const initials = (s = '') => s.replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase();

/** Case-insensitive "does any of these fields contain the query?" */
export function matchesQuery(query, ...fields) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  return fields.flat().some((f) => String(f ?? '').toLowerCase().includes(q));
}

/** Copy text to the clipboard, with a fallback for older browsers. */
export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}

/** Download a string as a file (used for "Download .md"). */
export function downloadText(filename, text, type = 'text/markdown') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** True when the user has asked the OS to reduce motion. */
export const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
