/** Validation rules for the contact form. Returns { field: message }. */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const INITIAL_FORM = { name: '', email: '', subject: '', message: '' };

export function validateField(name, value) {
  const v = value.trim();
  switch (name) {
    case 'name':
      if (!v) return 'Please enter your name.';
      if (v.length < 2) return 'Name should be at least 2 characters.';
      return '';
    case 'email':
      if (!v) return 'Please enter your email.';
      if (!EMAIL_RE.test(v)) return 'That email address doesn’t look right.';
      return '';
    case 'subject':
      if (!v) return 'Please add a subject.';
      if (v.length < 3) return 'Subject should be at least 3 characters.';
      return '';
    case 'message':
      if (!v) return 'Please write a message.';
      if (v.length < 10) return 'Message should be at least 10 characters.';
      if (v.length > 2000) return 'Message should be under 2000 characters.';
      return '';
    default:
      return '';
  }
}

export function validateForm(values) {
  const errors = {};
  Object.keys(INITIAL_FORM).forEach((key) => {
    const msg = validateField(key, values[key] ?? '');
    if (msg) errors[key] = msg;
  });
  return errors;
}
