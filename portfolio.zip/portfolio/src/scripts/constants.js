/**
 * Site-wide constants. Edit this file to change your name, contact details,
 * hero text, services and testimonials. Lists of projects, skills, articles
 * and experience live in src/data.
 */

export const SITE = {
  name: 'Pabitra Swain',
  shortName: 'PS',
  brand: 'Pabitraswain.in',
  tagline: 'MND',
  url: 'https://pabitraswain.vercel.app',
  email: 'ipsmnd3979@gmail.com',
  phone: '+91 7609050022',
  location: 'Odisha, India',
  available: true,
  resumeUrl: '/resume.pdf',
  avatar: '/images/profile.webp',
  title: 'UI/UX Designer & Frontend Developer',
  intro:
    'A UI/UX and Web Developer with over 3.5 years of experience developing client and server based web applications.',
  bio: [
    'I bridge the gap between aesthetic design and robust functionality. With 3.5+ years of experience in full-stack web development, I transform complex ideas into intuitive, high-performance digital experiences.',
    "My focus isn't just on writing code — it's on building seamless interfaces that engage users and drive business growth. From clean, responsive UI layouts to reliable server-side architecture, I bring technical precision and a designer's eye to every project.",
  ],
};

/** Roles cycled by the typing effect in the hero. */
export const TYPING_ROLES = ['Frontend Development', 'UI/UX Design', 'WordPress Builds'];

/** Headline numbers. `value` is animated from 0; `suffix` is appended. */
export const STATS = [
  { value: 3.5, suffix: '+', label: 'Years experience' },
  { value: 10, suffix: '+', label: 'Projects delivered' },
  { value: 10, suffix: '+', label: 'Tools in my stack' },
];

/** Things I like outside client work (shown on About). */
export const INTERESTS = [
  'Exploring new UI trends',
  'Writing framework guides',
  'Glassmorphism & bento layouts',
  'Photo editing',
  'Teaching through MND Code',
];

/** Services shown on Home and About. `icon` is a key in ServiceIcon. */
export const SERVICES = [
  { icon: 'code', title: 'Web Development', text: 'Custom client & server based web applications.', tone: 'from-primary-600 to-primary-900' },
  { icon: 'design', title: 'Web Design', text: 'Functional, user-first interface design.', tone: 'from-accent-500 to-[#3b2262]' },
  { icon: 'wordpress', title: 'WordPress', text: 'Custom themes, plugins & CMS builds.', tone: 'from-[#cf8a14] to-[#6a3d0b]' },
  { icon: 'support', title: 'Support', text: 'Ongoing updates, fixes & site maintenance.', tone: 'from-[#17a58c] to-[#0d4a4f]' },
];

export const TESTIMONIALS = [
  { quote: 'Highly satisfied with the final result, thank you!', name: 'Anita Rao', role: 'Verified Client' },
  {
    quote:
      "I absolutely love the design of this site. It's not only stylish but also very functional — it captures the brand identity perfectly.",
    name: 'Sonia & Robert',
    role: 'Studio Founders',
  },
  { quote: 'Prompt and helpful responses to every inquiry! Superb quality, genuinely impressed.', name: 'Matthew Smith', role: 'CEO, NebulaCo' },
  { quote: 'Incredible service. Perfectly exceeded expectations.', name: 'Aisha K.', role: 'Client Review' },
  { quote: 'Delivered on time with beautiful, pixel-perfect work.', name: 'Rahul M.', role: 'Startup Owner' },
  { quote: 'A true professional who understands design and code.', name: 'Priya S.', role: 'Product Manager' },
];

/** Main navigation. Order here is the order in the navbar. */
export const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/skills', label: 'Skills' },
  { to: '/projects', label: 'Projects' },
  { to: '/articles', label: 'Articles' },
  { to: '/experience', label: 'Experience' },
  { to: '/contact', label: 'Contact' },
];

export const THEME_STORAGE_KEY = 'ps-theme';
export const ARTICLES_PAGE_SIZE = 12;
