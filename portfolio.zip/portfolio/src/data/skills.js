/**
 * Skills, grouped by category. `level` (0–100) draws the progress bar;
 * leave it out to show the skill as an icon card instead (used for soft skills).
 * `icon` is a key in src/components/SkillBar.jsx -> SKILL_ICONS.
 */

export const SKILL_CATEGORIES = [
  { key: 'all', label: 'All' },
  { key: 'frontend', label: 'Frontend' },
  { key: 'backend', label: 'Backend & CMS' },
  { key: 'tools', label: 'Design Tools' },
  { key: 'soft', label: 'Soft Skills' },
];

const skills = [
  { name: 'HTML5 & CSS3', level: 90, category: 'frontend', icon: 'html' },
  { name: 'Bootstrap', level: 85, category: 'frontend', icon: 'bootstrap' },
  { name: 'JavaScript', level: 75, category: 'frontend', icon: 'js' },
  { name: 'jQuery', level: 75, category: 'frontend', icon: 'jquery' },
  { name: 'WordPress', level: 60, category: 'backend', icon: 'wordpress' },
  { name: 'JSON', level: 65, category: 'backend', icon: 'json' },
  { name: 'Photoshop', level: 90, category: 'tools', icon: 'photoshop' },
  { name: 'Figma', level: 75, category: 'tools', icon: 'figma' },
  { name: 'Illustrator', level: 65, category: 'tools', icon: 'illustrator' },
  { name: 'Client communication', category: 'soft', icon: 'chat' },
  { name: 'Design thinking', category: 'soft', icon: 'idea' },
  { name: 'Problem solving', category: 'soft', icon: 'puzzle' },
  { name: 'Time management', category: 'soft', icon: 'clock' },
];

/** UI design styles I work in (shown as tags). */
export const DESIGN_STYLES = [
  'Liquid Glass UI',
  'Bento Grid UI',
  'Spatial UI Design',
  'Claymorphism',
  'Neomorphism',
  'Glassmorphism',
  'Skeuomorphism',
  'Minimalism',
  'Maximalism',
  'Brutalism',
];

export default skills;
