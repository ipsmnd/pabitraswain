/**
 * Projects shown on /projects and Home.
 * Add a project by appending an object — nothing else needs to change.
 *
 * category: 'web' | 'ui'   (keys in PROJECT_CATEGORIES)
 * image:    path inside /public (keep images ~900px wide, .webp)
 * liveUrl / githubUrl: leave '' to hide that button.
 */

export const PROJECT_CATEGORIES = [
  { key: 'all', label: 'All' },
  { key: 'web', label: 'Website' },
  { key: 'ui', label: 'UI/UX' },
];

const projects = [
  {
    id: 'travel-io',
    title: 'Travel io',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/travel-io.webp',
    description: 'Immersive travel landing page with bold hero typography.',
    details:
      'A landing page for a travel brand built around one large, confident headline. Destination imagery carries the mood, while a short booking path keeps the call to action in view.',
    tech: ['Figma', 'HTML5', 'CSS3', 'JavaScript'],
    liveUrl: '',
    githubUrl: '',
    featured: true,
  },
  {
    id: 'banking-app',
    title: 'Banking App',
    category: 'ui',
    kind: 'UI/UX Design',
    image: '/images/projects/banking-app.webp',
    description: 'Mobile banking UI with balance, cards and sign-in screens.',
    details:
      'A set of mobile banking screens: sign-in, account balance and card management. The layout keeps the numbers people check most at the top and pushes secondary actions into clear, thumb-friendly buttons.',
    tech: ['Figma', 'Illustrator', 'Prototyping'],
    liveUrl: '',
    githubUrl: '',
    featured: true,
  },
  {
    id: 'nature-app-ui',
    title: 'Nature App UI',
    category: 'ui',
    kind: 'UI/UX Design',
    image: '/images/projects/nature-app-ui.webp',
    description: 'Colourful illustrated mobile app concept.',
    details:
      'An illustration-led mobile concept exploring a playful, colourful visual language with soft shapes and friendly typography.',
    tech: ['Figma', 'Illustrator'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'furniture-landing-page',
    title: 'Furniture Landing Page',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/furniture-landing-page.webp',
    description: 'Clean landing page for a furniture collection.',
    details:
      'A calm, product-first landing page for a furniture collection, with generous white space so each piece reads clearly.',
    tech: ['Figma', 'HTML5', 'CSS3', 'Bootstrap'],
    liveUrl: '',
    githubUrl: '',
    featured: true,
  },
  {
    id: 'webtech-developer',
    title: 'WebTech Developer',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/webtech-developer.webp',
    description: 'Hero-led developer website with a full-bleed photo.',
    details:
      'A personal brand site for a developer, led by a full-bleed hero photo and a short, direct introduction.',
    tech: ['HTML5', 'CSS3', 'JavaScript', 'Photoshop'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'baby-car-service',
    title: 'Baby Car Service',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/baby-car-service.webp',
    description: 'Responsive car service website shown across devices.',
    details:
      'A responsive service website designed to work equally well on phone, tablet and desktop, with booking information always one tap away.',
    tech: ['HTML5', 'CSS3', 'Bootstrap', 'jQuery'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'freshina',
    title: 'Freshina',
    category: 'ui',
    kind: 'UI/UX Design',
    image: '/images/projects/freshina.webp',
    description: 'Web application login UI for a milk & dairy platform.',
    details:
      'Web application UI for a milk and dairy products platform, starting with a clear, welcoming sign-in experience. Ongoing work since 2022.',
    tech: ['Figma', 'Photoshop'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'smartshopee',
    title: 'Smartshopee',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/smartshopee.webp',
    description: 'E-commerce website for mobile phones and accessories.',
    details:
      'E-commerce UI design and development for a phones and accessories store — product listings, filters and a straightforward checkout path.',
    tech: ['HTML5', 'CSS3', 'JavaScript', 'WordPress'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'login-portal',
    title: 'Login Portal',
    category: 'ui',
    kind: 'UI/UX Design',
    image: '/images/projects/login-portal.webp',
    description: 'Modern split-card login interface.',
    details: 'A split-card sign-in screen pairing a brand illustration with a focused, minimal form.',
    tech: ['Figma', 'HTML5', 'CSS3'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
  {
    id: 'hitesh-trading-co',
    title: 'Hitesh Trading Co.',
    category: 'web',
    kind: 'Website Design',
    image: '/images/projects/hitesh-trading-co.webp',
    description: 'Business website for a fabric trading company.',
    details:
      'A business website for a fabric trading company, presenting product ranges and contact details in a trustworthy, easy-to-scan layout.',
    tech: ['WordPress', 'CSS3', 'Photoshop'],
    liveUrl: '',
    githubUrl: '',
    featured: false,
  },
];

export default projects;
