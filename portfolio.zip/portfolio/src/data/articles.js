/**
 * Articles — the MND Code "Frontend Frameworks" library (56 guides).
 *
 * Each article is plain Markdown in `content`. To publish a new one, append an
 * object with the same shape; the list, search, tag filter and the
 * /articles/:slug page update automatically.
 *
 * Shape: { slug, title, excerpt, type, bestFor, officialUrl,
 *          category (key of ARTICLE_CATEGORIES), tags[], featured, date (YYYY-MM-DD), content }
 * Links like [Vue.js](#vue-js) inside content open the article with that slug.
 */

/** Category key -> display label + Tailwind gradient used for the generated cover. */
export const ARTICLE_CATEGORIES = {
  popular: { label: "Popular", cover: "from-primary-600 to-accent-700" },
  react: { label: "React", cover: "from-sky-500 to-blue-800" },
  vue: { label: "Vue", cover: "from-emerald-500 to-teal-800" },
  angular: { label: "Angular", cover: "from-rose-500 to-red-800" },
  svelte: { label: "Svelte", cover: "from-orange-500 to-amber-800" },
  css: { label: "CSS & UI", cover: "from-fuchsia-500 to-purple-800" },
  build: { label: "Build Tools", cover: "from-amber-500 to-yellow-800" },
};

const articles = [
  {
    "slug": "react-js",
    "title": "React.js",
    "excerpt": "Meta’s component-based library built on JSX and hooks.",
    "type": "UI library",
    "bestFor": "large apps with a huge ecosystem",
    "officialUrl": "https://react.dev",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": true,
    "date": "2026-11-20",
    "content": "# React.js\n\n> Meta’s component-based library built on JSX and hooks.\n\n| Field | Detail |\n|---|---|\n| Type | UI library |\n| Category | Popular frontend frameworks |\n| Best for | large apps with a huge ecosystem |\n| Official site | [react.dev](https://react.dev) |\n\n## Overview\n\nReact is the most widely used library for building user interfaces. You describe the UI as small, reusable components written in JSX, and React updates the page efficiently when your data changes. It focuses only on the view layer, so routing, data fetching and styling are chosen separately or provided by a framework such as Next.js.\n\n## Key features\n\n- **Components and JSX** — UI is built from functions that return HTML-like markup.\n- **Hooks** — `useState`, `useEffect` and friends add state and side effects to components.\n- **React Compiler** — automatically memoises components so you write less optimisation code.\n- **Server Components** — render parts of the UI on the server when used with a framework like Next.js.\n- **Huge ecosystem** — libraries exist for almost every need, and React Native reuses the same model for mobile.\n\n## Quick start\n\n```bash\nnpm create vite@latest my-app -- --template react\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```jsx\nimport { useState } from 'react';\n\nexport default function Counter() {\n  const [count, setCount] = useState(0);\n  return (\n    <button onClick={() => setCount(count + 1)}>\n      Clicked {count} times\n    </button>\n  );\n}\n```\n\n## When to choose it\n\n- You want the largest job market and the most third-party libraries.\n- You plan to share skills between web and mobile (React Native / Expo).\n\n## Think twice if\n\n- You want routing, forms and HTTP built in — React leaves those choices to you.\n\n## Related\n\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://react.dev).*\n"
  },
  {
    "slug": "angular",
    "title": "Angular",
    "excerpt": "Google’s TypeScript-first, batteries-included application framework.",
    "type": "framework",
    "bestFor": "enterprise-scale apps",
    "officialUrl": "https://angular.dev",
    "category": "popular",
    "tags": [
      "Popular",
      "Angular"
    ],
    "featured": true,
    "date": "2026-11-18",
    "content": "# Angular\n\n> Google’s TypeScript-first, batteries-included application framework.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks · Angular ecosystem |\n| Best for | enterprise-scale apps |\n| Official site | [angular.dev](https://angular.dev) |\n\n## Overview\n\nAngular is Google's complete, TypeScript-first framework. It ships with a router, forms, an HTTP client, dependency injection, testing tools and a powerful CLI, so large teams can work in one consistent structure. Modern Angular uses standalone components and Signals for fast, fine-grained reactivity.\n\n## Key features\n\n- **Batteries included** — router, forms, HttpClient, animations and i18n are official packages.\n- **Signals** — simple reactive values that update only what changed.\n- **Angular CLI** — generates components, services and builds with one command.\n- **Dependency injection** — clean, testable services shared across the app.\n- **SSR and hydration** — server rendering via `@angular/ssr`.\n\n## Quick start\n\n```bash\nnpm install -g @angular/cli\nng new my-app\ncd my-app\nng serve\n```\n\n## Example\n\n```ts\nimport { Component, signal } from '@angular/core';\n\n@Component({\n  selector: 'app-counter',\n  template: `<button (click)=\"count.set(count() + 1)\">\n    Clicked {{ count() }} times\n  </button>`,\n})\nexport class Counter {\n  count = signal(0);\n}\n```\n\n## When to choose it\n\n- You are building a large, long-lived enterprise application with many developers.\n- You like having one official way to do routing, forms and testing.\n\n## Think twice if\n\n- You need a tiny bundle for a simple marketing page.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://angular.dev).*\n"
  },
  {
    "slug": "vue-js",
    "title": "Vue.js",
    "excerpt": "Progressive framework with approachable templates and reactivity.",
    "type": "framework",
    "bestFor": "a gentle learning curve",
    "officialUrl": "https://vuejs.org",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": true,
    "date": "2026-11-17",
    "content": "# Vue.js\n\n> Progressive framework with approachable templates and reactivity.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | a gentle learning curve |\n| Official site | [vuejs.org](https://vuejs.org) |\n\n## Overview\n\nVue is a progressive framework: you can drop it into one page or build a full single-page app with it. Single-File Components keep template, logic and styles together, and its reactivity system tracks changes automatically. Many developers find Vue the easiest of the big frameworks to learn.\n\n## Key features\n\n- **Single-File Components** — `.vue` files hold template, script and style in one place.\n- **Composition API and Options API** — choose the style that suits your team.\n- **Automatic reactivity** — `ref()` and `reactive()` update the DOM when values change.\n- **Official tools** — Vue Router, Pinia for state, and Vite for builds.\n\n## Quick start\n\n```bash\nnpm create vue@latest\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```vue\n<script setup>\nimport { ref } from 'vue'\nconst count = ref(0)\n</script>\n\n<template>\n  <button @click=\"count++\">Clicked {{ count }} times</button>\n</template>\n```\n\n## When to choose it\n\n- You want a gentle learning curve with HTML-like templates.\n- You want to add interactivity to an existing site step by step.\n\n## Think twice if\n\n- Your team already has deep React experience and a React component library.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vuejs.org).*\n"
  },
  {
    "slug": "svelte",
    "title": "Svelte",
    "excerpt": "Compiler-based framework that ships very little runtime code.",
    "type": "framework",
    "bestFor": "small, fast bundles",
    "officialUrl": "https://svelte.dev",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": true,
    "date": "2026-11-16",
    "content": "# Svelte\n\n> Compiler-based framework that ships very little runtime code.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | small, fast bundles |\n| Official site | [svelte.dev](https://svelte.dev) |\n\n## Overview\n\nSvelte is a compiler. Instead of shipping a large runtime to the browser, it turns your components into small, efficient JavaScript at build time. Svelte 5 introduced *runes* such as `$state` and `$derived`, which make reactivity explicit and easy to read.\n\n## Key features\n\n- **Compile-time framework** — very little framework code reaches the browser.\n- **Runes** — `$state`, `$derived` and `$effect` for clear reactivity.\n- **Scoped CSS by default** — styles in a component never leak out.\n- **Built-in transitions and animations**.\n\n## Quick start\n\n```bash\nnpx sv create my-app\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```svelte\n<script>\n  let count = $state(0);\n</script>\n\n<button onclick={() => count++}>\n  Clicked {count} times\n</button>\n```\n\n## When to choose it\n\n- You want small bundles and very little boilerplate.\n- You enjoy writing close to plain HTML, CSS and JavaScript.\n\n## Think twice if\n\n- You need the biggest possible library ecosystem or hiring pool.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://svelte.dev).*\n"
  },
  {
    "slug": "solidjs",
    "title": "SolidJS",
    "excerpt": "Fine-grained reactivity with JSX and no virtual DOM.",
    "type": "UI library",
    "bestFor": "top-tier runtime performance",
    "officialUrl": "https://www.solidjs.com",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-10",
    "content": "# SolidJS\n\n> Fine-grained reactivity with JSX and no virtual DOM.\n\n| Field | Detail |\n|---|---|\n| Type | UI library |\n| Category | Popular frontend frameworks |\n| Best for | top-tier runtime performance |\n| Official site | [solidjs.com](https://www.solidjs.com) |\n\n## Overview\n\nSolidJS looks like React — JSX and familiar function components — but works very differently underneath. Components run only once, and fine-grained *signals* update exactly the DOM nodes that depend on them, with no virtual DOM. This makes Solid one of the fastest UI libraries in benchmarks.\n\n## Key features\n\n- **Signals** — `createSignal` and `createMemo` drive precise updates.\n- **No virtual DOM** — direct, surgical DOM updates.\n- **JSX** — easy move for React developers.\n- **SolidStart** — official meta-framework for routing and SSR.\n\n## Quick start\n\n```bash\nnpm create solid@latest\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```jsx\nimport { createSignal } from 'solid-js';\n\nfunction Counter() {\n  const [count, setCount] = createSignal(0);\n  return (\n    <button onClick={() => setCount(count() + 1)}>\n      Clicked {count()} times\n    </button>\n  );\n}\n```\n\n## When to choose it\n\n- Runtime performance is a top priority.\n- You like JSX but want simpler, more predictable reactivity.\n\n## Think twice if\n\n- You rely on React-only libraries — they will not work directly.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.solidjs.com).*\n"
  },
  {
    "slug": "qwik",
    "title": "Qwik",
    "excerpt": "Resumable framework that loads JavaScript only when needed.",
    "type": "framework",
    "bestFor": "instant startup on slow devices",
    "officialUrl": "https://qwik.dev",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-09",
    "content": "# Qwik\n\n> Resumable framework that loads JavaScript only when needed.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | instant startup on slow devices |\n| Official site | [qwik.dev](https://qwik.dev) |\n\n## Overview\n\nQwik is built for instant page loads. Its key idea is *resumability*: the server sends HTML plus a tiny loader, and the browser downloads the JavaScript for an interaction only when the user actually triggers it. There is no expensive hydration step on start-up.\n\n## Key features\n\n- **Resumability** — no hydration; the app resumes where the server left off.\n- **Lazy loading by default** — the `$` suffix marks code that can be loaded on demand.\n- **Qwik City** — file-based routing, loaders and actions.\n- **JSX syntax** — familiar to React developers.\n\n## Quick start\n\n```bash\nnpm create qwik@latest\ncd my-app\nnpm start\n```\n\n## Example\n\n```tsx\nimport { component$, useSignal } from '@builder.io/qwik';\n\nexport default component$(() => {\n  const count = useSignal(0);\n  return (\n    <button onClick$={() => count.value++}>\n      Clicked {count.value} times\n    </button>\n  );\n});\n```\n\n## When to choose it\n\n- Your users are on slow phones or networks and start-up speed matters most.\n- You are building content-heavy e-commerce or marketing sites.\n\n## Think twice if\n\n- You need a mature ecosystem of ready-made components.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Preact](#preact) — A roughly 3 KB, React-compatible alternative.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://qwik.dev).*\n"
  },
  {
    "slug": "preact",
    "title": "Preact",
    "excerpt": "A roughly 3 KB, React-compatible alternative.",
    "type": "UI library",
    "bestFor": "React APIs at tiny size",
    "officialUrl": "https://preactjs.com",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-08",
    "content": "# Preact\n\n> A roughly 3 KB, React-compatible alternative.\n\n| Field | Detail |\n|---|---|\n| Type | UI library |\n| Category | Popular frontend frameworks |\n| Best for | React APIs at tiny size |\n| Official site | [preactjs.com](https://preactjs.com) |\n\n## Overview\n\nPreact is a fast, roughly 3 KB alternative to React with the same modern API. With the `preact/compat` layer, many React libraries work unchanged. It is popular for widgets, embedded apps and sites where every kilobyte counts.\n\n## Key features\n\n- **Tiny size** — about 3 KB gzipped.\n- **React-compatible API** — hooks, components and JSX.\n- **preact/compat** — run many React packages as they are.\n- **Preact Signals** — optional fine-grained reactive state.\n\n## Quick start\n\n```bash\nnpm init preact\ncd my-app\nnpm run dev\n```\n\n## Example\n\n```jsx\nimport { useState } from 'preact/hooks';\n\nexport function Counter() {\n  const [count, setCount] = useState(0);\n  return (\n    <button onClick={() => setCount(count + 1)}>\n      Clicked {count} times\n    </button>\n  );\n}\n```\n\n## When to choose it\n\n- You want React skills with a much smaller bundle.\n- You are building an embeddable widget for other people's websites.\n\n## Think twice if\n\n- You depend on newest React-only features such as Server Components.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://preactjs.com).*\n"
  },
  {
    "slug": "ember-js",
    "title": "Ember.js",
    "excerpt": "Convention-over-configuration framework for ambitious web apps.",
    "type": "framework",
    "bestFor": "long-lived, stable products",
    "officialUrl": "https://emberjs.com",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-07",
    "content": "# Ember.js\n\n> Convention-over-configuration framework for ambitious web apps.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | long-lived, stable products |\n| Official site | [emberjs.com](https://emberjs.com) |\n\n## Overview\n\nEmber is a convention-over-configuration framework for ambitious web apps. It provides a full stack of tools — router, data layer, testing and a CLI — and follows a strict release cycle with long-term-support versions, so apps can stay healthy for many years.\n\n## Key features\n\n- **Ember CLI** — generators, builds and testing out of the box.\n- **Strong conventions** — every Ember app has a familiar structure.\n- **Glimmer components** with `@tracked` state.\n- **LTS releases** — predictable, stable upgrades.\n\n## Quick start\n\n```bash\nnpx ember-cli new my-app\ncd my-app\nnpm start\n```\n\n## Example\n\n```js\nimport Component from '@glimmer/component';\nimport { tracked } from '@glimmer/tracking';\nimport { on } from '@ember/modifier';\n\nexport default class Counter extends Component {\n  @tracked count = 0;\n  increment = () => this.count++;\n\n  <template>\n    <button {{on \"click\" this.increment}}>Clicked {{this.count}} times</button>\n  </template>\n}\n```\n\n## When to choose it\n\n- You value stability and clear conventions over flexibility.\n- You maintain a large app that must live for many years.\n\n## Think twice if\n\n- You are learning your first framework — the job market is smaller.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://emberjs.com).*\n"
  },
  {
    "slug": "alpine-js",
    "title": "Alpine.js",
    "excerpt": "Lightweight interactivity written as HTML attributes.",
    "type": "UI library",
    "bestFor": "sprinkling behaviour on server-rendered pages",
    "officialUrl": "https://alpinejs.dev",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-06",
    "content": "# Alpine.js\n\n> Lightweight interactivity written as HTML attributes.\n\n| Field | Detail |\n|---|---|\n| Type | UI library |\n| Category | Popular frontend frameworks |\n| Best for | sprinkling behaviour on server-rendered pages |\n| Official site | [alpinejs.dev](https://alpinejs.dev) |\n\n## Overview\n\nAlpine.js adds interactivity directly in your HTML using attributes like `x-data`, `x-show` and `@click`. There is no build step — just add one script tag. It is ideal for dropdowns, tabs, modals and small widgets on server-rendered pages (Laravel, Django, WordPress, static HTML).\n\n## Key features\n\n- **No build step** — include one script and start.\n- **HTML attributes** — `x-data`, `x-bind`, `x-on`, `x-model`, `x-for`.\n- **Very small** — around 15 KB.\n- **Pairs well with htmx and Tailwind CSS**.\n\n## Quick start\n\n```html\n<script defer src=\"https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js\"></script>\n```\n\n## Example\n\n```html\n<div x-data=\"{ count: 0, open: false }\">\n  <button @click=\"count++\">Clicked <span x-text=\"count\"></span> times</button>\n\n  <button @click=\"open = !open\">Toggle menu</button>\n  <ul x-show=\"open\"><li>Home</li><li>About</li></ul>\n</div>\n```\n\n## When to choose it\n\n- Your pages are rendered by a server or CMS and need a little interactivity.\n- You want to avoid a JavaScript build pipeline.\n\n## Think twice if\n\n- You are building a large single-page application.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://alpinejs.dev).*\n"
  },
  {
    "slug": "lit",
    "title": "Lit",
    "excerpt": "Small library for building standards-based web components.",
    "type": "UI library",
    "bestFor": "framework-agnostic components",
    "officialUrl": "https://lit.dev",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-05",
    "content": "# Lit\n\n> Small library for building standards-based web components.\n\n| Field | Detail |\n|---|---|\n| Type | UI library |\n| Category | Popular frontend frameworks |\n| Best for | framework-agnostic components |\n| Official site | [lit.dev](https://lit.dev) |\n\n## Overview\n\nLit is a small library from Google for building fast, standard Web Components. Components made with Lit are real custom HTML elements, so they work in plain HTML and inside React, Vue, Angular or any other framework.\n\n## Key features\n\n- **Standards-based** — builds on Custom Elements and Shadow DOM.\n- **Reactive properties** — re-render when values change.\n- **Tagged template literals** — `html` templates with no compiler needed.\n- **Small** — about 5 KB.\n\n## Quick start\n\n```bash\nnpm install lit\n```\n\n## Example\n\n```js\nimport { LitElement, html } from 'lit';\n\nclass MyCounter extends LitElement {\n  static properties = { count: { type: Number } };\n  constructor() { super(); this.count = 0; }\n  render() {\n    return html`<button @click=${() => this.count++}>\n      Clicked ${this.count} times</button>`;\n  }\n}\ncustomElements.define('my-counter', MyCounter);\n```\n\n## When to choose it\n\n- You need components that work in any framework or in plain HTML.\n- You are building a design system shared by several teams.\n\n## Think twice if\n\n- You want a full app framework with routing and data loading.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://lit.dev).*\n"
  },
  {
    "slug": "mithril-js",
    "title": "Mithril.js",
    "excerpt": "Tiny SPA framework with routing and XHR built in.",
    "type": "framework",
    "bestFor": "minimal, fast single-page apps",
    "officialUrl": "https://mithril.js.org",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-04",
    "content": "# Mithril.js\n\n> Tiny SPA framework with routing and XHR built in.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | minimal, fast single-page apps |\n| Official site | [mithril.js.org](https://mithril.js.org) |\n\n## Overview\n\nMithril is a tiny client-side framework (around 10 KB) that still includes routing and an HTTP request utility. Its API is small enough to learn in an afternoon, and it uses a fast virtual DOM.\n\n## Key features\n\n- **Small and complete** — virtual DOM, router and XHR in one package.\n- **Hyperscript** — `m('div', ...)` or optional JSX.\n- **Automatic redraws** after events and requests.\n\n## Quick start\n\n```bash\nnpm install mithril\n```\n\n## Example\n\n```js\nimport m from 'mithril';\n\nlet count = 0;\nconst Counter = {\n  view: () => m('button', { onclick: () => count++ },\n    `Clicked ${count} times`)\n};\n\nm.mount(document.body, Counter);\n```\n\n## When to choose it\n\n- You want a full SPA toolkit with a very small footprint.\n- You prefer plain JavaScript over a big framework.\n\n## Think twice if\n\n- You need lots of community component libraries.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mithril.js.org).*\n"
  },
  {
    "slug": "marko",
    "title": "Marko",
    "excerpt": "HTML-based language with streaming server rendering.",
    "type": "framework",
    "bestFor": "content-heavy, fast-loading sites",
    "officialUrl": "https://markojs.com",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-03",
    "content": "# Marko\n\n> HTML-based language with streaming server rendering.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | content-heavy, fast-loading sites |\n| Official site | [markojs.com](https://markojs.com) |\n\n## Overview\n\nMarko is an HTML-based UI language created at eBay. It streams HTML from the server as soon as parts are ready and sends only the JavaScript needed for interactive parts. Marko 6 introduced a simpler *Tags API*.\n\n## Key features\n\n- **HTML-first syntax** — templates look like enhanced HTML.\n- **Streaming SSR** — users see content sooner.\n- **Partial hydration** — only interactive parts ship JavaScript.\n- **Proven at scale** — powers eBay.\n\n## Quick start\n\n```bash\nnpm init marko\ncd my-app\nnpm run dev\n```\n\n## Example\n\n```html\n<let/count=0>\n\n<button onClick() { count++ }>\n  Clicked ${count} times\n</button>\n```\n\n## When to choose it\n\n- You build content-heavy, high-traffic sites where load speed matters.\n- You like writing templates that look like HTML.\n\n## Think twice if\n\n- You need a large hiring pool or many ready-made UI kits.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://markojs.com).*\n"
  },
  {
    "slug": "aurelia",
    "title": "Aurelia",
    "excerpt": "Standards-focused framework with convention-based binding.",
    "type": "framework",
    "bestFor": "clean, plain-JavaScript classes",
    "officialUrl": "https://aurelia.io",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-02",
    "content": "# Aurelia\n\n> Standards-focused framework with convention-based binding.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Popular frontend frameworks |\n| Best for | clean, plain-JavaScript classes |\n| Official site | [aurelia.io](https://aurelia.io) |\n\n## Overview\n\nAurelia is a standards-focused framework where your components are plain JavaScript or TypeScript classes with HTML templates. Its convention-based binding means very little framework-specific code. Aurelia 2 is the current major version.\n\n## Key features\n\n- **Plain classes** — little framework code inside your components.\n- **Two-way binding** with clear syntax like `value.bind` and `click.trigger`.\n- **Dependency injection and router** included.\n- **Standards-based** — uses modern web APIs.\n\n## Quick start\n\n```bash\nnpx makes aurelia\ncd my-app\nnpm start\n```\n\n## Example\n\n```html\n<!-- my-app.ts:  export class MyApp { count = 0; increment() { this.count++; } } -->\n\n<button click.trigger=\"increment()\">\n  Clicked ${count} times\n</button>\n```\n\n## When to choose it\n\n- You want clean, framework-light code.\n- Your team likes conventions and two-way binding.\n\n## Think twice if\n\n- You need a large community and many tutorials.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://aurelia.io).*\n"
  },
  {
    "slug": "backbone-js",
    "title": "Backbone.js",
    "excerpt": "Minimal MVC-style structure with models and views; now mostly legacy.",
    "type": "library",
    "bestFor": "maintaining older codebases",
    "officialUrl": "https://backbonejs.org",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-11-01",
    "content": "# Backbone.js\n\n> Minimal MVC-style structure with models and views; now mostly legacy.\n\n| Field | Detail |\n|---|---|\n| Type | library |\n| Category | Popular frontend frameworks |\n| Best for | maintaining older codebases |\n| Official site | [backbonejs.org](https://backbonejs.org) |\n\n## Overview\n\nBackbone.js was one of the first popular JavaScript MVC libraries. It gives structure with Models, Collections, Views and a Router, and depends on Underscore.js (and usually jQuery). Today it is mostly found in older, still-running codebases.\n\n> **Status note:** Backbone receives very few updates today. Use it for maintenance, not for new apps.\n\n## Key features\n\n- **Models and Collections** with change events.\n- **Views** that listen to models and re-render.\n- **Router** for hash or history URLs.\n- **Very small and simple**.\n\n## Quick start\n\n```bash\nnpm install backbone underscore jquery\n```\n\n## Example\n\n```js\nconst Counter = Backbone.Model.extend({ defaults: { count: 0 } });\n\nconst CounterView = Backbone.View.extend({\n  events: { click: 'inc' },\n  initialize() { this.listenTo(this.model, 'change', this.render); },\n  inc() { this.model.set('count', this.model.get('count') + 1); },\n  render() { this.$el.text(`Clicked ${this.model.get('count')} times`); return this; }\n});\n```\n\n## When to choose it\n\n- You maintain or extend an existing Backbone application.\n- You want to understand where modern MVC frameworks came from.\n\n## Think twice if\n\n- You are starting a new project — choose a modern framework instead.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://backbonejs.org).*\n"
  },
  {
    "slug": "stencil",
    "title": "Stencil",
    "excerpt": "Compiler that generates web components, from the Ionic team.",
    "type": "compiler",
    "bestFor": "design systems shipped as web components",
    "officialUrl": "https://stenciljs.com",
    "category": "popular",
    "tags": [
      "Popular"
    ],
    "featured": false,
    "date": "2026-10-31",
    "content": "# Stencil\n\n> Compiler that generates web components, from the Ionic team.\n\n| Field | Detail |\n|---|---|\n| Type | compiler |\n| Category | Popular frontend frameworks |\n| Best for | design systems shipped as web components |\n| Official site | [stenciljs.com](https://stenciljs.com) |\n\n## Overview\n\nStencil is a compiler from the Ionic team that turns TypeScript and JSX components into standard Web Components. It adds lazy loading and framework wrappers, which makes it popular for company design systems that must work in React, Angular and Vue at the same time.\n\n## Key features\n\n- **Outputs standard Web Components**.\n- **TypeScript + JSX** authoring with decorators.\n- **Lazy loading** of components.\n- **Framework output targets** — wrappers for React, Angular and Vue.\n\n## Quick start\n\n```bash\nnpm init stencil\ncd my-components\nnpm start\n```\n\n## Example\n\n```tsx\nimport { Component, State, h } from '@stencil/core';\n\n@Component({ tag: 'my-counter' })\nexport class MyCounter {\n  @State() count = 0;\n  render() {\n    return <button onClick={() => this.count++}>Clicked {this.count} times</button>;\n  }\n}\n```\n\n## When to choose it\n\n- You are building a design system used by teams on different frameworks.\n\n## Think twice if\n\n- You are building one normal web app — a regular framework is simpler.\n\n## Related\n\n- [React.js](#react-js) — Meta’s component-based library built on JSX and hooks.\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Vue.js](#vue-js) — Progressive framework with approachable templates and reactivity.\n- [Svelte](#svelte) — Compiler-based framework that ships very little runtime code.\n- [SolidJS](#solidjs) — Fine-grained reactivity with JSX and no virtual DOM.\n- [Qwik](#qwik) — Resumable framework that loads JavaScript only when needed.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://stenciljs.com).*\n"
  },
  {
    "slug": "next-js",
    "title": "Next.js",
    "excerpt": "Vercel’s full-stack React framework with SSR, SSG and the App Router.",
    "type": "meta-framework",
    "bestFor": "production React websites",
    "officialUrl": "https://nextjs.org",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": true,
    "date": "2026-11-19",
    "content": "# Next.js\n\n> Vercel’s full-stack React framework with SSR, SSG and the App Router.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | React-based frameworks |\n| Best for | production React websites |\n| Official site | [nextjs.org](https://nextjs.org) |\n\n## Overview\n\nNext.js, made by Vercel, is the most popular full-stack framework for React. It adds file-based routing, server rendering, static generation, API routes and image optimisation. The App Router is built around React Server Components, so data can be fetched directly inside components on the server.\n\n## Key features\n\n- **App Router** — folders in `app/` become routes, with layouts and loading states.\n- **Server Components and Server Actions** — fetch data and handle forms on the server.\n- **SSR, SSG and ISR** — choose rendering per page.\n- **Built-in optimisation** — images, fonts and scripts.\n- **Turbopack** — fast Rust-based bundler for dev and builds.\n\n## Quick start\n\n```bash\nnpx create-next-app@latest my-app\ncd my-app\nnpm run dev\n```\n\n## Example\n\n```tsx\n// app/page.tsx — a Server Component\nexport default async function Page() {\n  const res = await fetch('https://api.example.com/posts');\n  const posts = await res.json();\n  return (\n    <ul>\n      {posts.map((p) => <li key={p.id}>{p.title}</li>)}\n    </ul>\n  );\n}\n```\n\n## When to choose it\n\n- You want a production-ready React website with good SEO.\n- You plan to deploy to Vercel or any Node.js host.\n\n## Think twice if\n\n- You only need a small client-side widget — plain React with Vite is lighter.\n\n## Related\n\n- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.\n- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.\n- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.\n- [React Router](#react-router) — The standard React router, with a framework mode since v7.\n- [Expo](#expo) — Toolchain and platform for building React Native apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nextjs.org).*\n"
  },
  {
    "slug": "remix",
    "title": "Remix",
    "excerpt": "Web-standards React framework whose features now live in React Router v7.",
    "type": "meta-framework",
    "bestFor": "data-loading-first apps",
    "officialUrl": "https://remix.run",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": false,
    "date": "2026-10-30",
    "content": "# Remix\n\n> Web-standards React framework whose features now live in React Router v7.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | React-based frameworks |\n| Best for | data-loading-first apps |\n| Official site | [remix.run](https://remix.run) |\n\n## Overview\n\nRemix is a React framework built on web standards — HTML forms, HTTP caching and the Fetch API. Its best ideas (nested routes, `loader` and `action` functions) were merged into React Router v7, so Remix-style apps are now built with React Router's *framework mode*. The Remix team is working on a new, separate Remix 3.\n\n> **Status note:** Remix v2 features now live in React Router v7. Check remix.run for the latest on Remix 3.\n\n## Key features\n\n- **Nested routing** — each route segment loads its own data.\n- **Loaders and actions** — server functions for reading and writing data.\n- **Progressive enhancement** — forms work even before JavaScript loads.\n- **Web-standard APIs** — Request, Response and FormData.\n\n## Quick start\n\n```bash\nnpx create-react-router@latest my-app\ncd my-app\nnpm run dev\n```\n\n## Example\n\n```tsx\n// app/routes/user.tsx\nexport async function loader({ params }) {\n  return { user: await getUser(params.id) };\n}\n\nexport default function User({ loaderData }) {\n  return <h1>{loaderData.user.name}</h1>;\n}\n```\n\n## When to choose it\n\n- You like web-standard, form-driven data flows.\n- You are maintaining a Remix v2 app or upgrading it to React Router v7.\n\n## Think twice if\n\n- You expect the classic Remix package to be the long-term path — new apps should start on React Router.\n\n## Related\n\n- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.\n- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.\n- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.\n- [React Router](#react-router) — The standard React router, with a framework mode since v7.\n- [Expo](#expo) — Toolchain and platform for building React Native apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://remix.run).*\n"
  },
  {
    "slug": "gatsby",
    "title": "Gatsby",
    "excerpt": "React static-site generator built around a GraphQL data layer.",
    "type": "static site generator",
    "bestFor": "content sites with many data sources",
    "officialUrl": "https://www.gatsbyjs.com",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": false,
    "date": "2026-10-29",
    "content": "# Gatsby\n\n> React static-site generator built around a GraphQL data layer.\n\n| Field | Detail |\n|---|---|\n| Type | static site generator |\n| Category | React-based frameworks |\n| Best for | content sites with many data sources |\n| Official site | [gatsbyjs.com](https://www.gatsbyjs.com) |\n\n## Overview\n\nGatsby is a React-based static-site generator. It pulls content from Markdown, CMSs and APIs into a single GraphQL data layer, then builds fast static pages with image optimisation and a large plugin library.\n\n> **Status note:** Development has slowed a lot since Netlify acquired Gatsby in 2023.\n\n## Key features\n\n- **GraphQL data layer** — query any data source the same way.\n- **Plugin ecosystem** — sources, images, SEO, PWA.\n- **Static output** — fast and easy to host on a CDN.\n\n## Quick start\n\n```bash\nnpm init gatsby\ncd my-site\nnpm run develop\n```\n\n## Example\n\n```jsx\nimport { graphql } from 'gatsby';\n\nexport default function Blog({ data }) {\n  return data.allMarkdownRemark.nodes.map(n => <h2 key={n.id}>{n.frontmatter.title}</h2>);\n}\n\nexport const query = graphql`\n  query { allMarkdownRemark { nodes { id frontmatter { title } } } }\n`;\n```\n\n## When to choose it\n\n- You maintain an existing Gatsby site.\n- You need to combine many content sources into one static site.\n\n## Think twice if\n\n- You are starting fresh — Next.js or Astro are more actively developed today.\n\n## Related\n\n- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.\n- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.\n- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.\n- [React Router](#react-router) — The standard React router, with a framework mode since v7.\n- [Expo](#expo) — Toolchain and platform for building React Native apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.gatsbyjs.com).*\n"
  },
  {
    "slug": "redwoodjs",
    "title": "RedwoodJS",
    "excerpt": "Opinionated full-stack framework combining React, GraphQL and Prisma.",
    "type": "meta-framework",
    "bestFor": "startups wanting one integrated stack",
    "officialUrl": "https://redwoodjs.com",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": false,
    "date": "2026-10-28",
    "content": "# RedwoodJS\n\n> Opinionated full-stack framework combining React, GraphQL and Prisma.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | React-based frameworks |\n| Best for | startups wanting one integrated stack |\n| Official site | [redwoodjs.com](https://redwoodjs.com) |\n\n## Overview\n\nRedwoodJS is an opinionated full-stack framework that combines React, GraphQL and Prisma in one project, with generators for pages, services and database models. Its *Cells* pattern handles loading, empty, error and success states for data automatically.\n\n> **Status note:** The core team has shifted focus to the newer RedwoodSDK; check redwoodjs.com for the current status of each project.\n\n## Key features\n\n- **Full-stack in one repo** — `web` and `api` sides.\n- **Cells** — declarative data fetching with built-in states.\n- **Prisma** for the database, **GraphQL** for the API.\n- **Generators** — scaffold CRUD pages in seconds.\n\n## Quick start\n\n```bash\nyarn create redwood-app my-app\ncd my-app\nyarn rw dev\n```\n\n## Example\n\n```jsx\n// web/src/components/PostsCell.jsx\nexport const QUERY = gql`query { posts { id title } }`;\n\nexport const Loading = () => <div>Loading…</div>;\nexport const Empty = () => <div>No posts yet</div>;\nexport const Success = ({ posts }) => (\n  <ul>{posts.map(p => <li key={p.id}>{p.title}</li>)}</ul>\n);\n```\n\n## When to choose it\n\n- A startup team wants one integrated, opinionated stack.\n\n## Think twice if\n\n- You don't want GraphQL in your app.\n\n## Related\n\n- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.\n- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.\n- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.\n- [React Router](#react-router) — The standard React router, with a framework mode since v7.\n- [Expo](#expo) — Toolchain and platform for building React Native apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://redwoodjs.com).*\n"
  },
  {
    "slug": "react-router",
    "title": "React Router",
    "excerpt": "The standard React router, with a framework mode since v7.",
    "type": "routing library",
    "bestFor": "client-side routing and data loading",
    "officialUrl": "https://reactrouter.com",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": false,
    "date": "2026-10-27",
    "content": "# React Router\n\n> The standard React router, with a framework mode since v7.\n\n| Field | Detail |\n|---|---|\n| Type | routing library |\n| Category | React-based frameworks |\n| Best for | client-side routing and data loading |\n| Official site | [reactrouter.com](https://reactrouter.com) |\n\n## Overview\n\nReact Router is the standard routing library for React. Since version 7 it works in three modes: *declarative* (simple `<Routes>`), *data* (loaders and actions) and *framework* (full Remix-style app with SSR and file-based route config).\n\n## Key features\n\n- **Nested routes and layouts**.\n- **Loaders and actions** for data in data and framework modes.\n- **Framework mode** — SSR, code splitting and type-safe routes.\n- **URL params, search params and navigation hooks**.\n\n## Quick start\n\n```bash\nnpm install react-router\n```\n\n## Example\n\n```jsx\nimport { createBrowserRouter, RouterProvider } from 'react-router';\n\nconst router = createBrowserRouter([\n  { path: '/', element: <Home /> },\n  { path: '/users/:id', element: <User />,\n    loader: ({ params }) => getUser(params.id) },\n]);\n\nroot.render(<RouterProvider router={router} />);\n```\n\n## When to choose it\n\n- You build a React SPA and need routing.\n- You want Remix-style data loading without Next.js.\n\n## Think twice if\n\n- You already use Next.js — it has its own router.\n\n## Related\n\n- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.\n- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.\n- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.\n- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.\n- [Expo](#expo) — Toolchain and platform for building React Native apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://reactrouter.com).*\n"
  },
  {
    "slug": "expo",
    "title": "Expo",
    "excerpt": "Toolchain and platform for building React Native apps.",
    "type": "mobile toolkit",
    "bestFor": "iOS, Android and web from one codebase",
    "officialUrl": "https://expo.dev",
    "category": "react",
    "tags": [
      "React"
    ],
    "featured": false,
    "date": "2026-10-26",
    "content": "# Expo\n\n> Toolchain and platform for building React Native apps.\n\n| Field | Detail |\n|---|---|\n| Type | mobile toolkit |\n| Category | React-based frameworks |\n| Best for | iOS, Android and web from one codebase |\n| Official site | [expo.dev](https://expo.dev) |\n\n## Overview\n\nExpo is a framework and platform for React Native. It lets you build iOS, Android and web apps from one JavaScript/TypeScript codebase, test instantly on your phone with Expo Go, and build or update apps in the cloud with EAS.\n\n## Key features\n\n- **Expo Router** — file-based navigation for mobile and web.\n- **Expo SDK** — camera, notifications, location and more.\n- **EAS Build and Update** — cloud builds and over-the-air updates.\n- **Expo Go** — preview on a real device without Xcode or Android Studio.\n\n## Quick start\n\n```bash\nnpx create-expo-app@latest my-app\ncd my-app\nnpx expo start\n```\n\n## Example\n\n```tsx\nimport { Text, View, Pressable } from 'react-native';\nimport { useState } from 'react';\n\nexport default function Home() {\n  const [count, setCount] = useState(0);\n  return (\n    <View style={{ padding: 40 }}>\n      <Pressable onPress={() => setCount(count + 1)}>\n        <Text>Tapped {count} times</Text>\n      </Pressable>\n    </View>\n  );\n}\n```\n\n## When to choose it\n\n- You know React and want to ship real mobile apps.\n- You want one codebase for iOS, Android and web.\n\n## Think twice if\n\n- Your app needs heavy custom native code from day one (still possible, but more work).\n\n## Related\n\n- [Next.js](#next-js) — Vercel’s full-stack React framework with SSR, SSG and the App Router.\n- [Remix](#remix) — Web-standards React framework whose features now live in React Router v7.\n- [Gatsby](#gatsby) — React static-site generator built around a GraphQL data layer.\n- [RedwoodJS](#redwoodjs) — Opinionated full-stack framework combining React, GraphQL and Prisma.\n- [React Router](#react-router) — The standard React router, with a framework mode since v7.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://expo.dev).*\n"
  },
  {
    "slug": "nuxt-js",
    "title": "Nuxt.js",
    "excerpt": "Full-stack Vue framework with SSR, file-based routing and modules.",
    "type": "meta-framework",
    "bestFor": "production Vue websites",
    "officialUrl": "https://nuxt.com",
    "category": "vue",
    "tags": [
      "Vue"
    ],
    "featured": false,
    "date": "2026-10-25",
    "content": "# Nuxt.js\n\n> Full-stack Vue framework with SSR, file-based routing and modules.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | Vue-based frameworks |\n| Best for | production Vue websites |\n| Official site | [nuxt.com](https://nuxt.com) |\n\n## Overview\n\nNuxt is the full-stack framework for Vue, similar to what Next.js is for React. It adds file-based routing, server rendering, auto-imports, a server engine (Nitro) for API routes, and a large module ecosystem.\n\n## Key features\n\n- **File-based routing** in `pages/`.\n- **Universal rendering** — SSR, SSG or hybrid per route.\n- **Auto-imports** of components and composables.\n- **Nitro server** — API routes that deploy almost anywhere.\n- **Modules** — content, images, i18n, UI and more.\n\n## Quick start\n\n```bash\nnpm create nuxt@latest my-app\ncd my-app\nnpm run dev\n```\n\n## Example\n\n```vue\n<!-- pages/index.vue -->\n<script setup>\nconst { data: posts } = await useFetch('/api/posts')\n</script>\n\n<template>\n  <ul>\n    <li v-for=\"p in posts\" :key=\"p.id\">{{ p.title }}</li>\n  </ul>\n</template>\n```\n\n## When to choose it\n\n- You want an SEO-friendly, production Vue website.\n- You like conventions and auto-imports.\n\n## Think twice if\n\n- You need only a small client-side Vue widget.\n\n## Related\n\n- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.\n- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.\n- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.\n- [VuePress](#vuepress) — The original Vue-powered documentation generator.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nuxt.com).*\n"
  },
  {
    "slug": "quasar",
    "title": "Quasar",
    "excerpt": "Vue framework for web, mobile and desktop apps from one codebase.",
    "type": "framework",
    "bestFor": "one team, many platforms",
    "officialUrl": "https://quasar.dev",
    "category": "vue",
    "tags": [
      "Vue"
    ],
    "featured": false,
    "date": "2026-10-24",
    "content": "# Quasar\n\n> Vue framework for web, mobile and desktop apps from one codebase.\n\n| Field | Detail |\n|---|---|\n| Type | framework |\n| Category | Vue-based frameworks |\n| Best for | one team, many platforms |\n| Official site | [quasar.dev](https://quasar.dev) |\n\n## Overview\n\nQuasar is a Vue framework with a large Material-style component library and a CLI that builds the same code as an SPA, SSR site, PWA, mobile app (Capacitor/Cordova), desktop app (Electron) or browser extension.\n\n## Key features\n\n- **70+ components** — tables, forms, dialogs, layouts.\n- **One codebase, many targets** — web, mobile, desktop.\n- **Quasar CLI** with build modes.\n- **Built-in theming and RTL support**.\n\n## Quick start\n\n```bash\nnpm init quasar\ncd my-app\nquasar dev\n```\n\n## Example\n\n```vue\n<template>\n  <q-page padding>\n    <q-input v-model=\"name\" label=\"Your name\" />\n    <q-btn color=\"primary\" label=\"Save\" @click=\"save\" />\n  </q-page>\n</template>\n```\n\n## When to choose it\n\n- One small team must ship web, mobile and desktop.\n- You want a big ready-made component set for Vue.\n\n## Think twice if\n\n- You want a very custom, non-Material look.\n\n## Related\n\n- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.\n- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.\n- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.\n- [VuePress](#vuepress) — The original Vue-powered documentation generator.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://quasar.dev).*\n"
  },
  {
    "slug": "gridsome",
    "title": "Gridsome",
    "excerpt": "Vue static-site generator using GraphQL; largely unmaintained today.",
    "type": "static site generator",
    "bestFor": "reading about older Vue JAMstack projects",
    "officialUrl": "https://gridsome.org",
    "category": "vue",
    "tags": [
      "Vue"
    ],
    "featured": false,
    "date": "2026-10-23",
    "content": "# Gridsome\n\n> Vue static-site generator using GraphQL; largely unmaintained today.\n\n| Field | Detail |\n|---|---|\n| Type | static site generator |\n| Category | Vue-based frameworks |\n| Best for | reading about older Vue JAMstack projects |\n| Official site | [gridsome.org](https://gridsome.org) |\n\n## Overview\n\nGridsome was a Vue-powered static-site generator inspired by Gatsby, with a GraphQL data layer for Markdown, CMS and API content. It never moved to Vue 3 and is largely unmaintained today.\n\n> **Status note:** Gridsome is based on Vue 2 (end of life) and receives no active development.\n\n## Key features\n\n- **GraphQL data layer**.\n- **Static output** for JAMstack hosting.\n- **Plugins** for CMS and Markdown sources.\n\n## Quick start\n\n```bash\nnpx @gridsome/cli create my-site\ncd my-site\nnpx gridsome develop\n```\n\n## Example\n\n```vue\n<page-query>\nquery { allPost { edges { node { id title } } } }\n</page-query>\n\n<template>\n  <Layout>\n    <h2 v-for=\"e in $page.allPost.edges\" :key=\"e.node.id\">{{ e.node.title }}</h2>\n  </Layout>\n</template>\n```\n\n## When to choose it\n\n- You are reading or maintaining an older Vue 2 JAMstack project.\n\n## Think twice if\n\n- You are starting a new site — use Nuxt or VitePress instead.\n\n## Related\n\n- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.\n- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.\n- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.\n- [VuePress](#vuepress) — The original Vue-powered documentation generator.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://gridsome.org).*\n"
  },
  {
    "slug": "vitepress",
    "title": "VitePress",
    "excerpt": "Vite and Vue powered generator for documentation sites.",
    "type": "static site generator",
    "bestFor": "docs and technical blogs",
    "officialUrl": "https://vitepress.dev",
    "category": "vue",
    "tags": [
      "Vue"
    ],
    "featured": false,
    "date": "2026-10-22",
    "content": "# VitePress\n\n> Vite and Vue powered generator for documentation sites.\n\n| Field | Detail |\n|---|---|\n| Type | static site generator |\n| Category | Vue-based frameworks |\n| Best for | docs and technical blogs |\n| Official site | [vitepress.dev](https://vitepress.dev) |\n\n## Overview\n\nVitePress is a static-site generator powered by Vite and Vue, designed for documentation. You write Markdown, and it produces a fast, searchable docs site with a polished default theme. The docs for Vue, Vite and many other projects use it.\n\n## Key features\n\n- **Markdown-first** with Vue components inside Markdown.\n- **Fast dev server** thanks to Vite.\n- **Great default docs theme** — sidebar, search, dark mode.\n- **Static output** — host anywhere.\n\n## Quick start\n\n```bash\nnpm add -D vitepress\nnpx vitepress init\nnpm run docs:dev\n```\n\n## Example\n\n```ts\n// .vitepress/config.mts\nimport { defineConfig } from 'vitepress'\n\nexport default defineConfig({\n  title: 'MND Docs',\n  themeConfig: {\n    nav: [{ text: 'Guide', link: '/guide/' }],\n    sidebar: [{ text: 'Intro', link: '/guide/' }]\n  }\n})\n```\n\n## When to choose it\n\n- You need a documentation site or technical blog quickly.\n- You like writing in Markdown.\n\n## Think twice if\n\n- You need a full web application.\n\n## Related\n\n- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.\n- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.\n- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.\n- [VuePress](#vuepress) — The original Vue-powered documentation generator.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vitepress.dev).*\n"
  },
  {
    "slug": "vuepress",
    "title": "VuePress",
    "excerpt": "The original Vue-powered documentation generator.",
    "type": "static site generator",
    "bestFor": "Markdown-centred doc sites",
    "officialUrl": "https://vuepress.vuejs.org",
    "category": "vue",
    "tags": [
      "Vue"
    ],
    "featured": false,
    "date": "2026-10-21",
    "content": "# VuePress\n\n> The original Vue-powered documentation generator.\n\n| Field | Detail |\n|---|---|\n| Type | static site generator |\n| Category | Vue-based frameworks |\n| Best for | Markdown-centred doc sites |\n| Official site | [vuepress.vuejs.org](https://vuepress.vuejs.org) |\n\n## Overview\n\nVuePress is the original Vue-powered documentation generator. VuePress 2 supports Vue 3 and Vite and is maintained by the community; for new documentation sites, the Vue team recommends its successor, VitePress.\n\n## Key features\n\n- **Markdown-centred** pages with Vue components.\n- **Themes and plugins**.\n- **Static output** with SPA navigation.\n\n## Quick start\n\n```bash\nnpm init vuepress my-docs\ncd my-docs\nnpm run docs:dev\n```\n\n## Example\n\n```md\n---\ntitle: Getting started\n---\n\n# Welcome\n\nThis page is written in **Markdown**.\n\n<MyVueComponent />\n```\n\n## When to choose it\n\n- You maintain an existing VuePress site.\n\n## Think twice if\n\n- You are starting fresh — VitePress is faster and more active.\n\n## Related\n\n- [Nuxt.js](#nuxt-js) — Full-stack Vue framework with SSR, file-based routing and modules.\n- [Quasar](#quasar) — Vue framework for web, mobile and desktop apps from one codebase.\n- [Gridsome](#gridsome) — Vue static-site generator using GraphQL; largely unmaintained today.\n- [VitePress](#vitepress) — Vite and Vue powered generator for documentation sites.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vuepress.vuejs.org).*\n"
  },
  {
    "slug": "analogjs",
    "title": "AnalogJS",
    "excerpt": "Vite-powered meta-framework for Angular with file-based routing and SSR.",
    "type": "meta-framework",
    "bestFor": "full-stack Angular apps",
    "officialUrl": "https://analogjs.org",
    "category": "angular",
    "tags": [
      "Angular"
    ],
    "featured": false,
    "date": "2026-10-20",
    "content": "# AnalogJS\n\n> Vite-powered meta-framework for Angular with file-based routing and SSR.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | Angular ecosystem |\n| Best for | full-stack Angular apps |\n| Official site | [analogjs.org](https://analogjs.org) |\n\n## Overview\n\nAnalog is a full-stack meta-framework for Angular, built on Vite. It brings file-based routing, server-side rendering, static generation, API routes and Markdown content to Angular — similar to what Next.js does for React.\n\n## Key features\n\n- **File-based routing** with `.page.ts` files.\n- **SSR and SSG** out of the box.\n- **API routes** powered by Nitro.\n- **Vite-powered** dev server and builds.\n- **Markdown content** routes for blogs.\n\n## Quick start\n\n```bash\nnpm create analog@latest my-app\ncd my-app\nnpm start\n```\n\n## Example\n\n```ts\n// src/app/pages/index.page.ts\nimport { Component } from '@angular/core';\n\n@Component({\n  standalone: true,\n  template: `<h1>Hello from Analog</h1>`,\n})\nexport default class HomePage {}\n```\n\n## When to choose it\n\n- You know Angular and want Next.js-style routing and SSR.\n- You want Vite speed in an Angular project.\n\n## Think twice if\n\n- Your enterprise prefers only official Angular tooling.\n\n## Related\n\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [Nx](#nx) — Monorepo build system with caching and code generation.\n- [Ionic](#ionic) — Cross-platform UI toolkit for hybrid mobile and PWA apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://analogjs.org).*\n"
  },
  {
    "slug": "nx",
    "title": "Nx",
    "excerpt": "Monorepo build system with caching and code generation.",
    "type": "build system",
    "bestFor": "large multi-project workspaces",
    "officialUrl": "https://nx.dev",
    "category": "angular",
    "tags": [
      "Angular"
    ],
    "featured": false,
    "date": "2026-10-19",
    "content": "# Nx\n\n> Monorepo build system with caching and code generation.\n\n| Field | Detail |\n|---|---|\n| Type | build system |\n| Category | Angular ecosystem |\n| Best for | large multi-project workspaces |\n| Official site | [nx.dev](https://nx.dev) |\n\n## Overview\n\nNx is a build system and monorepo tool. It understands how projects in one repository depend on each other, caches build and test results, and runs only what a change affects. It supports Angular, React, Vue, Node and more, with code generators for each.\n\n## Key features\n\n- **Smart caching** — never rebuild the same thing twice (local or remote).\n- **Affected commands** — test only projects your change touches.\n- **Project graph** — visualise dependencies.\n- **Generators and plugins** for many frameworks.\n\n## Quick start\n\n```bash\nnpx create-nx-workspace@latest my-workspace\n```\n\n## Example\n\n```bash\n# run the dev server of one app\nnx serve shop\n\n# test only what changed\nnx affected -t test\n\n# see the dependency graph in your browser\nnx graph\n```\n\n## When to choose it\n\n- You have many apps and libraries in one repository.\n- CI builds are getting slow.\n\n## Think twice if\n\n- You have a single small project — the setup is overkill.\n\n## Related\n\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [AnalogJS](#analogjs) — Vite-powered meta-framework for Angular with file-based routing and SSR.\n- [Ionic](#ionic) — Cross-platform UI toolkit for hybrid mobile and PWA apps.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nx.dev).*\n"
  },
  {
    "slug": "ionic",
    "title": "Ionic",
    "excerpt": "Cross-platform UI toolkit for hybrid mobile and PWA apps.",
    "type": "mobile toolkit",
    "bestFor": "web-skilled teams shipping mobile apps",
    "officialUrl": "https://ionicframework.com",
    "category": "angular",
    "tags": [
      "Angular"
    ],
    "featured": false,
    "date": "2026-10-18",
    "content": "# Ionic\n\n> Cross-platform UI toolkit for hybrid mobile and PWA apps.\n\n| Field | Detail |\n|---|---|\n| Type | mobile toolkit |\n| Category | Angular ecosystem |\n| Best for | web-skilled teams shipping mobile apps |\n| Official site | [ionicframework.com](https://ionicframework.com) |\n\n## Overview\n\nIonic is a UI toolkit of mobile-styled components (built as Web Components) for building iOS, Android and PWA apps with web technology. It works with Angular, React or Vue, and uses Capacitor to access native device features.\n\n## Key features\n\n- **Adaptive components** — look native on iOS and Android.\n- **Works with Angular, React and Vue**.\n- **Capacitor** — camera, files, push notifications.\n- **Ionic CLI** for creating and running apps.\n\n## Quick start\n\n```bash\nnpm install -g @ionic/cli\nionic start my-app tabs\ncd my-app\nionic serve\n```\n\n## Example\n\n```html\n<ion-header>\n  <ion-toolbar><ion-title>Profile</ion-title></ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding\">\n  <ion-input label=\"Name\" placeholder=\"Enter your name\"></ion-input>\n  <ion-button expand=\"block\">Save</ion-button>\n</ion-content>\n```\n\n## When to choose it\n\n- A web-skilled team needs to ship mobile apps.\n- You want one codebase for app stores and a PWA.\n\n## Think twice if\n\n- Your app needs heavy native performance such as 3D games.\n\n## Related\n\n- [Angular](#angular) — Google’s TypeScript-first, batteries-included application framework.\n- [AnalogJS](#analogjs) — Vite-powered meta-framework for Angular with file-based routing and SSR.\n- [Nx](#nx) — Monorepo build system with caching and code generation.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ionicframework.com).*\n"
  },
  {
    "slug": "sveltekit",
    "title": "SvelteKit",
    "excerpt": "The official application framework for Svelte with routing and SSR.",
    "type": "meta-framework",
    "bestFor": "full-stack Svelte apps",
    "officialUrl": "https://svelte.dev/docs/kit",
    "category": "svelte",
    "tags": [
      "Svelte"
    ],
    "featured": false,
    "date": "2026-10-17",
    "content": "# SvelteKit\n\n> The official application framework for Svelte with routing and SSR.\n\n| Field | Detail |\n|---|---|\n| Type | meta-framework |\n| Category | Svelte ecosystem |\n| Best for | full-stack Svelte apps |\n| Official site | [svelte.dev/docs/kit](https://svelte.dev/docs/kit) |\n\n## Overview\n\nSvelteKit is the official application framework for Svelte. It adds file-based routing, server-side rendering, data loading, form actions and adapters that deploy to Node, Vercel, Netlify, Cloudflare and static hosting.\n\n## Key features\n\n- **File-based routing** with `+page.svelte` files.\n- **Load functions** for server and universal data.\n- **Form actions** with progressive enhancement.\n- **Adapters** for almost any host.\n\n## Quick start\n\n```bash\nnpx sv create my-app\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```svelte\n<!-- src/routes/+page.svelte -->\n<script>\n  // data comes from +page.server.js:\n  // export async function load() { return { posts: await getPosts() }; }\n  let { data } = $props();\n</script>\n\n{#each data.posts as post}\n  <h2>{post.title}</h2>\n{/each}\n```\n\n## When to choose it\n\n- You like Svelte and need a full website or app.\n- You want SSR and great performance with little code.\n\n## Think twice if\n\n- You need many enterprise-grade third-party component libraries.\n\n## Related\n\n- [Elder.js](#elder-js) — SEO-focused Svelte static-site generator; no longer actively maintained.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://svelte.dev/docs/kit).*\n"
  },
  {
    "slug": "elder-js",
    "title": "Elder.js",
    "excerpt": "SEO-focused Svelte static-site generator; no longer actively maintained.",
    "type": "static site generator",
    "bestFor": "studying content-site architecture",
    "officialUrl": "https://elderguide.com/tech/elderjs/",
    "category": "svelte",
    "tags": [
      "Svelte"
    ],
    "featured": false,
    "date": "2026-10-16",
    "content": "# Elder.js\n\n> SEO-focused Svelte static-site generator; no longer actively maintained.\n\n| Field | Detail |\n|---|---|\n| Type | static site generator |\n| Category | Svelte ecosystem |\n| Best for | studying content-site architecture |\n| Official site | [elderguide.com/tech/elderjs](https://elderguide.com/tech/elderjs/) |\n\n## Overview\n\nElder.js is an SEO-focused static-site generator built on Svelte, designed for very large content sites with thousands of pages and partial hydration of interactive parts. It is no longer actively maintained.\n\n> **Status note:** Elder.js has not had significant updates for several years.\n\n## Key features\n\n- **Built for SEO** and large sites.\n- **Partial hydration** of Svelte components.\n- **Hooks system** to customise every build step.\n\n## Quick start\n\n```bash\nnpx degit Elderjs/template elderjs-app\ncd elderjs-app\nnpm install\nnpm start\n```\n\n## Example\n\n```js\n// src/routes/blog/route.js\nmodule.exports = {\n  all: async () => [{ slug: 'hello-world' }],\n  permalink: ({ request }) => `/blog/${request.slug}/`,\n  data: async ({ request }) => ({ title: request.slug }),\n};\n```\n\n## When to choose it\n\n- You want to study how large content sites are architected.\n\n## Think twice if\n\n- You are starting a new project — SvelteKit or Astro are better choices.\n\n## Related\n\n- [SvelteKit](#sveltekit) — The official application framework for Svelte with routing and SSR.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://elderguide.com/tech/elderjs/).*\n"
  },
  {
    "slug": "bootstrap",
    "title": "Bootstrap",
    "excerpt": "Popular responsive grid and component framework.",
    "type": "CSS framework",
    "bestFor": "fast, consistent layouts",
    "officialUrl": "https://getbootstrap.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": true,
    "date": "2026-11-14",
    "content": "# Bootstrap\n\n> Popular responsive grid and component framework.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | fast, consistent layouts |\n| Official site | [getbootstrap.com](https://getbootstrap.com) |\n\n## Overview\n\nBootstrap is the world's most popular CSS framework. It gives you a responsive 12-column grid, ready-made components (navbars, cards, modals, forms) and utility classes, so you can build a clean, consistent layout very quickly.\n\n## Key features\n\n- **Responsive grid** — `container`, `row` and `col-*` classes.\n- **Components** — buttons, navbars, modals, carousels and more.\n- **Utilities** for spacing, colours and flexbox.\n- **Sass variables and CSS variables** for theming, including dark mode.\n\n## Quick start\n\n```bash\nnpm install bootstrap\n\n# or use the CDN:\n# <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\n```\n\n## Example\n\n```html\n<div class=\"container\">\n  <div class=\"row g-3\">\n    <div class=\"col-md-6\">\n      <div class=\"card p-3\">\n        <h5 class=\"card-title\">Web Design</h5>\n        <a href=\"#\" class=\"btn btn-primary\">Learn more</a>\n      </div>\n    </div>\n  </div>\n</div>\n```\n\n## When to choose it\n\n- You want professional-looking pages fast.\n- You are building admin panels, business sites or prototypes.\n\n## Think twice if\n\n- You want a very unique design — Bootstrap sites can look alike unless customised.\n\n## Related\n\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://getbootstrap.com).*\n"
  },
  {
    "slug": "tailwind-css",
    "title": "Tailwind CSS",
    "excerpt": "Utility-first framework for styling directly in markup.",
    "type": "CSS framework",
    "bestFor": "custom designs at speed",
    "officialUrl": "https://tailwindcss.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": true,
    "date": "2026-11-15",
    "content": "# Tailwind CSS\n\n> Utility-first framework for styling directly in markup.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | custom designs at speed |\n| Official site | [tailwindcss.com](https://tailwindcss.com) |\n\n## Overview\n\nTailwind CSS is a utility-first framework: instead of writing custom CSS, you combine small classes like `flex`, `p-4` and `text-blue-600` directly in your HTML. Only the classes you actually use end up in the final CSS file, so it stays small. Version 4 made setup simpler with a single CSS import.\n\n## Key features\n\n- **Utility classes** for layout, spacing, colour and typography.\n- **Responsive and state variants** — `md:`, `hover:`, `dark:`.\n- **Tiny production CSS** — unused classes are removed.\n- **CSS-first config** in v4 using `@theme`.\n\n## Quick start\n\n```bash\nnpm install tailwindcss @tailwindcss/vite\n\n# then in your main CSS file:\n# @import \"tailwindcss\";\n```\n\n## Example\n\n```html\n<div class=\"max-w-sm rounded-2xl bg-slate-900 p-6 shadow-lg\">\n  <h3 class=\"text-xl font-bold text-white\">Web Design</h3>\n  <p class=\"mt-2 text-slate-400\">Functional, user-first interfaces.</p>\n  <button class=\"mt-4 rounded-xl bg-blue-600 px-4 py-2 text-white hover:bg-blue-500\">\n    Learn more\n  </button>\n</div>\n```\n\n## When to choose it\n\n- You want fully custom designs without writing much CSS.\n- You use React, Vue or Svelte components.\n\n## Think twice if\n\n- You dislike long class lists in HTML.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://tailwindcss.com).*\n"
  },
  {
    "slug": "bulma",
    "title": "Bulma",
    "excerpt": "Flexbox-based, CSS-only framework with no JavaScript.",
    "type": "CSS framework",
    "bestFor": "simple, readable styling",
    "officialUrl": "https://bulma.io",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-15",
    "content": "# Bulma\n\n> Flexbox-based, CSS-only framework with no JavaScript.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | simple, readable styling |\n| Official site | [bulma.io](https://bulma.io) |\n\n## Overview\n\nBulma is a modern CSS-only framework based on Flexbox. It has no JavaScript at all, readable class names like `button is-primary`, and a simple column system.\n\n## Key features\n\n- **CSS only** — no JavaScript dependencies.\n- **Flexbox columns** — `columns` and `column`.\n- **Readable modifiers** — `is-primary`, `is-large`.\n- **CSS variables** for theming (v1).\n\n## Quick start\n\n```bash\nnpm install bulma\n```\n\n## Example\n\n```html\n<div class=\"columns\">\n  <div class=\"column\">\n    <div class=\"box\">\n      <h3 class=\"title is-4\">Web Design</h3>\n      <button class=\"button is-primary\">Learn more</button>\n    </div>\n  </div>\n</div>\n```\n\n## When to choose it\n\n- You want simple, readable styling with no JavaScript.\n\n## Think twice if\n\n- You need interactive components like modals and dropdowns ready to use.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://bulma.io).*\n"
  },
  {
    "slug": "foundation",
    "title": "Foundation",
    "excerpt": "Responsive framework from ZURB aimed at flexible, accessible sites.",
    "type": "CSS framework",
    "bestFor": "advanced responsive layouts",
    "officialUrl": "https://get.foundation",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-14",
    "content": "# Foundation\n\n> Responsive framework from ZURB aimed at flexible, accessible sites.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | advanced responsive layouts |\n| Official site | [get.foundation](https://get.foundation) |\n\n## Overview\n\nFoundation by ZURB is a responsive front-end framework focused on flexibility and accessibility. It offers an XY grid, Sass mixins, components and a separate framework for HTML emails.\n\n> **Status note:** Updates are infrequent compared with Bootstrap or Tailwind.\n\n## Key features\n\n- **XY Grid** — flexible responsive layouts.\n- **Sass-based** customisation.\n- **Accessible components** with JavaScript plugins.\n- **Foundation for Emails**.\n\n## Quick start\n\n```bash\nnpm install foundation-sites\n```\n\n## Example\n\n```html\n<div class=\"grid-container\">\n  <div class=\"grid-x grid-margin-x\">\n    <div class=\"cell medium-6\">Left</div>\n    <div class=\"cell medium-6\">Right</div>\n  </div>\n  <a class=\"button primary\" href=\"#\">Learn more</a>\n</div>\n```\n\n## When to choose it\n\n- You maintain a Foundation site or need its email framework.\n\n## Think twice if\n\n- You are starting new — Bootstrap or Tailwind have more active communities.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://get.foundation).*\n"
  },
  {
    "slug": "materialize-css",
    "title": "Materialize CSS",
    "excerpt": "Framework implementing Google’s Material Design.",
    "type": "CSS framework",
    "bestFor": "Material-style sites",
    "officialUrl": "https://materializecss.github.io/materialize/",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-13",
    "content": "# Materialize CSS\n\n> Framework implementing Google’s Material Design.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | Material-style sites |\n| Official site | [materializecss.github.io/materialize](https://materializecss.github.io/materialize/) |\n\n## Overview\n\nMaterialize is a CSS framework that implements Google's Material Design look — cards, shadows, ripple 'waves' effects and floating buttons. The original project is no longer maintained; a community fork continues development.\n\n> **Status note:** Use the community fork (`@materializecss/materialize`), not the old `materialize-css` package.\n\n## Key features\n\n- **Material Design styling**.\n- **Components** — cards, modals, tabs, toasts.\n- **Waves** ripple effect.\n- **Responsive grid**.\n\n## Quick start\n\n```bash\nnpm install @materializecss/materialize\n```\n\n## Example\n\n```html\n<div class=\"row\">\n  <div class=\"col s12 m6\">\n    <div class=\"card\">\n      <div class=\"card-content\"><span class=\"card-title\">Web Design</span></div>\n      <div class=\"card-action\"><a class=\"btn waves-effect\">Learn more</a></div>\n    </div>\n  </div>\n</div>\n```\n\n## When to choose it\n\n- You want a quick Material-style look without React.\n\n## Think twice if\n\n- You use React — Material UI (MUI) is far more complete.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://materializecss.github.io/materialize/).*\n"
  },
  {
    "slug": "semantic-ui",
    "title": "Semantic UI",
    "excerpt": "Framework using human-friendly, natural-language class names.",
    "type": "CSS framework",
    "bestFor": "readable class names",
    "officialUrl": "https://fomantic-ui.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-12",
    "content": "# Semantic UI\n\n> Framework using human-friendly, natural-language class names.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | readable class names |\n| Official site | [fomantic-ui.com](https://fomantic-ui.com) |\n\n## Overview\n\nSemantic UI uses human-friendly class names that read like sentences, such as `ui primary button`. The original project stopped active development; the community fork Fomantic-UI continues it.\n\n> **Status note:** The original Semantic UI is inactive — use Fomantic-UI for updates.\n\n## Key features\n\n- **Natural-language class names**.\n- **Large set of components and themes**.\n- **jQuery-based behaviours** for interactive parts.\n\n## Quick start\n\n```bash\nnpm install fomantic-ui-css\n```\n\n## Example\n\n```html\n<div class=\"ui card\">\n  <div class=\"content\">\n    <div class=\"header\">Web Design</div>\n  </div>\n  <button class=\"ui primary button\">Learn more</button>\n</div>\n```\n\n## When to choose it\n\n- You like readable class names and maintain a Semantic/Fomantic site.\n\n## Think twice if\n\n- You want a framework without jQuery.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [UIKit](#uikit) — Modular front-end framework from YOOtheme.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://fomantic-ui.com).*\n"
  },
  {
    "slug": "uikit",
    "title": "UIKit",
    "excerpt": "Modular front-end framework from YOOtheme.",
    "type": "CSS framework",
    "bestFor": "lightweight modular UI",
    "officialUrl": "https://getuikit.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-11",
    "content": "# UIKit\n\n> Modular front-end framework from YOOtheme.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | lightweight modular UI |\n| Official site | [getuikit.com](https://getuikit.com) |\n\n## Overview\n\nUIkit, from YOOtheme, is a lightweight, modular front-end framework. It provides a grid, many components and JavaScript behaviours controlled through simple HTML attributes like `uk-grid` and `uk-modal`.\n\n## Key features\n\n- **Modular** — use only the parts you need.\n- **Attribute-driven JavaScript** — `uk-slider`, `uk-modal`, `uk-scrollspy`.\n- **Less/Sass theming**.\n- **Animations and sliders** built in.\n\n## Quick start\n\n```bash\nnpm install uikit\n```\n\n## Example\n\n```html\n<div class=\"uk-child-width-1-2@m\" uk-grid>\n  <div><div class=\"uk-card uk-card-default uk-card-body\">Web Design</div></div>\n  <div><div class=\"uk-card uk-card-primary uk-card-body\">UI/UX</div></div>\n</div>\n<button class=\"uk-button uk-button-primary\">Learn more</button>\n```\n\n## When to choose it\n\n- You want modular UI with built-in sliders and animations.\n- You build WordPress/Joomla themes (popular with YOOtheme).\n\n## Think twice if\n\n- You prefer utility-first styling.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://getuikit.com).*\n"
  },
  {
    "slug": "pico-css",
    "title": "Pico CSS",
    "excerpt": "Minimal framework that styles semantic HTML with few classes.",
    "type": "CSS framework",
    "bestFor": "clean pages with almost no CSS",
    "officialUrl": "https://picocss.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-10",
    "content": "# Pico CSS\n\n> Minimal framework that styles semantic HTML with few classes.\n\n| Field | Detail |\n|---|---|\n| Type | CSS framework |\n| Category | CSS frameworks and UI libraries |\n| Best for | clean pages with almost no CSS |\n| Official site | [picocss.com](https://picocss.com) |\n\n## Overview\n\nPico CSS is a minimal framework that styles plain, semantic HTML. Write normal `<nav>`, `<article>`, `<form>` and `<button>` tags and they look good automatically — with almost no classes and built-in light/dark mode.\n\n## Key features\n\n- **Class-light** — semantic HTML is styled directly.\n- **Automatic dark mode**.\n- **Responsive typography and spacing**.\n- **Small** — one CSS file.\n\n## Quick start\n\n```html\n<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css\">\n```\n\n## Example\n\n```html\n<main class=\"container\">\n  <article>\n    <h2>Contact</h2>\n    <form>\n      <input type=\"email\" placeholder=\"Email\">\n      <button type=\"submit\">Send</button>\n    </form>\n  </article>\n</main>\n```\n\n## When to choose it\n\n- You want clean pages, docs or prototypes with almost no CSS.\n\n## Think twice if\n\n- You need a large set of complex components.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://picocss.com).*\n"
  },
  {
    "slug": "unocss",
    "title": "UnoCSS",
    "excerpt": "Instant, on-demand atomic CSS engine.",
    "type": "utility engine",
    "bestFor": "customizable utility CSS",
    "officialUrl": "https://unocss.dev",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-09",
    "content": "# UnoCSS\n\n> Instant, on-demand atomic CSS engine.\n\n| Field | Detail |\n|---|---|\n| Type | utility engine |\n| Category | CSS frameworks and UI libraries |\n| Best for | customizable utility CSS |\n| Official site | [unocss.dev](https://unocss.dev) |\n\n## Overview\n\nUnoCSS is an instant, on-demand atomic CSS engine. It generates only the utility classes you use, and you can enable presets (such as a Tailwind-compatible one), icons or attribute mode. It is extremely fast and highly customisable.\n\n## Key features\n\n- **On-demand generation** — very fast builds.\n- **Presets** — Tailwind-like, icons, attributify, typography.\n- **Custom rules** in a few lines.\n- **Works with Vite, Nuxt, Astro and more**.\n\n## Quick start\n\n```bash\nnpm install -D unocss\n```\n\n## Example\n\n```ts\n// vite.config.ts\nimport UnoCSS from 'unocss/vite'\nimport { defineConfig } from 'vite'\n\nexport default defineConfig({\n  plugins: [UnoCSS()],\n})\n\n// main.ts\n// import 'virtual:uno.css'\n```\n\n## When to choose it\n\n- You want Tailwind-style utilities with full control over rules.\n- You use Vite or Nuxt.\n\n## Think twice if\n\n- You want the largest community and plugin set — Tailwind is bigger.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://unocss.dev).*\n"
  },
  {
    "slug": "windi-css",
    "title": "Windi CSS",
    "excerpt": "Early on-demand Tailwind alternative; now deprecated.",
    "type": "utility engine",
    "bestFor": "understanding utility-CSS history",
    "officialUrl": "https://windicss.org",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-08",
    "content": "# Windi CSS\n\n> Early on-demand Tailwind alternative; now deprecated.\n\n| Field | Detail |\n|---|---|\n| Type | utility engine |\n| Category | CSS frameworks and UI libraries |\n| Best for | understanding utility-CSS history |\n| Official site | [windicss.org](https://windicss.org) |\n\n## Overview\n\nWindi CSS was an early on-demand alternative to Tailwind CSS that made dev builds much faster. Its ideas were adopted by Tailwind's JIT engine and by UnoCSS, and the project has been sunset.\n\n> **Status note:** Windi CSS was sunset in 2023. Migrate to Tailwind CSS or UnoCSS.\n\n## Key features\n\n- **On-demand utility generation** (influenced Tailwind JIT).\n- **Tailwind-compatible classes**.\n- **Attributify mode** — later carried into UnoCSS.\n\n## Quick start\n\n```bash\n# Deprecated — for new projects install Tailwind CSS or UnoCSS instead\nnpm install -D unocss\n```\n\n## Example\n\n```html\n<!-- Windi-style utilities still work the same way in Tailwind/UnoCSS -->\n<button class=\"px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-500\">\n  Learn more\n</button>\n```\n\n## When to choose it\n\n- You want to understand the history of utility-first CSS.\n\n## Think twice if\n\n- Any new project — it is no longer maintained.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://windicss.org).*\n"
  },
  {
    "slug": "daisyui",
    "title": "DaisyUI",
    "excerpt": "Tailwind plugin that adds ready-made component classes.",
    "type": "component library",
    "bestFor": "Tailwind with less markup",
    "officialUrl": "https://daisyui.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-07",
    "content": "# DaisyUI\n\n> Tailwind plugin that adds ready-made component classes.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | Tailwind with less markup |\n| Official site | [daisyui.com](https://daisyui.com) |\n\n## Overview\n\ndaisyUI is a plugin for Tailwind CSS that adds ready-made component class names such as `btn`, `card` and `modal`. You keep Tailwind utilities but write much less markup, and switch between many built-in themes.\n\n## Key features\n\n- **Component classes** — `btn`, `card`, `navbar`, `modal`.\n- **Many themes** including dark mode.\n- **Pure CSS** — works with any framework.\n- **Still fully customisable** with Tailwind utilities.\n\n## Quick start\n\n```bash\nnpm install -D daisyui@latest\n\n# in your CSS (Tailwind v4):\n# @import \"tailwindcss\";\n# @plugin \"daisyui\";\n```\n\n## Example\n\n```html\n<div class=\"card bg-base-200 w-80 shadow\">\n  <div class=\"card-body\">\n    <h2 class=\"card-title\">Web Design</h2>\n    <div class=\"card-actions justify-end\">\n      <button class=\"btn btn-primary\">Learn more</button>\n    </div>\n  </div>\n</div>\n```\n\n## When to choose it\n\n- You use Tailwind but want shorter markup and themes.\n\n## Think twice if\n\n- You don't use Tailwind CSS.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://daisyui.com).*\n"
  },
  {
    "slug": "chakra-ui",
    "title": "Chakra UI",
    "excerpt": "Accessible, themeable React component library.",
    "type": "component library",
    "bestFor": "accessible React interfaces",
    "officialUrl": "https://chakra-ui.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-06",
    "content": "# Chakra UI\n\n> Accessible, themeable React component library.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | accessible React interfaces |\n| Official site | [chakra-ui.com](https://chakra-ui.com) |\n\n## Overview\n\nChakra UI is an accessible, themeable component library for React. Components accept style props (like `p=\"4\"` or `color=\"teal.500\"`), and a token-based theme system makes consistent design and dark mode easy.\n\n## Key features\n\n- **Accessible by default** (WAI-ARIA).\n- **Style props** directly on components.\n- **Theme tokens** and colour palettes.\n- **Dark mode** support.\n\n## Quick start\n\n```bash\nnpm install @chakra-ui/react @emotion/react\n```\n\n## Example\n\n```jsx\nimport { ChakraProvider, defaultSystem, Button, Box } from '@chakra-ui/react';\n\nexport default function App() {\n  return (\n    <ChakraProvider value={defaultSystem}>\n      <Box p=\"6\" borderRadius=\"xl\" bg=\"gray.900\">\n        <Button colorPalette=\"teal\">Save</Button>\n      </Box>\n    </ChakraProvider>\n  );\n}\n```\n\n## When to choose it\n\n- You want accessible React components with quick styling.\n\n## Think twice if\n\n- You are not using React.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://chakra-ui.com).*\n"
  },
  {
    "slug": "material-ui-mui",
    "title": "Material UI (MUI)",
    "excerpt": "React components implementing Material Design.",
    "type": "component library",
    "bestFor": "polished React dashboards",
    "officialUrl": "https://mui.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": true,
    "date": "2026-11-13",
    "content": "# Material UI (MUI)\n\n> React components implementing Material Design.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | polished React dashboards |\n| Official site | [mui.com](https://mui.com) |\n\n## Overview\n\nMaterial UI (MUI) is a large React component library that implements Google's Material Design. It is widely used for dashboards and business apps, and MUI X adds advanced components like data grids, date pickers and charts.\n\n## Key features\n\n- **Comprehensive components** — buttons, dialogs, tables, menus.\n- **Theming** with `createTheme`.\n- **`sx` prop** for one-off styles.\n- **MUI X** — Data Grid, Date Pickers, Charts.\n\n## Quick start\n\n```bash\nnpm install @mui/material @emotion/react @emotion/styled\n```\n\n## Example\n\n```jsx\nimport Button from '@mui/material/Button';\nimport Card from '@mui/material/Card';\nimport CardContent from '@mui/material/CardContent';\n\nexport default function Service() {\n  return (\n    <Card sx={{ maxWidth: 320 }}>\n      <CardContent>Web Design</CardContent>\n      <Button variant=\"contained\">Learn more</Button>\n    </Card>\n  );\n}\n```\n\n## When to choose it\n\n- You build polished React dashboards or admin panels.\n- You like the Material Design look.\n\n## Think twice if\n\n- You want a non-Material, highly custom brand look with little effort.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mui.com).*\n"
  },
  {
    "slug": "ant-design",
    "title": "Ant Design",
    "excerpt": "Enterprise-grade React UI system with a rich component set.",
    "type": "component library",
    "bestFor": "admin and data-heavy apps",
    "officialUrl": "https://ant.design",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-05",
    "content": "# Ant Design\n\n> Enterprise-grade React UI system with a rich component set.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | admin and data-heavy apps |\n| Official site | [ant.design](https://ant.design) |\n\n## Overview\n\nAnt Design is an enterprise-grade React UI system from Ant Group. It has a very rich component set — especially tables, forms and data-entry controls — making it a favourite for admin panels and data-heavy apps.\n\n## Key features\n\n- **60+ components** focused on business apps.\n- **Powerful Table and Form**.\n- **Design tokens** for theming.\n- **Built-in internationalisation**.\n\n## Quick start\n\n```bash\nnpm install antd\n```\n\n## Example\n\n```jsx\nimport { Button, Table } from 'antd';\n\nconst columns = [{ title: 'Name', dataIndex: 'name' }, { title: 'Role', dataIndex: 'role' }];\nconst data = [{ key: 1, name: 'Pabitra', role: 'Developer' }];\n\nexport default function Team() {\n  return (\n    <>\n      <Button type=\"primary\">Add member</Button>\n      <Table columns={columns} dataSource={data} />\n    </>\n  );\n}\n```\n\n## When to choose it\n\n- You build admin dashboards with many tables and forms.\n\n## Think twice if\n\n- You want a lightweight or very custom-looking marketing site.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ant.design).*\n"
  },
  {
    "slug": "mantine",
    "title": "Mantine",
    "excerpt": "Full-featured React components and hooks library.",
    "type": "component library",
    "bestFor": "productive React apps",
    "officialUrl": "https://mantine.dev",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-04",
    "content": "# Mantine\n\n> Full-featured React components and hooks library.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | productive React apps |\n| Official site | [mantine.dev](https://mantine.dev) |\n\n## Overview\n\nMantine is a full-featured React component library with 100+ components and 50+ hooks. It has great documentation, built-in dark mode, and extra packages for forms, dates, notifications and charts.\n\n## Key features\n\n- **100+ components** and many useful hooks.\n- **Dark mode and theming** built in.\n- **Extra packages** — form, dates, notifications, charts.\n- **CSS modules based** styling.\n\n## Quick start\n\n```bash\nnpm install @mantine/core @mantine/hooks\n```\n\n## Example\n\n```jsx\nimport '@mantine/core/styles.css';\nimport { MantineProvider, Button, Card, Text } from '@mantine/core';\n\nexport default function App() {\n  return (\n    <MantineProvider defaultColorScheme=\"dark\">\n      <Card padding=\"lg\" radius=\"lg\">\n        <Text fw={700}>Web Design</Text>\n        <Button mt=\"md\">Learn more</Button>\n      </Card>\n    </MantineProvider>\n  );\n}\n```\n\n## When to choose it\n\n- You want to be productive quickly in React with good docs.\n\n## Think twice if\n\n- You are not using React.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://mantine.dev).*\n"
  },
  {
    "slug": "shadcn-ui",
    "title": "shadcn/ui",
    "excerpt": "Copy-and-own components built on Radix UI and Tailwind CSS.",
    "type": "component collection",
    "bestFor": "fully customizable components",
    "officialUrl": "https://ui.shadcn.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": true,
    "date": "2026-11-12",
    "content": "# shadcn/ui\n\n> Copy-and-own components built on Radix UI and Tailwind CSS.\n\n| Field | Detail |\n|---|---|\n| Type | component collection |\n| Category | CSS frameworks and UI libraries |\n| Best for | fully customizable components |\n| Official site | [ui.shadcn.com](https://ui.shadcn.com) |\n\n## Overview\n\nshadcn/ui is not a normal npm library. It is a collection of beautifully designed components (built on Radix UI and Tailwind CSS) that a CLI copies directly into your project. You own the code, so you can change anything.\n\n## Key features\n\n- **Copy-and-own** — components live in your repo.\n- **Built on Radix UI** primitives for accessibility.\n- **Tailwind CSS** styling — easy to restyle.\n- **CLI** — `npx shadcn add button`.\n- **Blocks and charts** ready to paste.\n\n## Quick start\n\n```bash\nnpx shadcn@latest init\nnpx shadcn@latest add button card\n```\n\n## Example\n\n```tsx\nimport { Button } from '@/components/ui/button';\nimport { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';\n\nexport default function Service() {\n  return (\n    <Card>\n      <CardHeader><CardTitle>Web Design</CardTitle></CardHeader>\n      <CardContent><Button>Learn more</Button></CardContent>\n    </Card>\n  );\n}\n```\n\n## When to choose it\n\n- You want full control over component code and design.\n- You use React with Tailwind CSS (Next.js, Vite).\n\n## Think twice if\n\n- You want updates delivered automatically through npm.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://ui.shadcn.com).*\n"
  },
  {
    "slug": "primereact",
    "title": "PrimeReact",
    "excerpt": "Large React UI suite with many data components.",
    "type": "component library",
    "bestFor": "feature-rich business UIs",
    "officialUrl": "https://primereact.org",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-03",
    "content": "# PrimeReact\n\n> Large React UI suite with many data components.\n\n| Field | Detail |\n|---|---|\n| Type | component library |\n| Category | CSS frameworks and UI libraries |\n| Best for | feature-rich business UIs |\n| Official site | [primereact.org](https://primereact.org) |\n\n## Overview\n\nPrimeReact is a large React UI suite with 80+ components, including a powerful DataTable, charts, calendars and file uploads. It offers styled themes or an unstyled mode you can style with Tailwind.\n\n## Key features\n\n- **80+ components** for business apps.\n- **DataTable** — sorting, filtering, paging, editing.\n- **Themes or unstyled mode**.\n- **Sister libraries** — PrimeVue and PrimeNG.\n\n## Quick start\n\n```bash\nnpm install primereact\n```\n\n## Example\n\n```jsx\nimport { DataTable } from 'primereact/datatable';\nimport { Column } from 'primereact/column';\n\nexport default function Projects({ rows }) {\n  return (\n    <DataTable value={rows} paginator rows={5}>\n      <Column field=\"name\" header=\"Project\" sortable />\n      <Column field=\"type\" header=\"Type\" />\n    </DataTable>\n  );\n}\n```\n\n## When to choose it\n\n- You need feature-rich data components quickly.\n\n## Think twice if\n\n- You only need a few simple components.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://primereact.org).*\n"
  },
  {
    "slug": "radix-ui",
    "title": "Radix UI",
    "excerpt": "Unstyled, accessible React primitives.",
    "type": "primitives",
    "bestFor": "building your own design system",
    "officialUrl": "https://www.radix-ui.com",
    "category": "css",
    "tags": [
      "CSS & UI"
    ],
    "featured": false,
    "date": "2026-10-02",
    "content": "# Radix UI\n\n> Unstyled, accessible React primitives.\n\n| Field | Detail |\n|---|---|\n| Type | primitives |\n| Category | CSS frameworks and UI libraries |\n| Best for | building your own design system |\n| Official site | [radix-ui.com](https://www.radix-ui.com) |\n\n## Overview\n\nRadix UI Primitives are unstyled, accessible React components — dialogs, dropdowns, tabs, tooltips and more. They handle keyboard navigation, focus and ARIA for you, while you add any styling you like. Many design systems, including shadcn/ui, are built on them.\n\n## Key features\n\n- **Unstyled** — bring your own CSS or Tailwind.\n- **Accessibility handled** — focus, keyboard, ARIA.\n- **Composable parts** like `Dialog.Trigger` and `Dialog.Content`.\n- **Radix Themes** — optional styled layer.\n\n## Quick start\n\n```bash\nnpm install radix-ui\n```\n\n## Example\n\n```jsx\nimport { Dialog } from 'radix-ui';\n\nexport default function Contact() {\n  return (\n    <Dialog.Root>\n      <Dialog.Trigger>Contact me</Dialog.Trigger>\n      <Dialog.Portal>\n        <Dialog.Overlay className=\"overlay\" />\n        <Dialog.Content className=\"modal\">\n          <Dialog.Title>Let's work together</Dialog.Title>\n          <Dialog.Close>Close</Dialog.Close>\n        </Dialog.Content>\n      </Dialog.Portal>\n    </Dialog.Root>\n  );\n}\n```\n\n## When to choose it\n\n- You are building your own design system in React.\n\n## Think twice if\n\n- You want pre-styled components — try shadcn/ui or Mantine.\n\n## Related\n\n- [Bootstrap](#bootstrap) — Popular responsive grid and component framework.\n- [Tailwind CSS](#tailwind-css) — Utility-first framework for styling directly in markup.\n- [Bulma](#bulma) — Flexbox-based, CSS-only framework with no JavaScript.\n- [Foundation](#foundation) — Responsive framework from ZURB aimed at flexible, accessible sites.\n- [Materialize CSS](#materialize-css) — Framework implementing Google’s Material Design.\n- [Semantic UI](#semantic-ui) — Framework using human-friendly, natural-language class names.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://www.radix-ui.com).*\n"
  },
  {
    "slug": "vite",
    "title": "Vite",
    "excerpt": "Fast dev server and bundler using native ES modules.",
    "type": "build tool",
    "bestFor": "almost any modern project",
    "officialUrl": "https://vite.dev",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": true,
    "date": "2026-11-11",
    "content": "# Vite\n\n> Fast dev server and bundler using native ES modules.\n\n| Field | Detail |\n|---|---|\n| Type | build tool |\n| Category | Frontend build tools |\n| Best for | almost any modern project |\n| Official site | [vite.dev](https://vite.dev) |\n\n## Overview\n\nVite is a fast build tool and dev server. In development it serves your code as native ES modules, so the server starts instantly and changes appear immediately (hot module replacement). For production it creates optimised bundles. It is the default tool for Vue, Svelte, Solid and many React projects.\n\n## Key features\n\n- **Instant dev server** and fast HMR.\n- **Templates** for React, Vue, Svelte, Solid, Preact, Lit and vanilla JS.\n- **TypeScript, JSX and CSS** support built in.\n- **Plugin system** compatible with Rollup plugins.\n\n## Quick start\n\n```bash\nnpm create vite@latest my-app\ncd my-app\nnpm install\nnpm run dev\n```\n\n## Example\n\n```js\n// vite.config.js\nimport { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\n\nexport default defineConfig({\n  plugins: [react()],\n  server: { port: 3000 },\n});\n```\n\n## When to choose it\n\n- Almost any new frontend project.\n- You want fast feedback while coding.\n\n## Think twice if\n\n- You have a very complex legacy webpack setup you can't migrate yet.\n\n## Related\n\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://vite.dev).*\n"
  },
  {
    "slug": "webpack",
    "title": "Webpack",
    "excerpt": "Highly configurable module bundler with a vast plugin ecosystem.",
    "type": "bundler",
    "bestFor": "complex or legacy builds",
    "officialUrl": "https://webpack.js.org",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-10-01",
    "content": "# Webpack\n\n> Highly configurable module bundler with a vast plugin ecosystem.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | complex or legacy builds |\n| Official site | [webpack.js.org](https://webpack.js.org) |\n\n## Overview\n\nwebpack is the long-established module bundler behind many existing apps. It turns JavaScript, CSS, images and more into optimised bundles using *loaders* and *plugins*, and is extremely configurable.\n\n## Key features\n\n- **Loaders** — handle CSS, images, TypeScript, etc.\n- **Plugins** — huge ecosystem for every need.\n- **Code splitting and lazy loading**.\n- **Module Federation** — share code between separate apps.\n\n## Quick start\n\n```bash\nnpm install -D webpack webpack-cli\n```\n\n## Example\n\n```js\n// webpack.config.js\nmodule.exports = {\n  entry: './src/index.js',\n  output: { filename: 'bundle.js', path: __dirname + '/dist' },\n  module: {\n    rules: [{ test: /\\.css$/, use: ['style-loader', 'css-loader'] }],\n  },\n};\n```\n\n## When to choose it\n\n- You maintain a webpack project or need Module Federation.\n- You need very fine control over the build.\n\n## Think twice if\n\n- You are starting fresh — Vite is simpler and faster.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://webpack.js.org).*\n"
  },
  {
    "slug": "parcel",
    "title": "Parcel",
    "excerpt": "Zero-configuration bundler.",
    "type": "bundler",
    "bestFor": "quick setups",
    "officialUrl": "https://parceljs.org",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-09-30",
    "content": "# Parcel\n\n> Zero-configuration bundler.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | quick setups |\n| Official site | [parceljs.org](https://parceljs.org) |\n\n## Overview\n\nParcel is a zero-configuration bundler. Point it at an HTML file and it automatically handles JavaScript, TypeScript, CSS, images and more — no config file needed.\n\n## Key features\n\n- **Zero config** — works out of the box.\n- **Fast** — Rust-based compiler and caching.\n- **Automatic transforms** for TS, JSX, Sass, images.\n\n## Quick start\n\n```bash\nnpm install -D parcel\n```\n\n## Example\n\n```bash\n# start a dev server from an HTML entry\nnpx parcel src/index.html\n\n# build for production\nnpx parcel build src/index.html\n```\n\n## When to choose it\n\n- You want a quick setup with no configuration.\n\n## Think twice if\n\n- You need a framework-specific setup — Vite templates are more common.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://parceljs.org).*\n"
  },
  {
    "slug": "rollup",
    "title": "Rollup",
    "excerpt": "ES-module bundler favoured for libraries.",
    "type": "bundler",
    "bestFor": "publishing libraries",
    "officialUrl": "https://rollupjs.org",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-09-29",
    "content": "# Rollup\n\n> ES-module bundler favoured for libraries.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | publishing libraries |\n| Official site | [rollupjs.org](https://rollupjs.org) |\n\n## Overview\n\nRollup is an ES-module bundler known for clean, efficient output and excellent tree-shaking. It is the favourite tool for publishing JavaScript libraries and is used inside Vite for production builds.\n\n## Key features\n\n- **Excellent tree-shaking**.\n- **Multiple output formats** — ESM, CommonJS, UMD.\n- **Simple plugin API** (also used by Vite).\n\n## Quick start\n\n```bash\nnpm install -D rollup\n```\n\n## Example\n\n```js\n// rollup.config.js\nexport default {\n  input: 'src/index.js',\n  output: [\n    { file: 'dist/index.mjs', format: 'es' },\n    { file: 'dist/index.cjs', format: 'cjs' },\n  ],\n};\n```\n\n## When to choose it\n\n- You are publishing an npm library.\n\n## Think twice if\n\n- You want a dev server for an app — use Vite.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://rollupjs.org).*\n"
  },
  {
    "slug": "esbuild",
    "title": "esbuild",
    "excerpt": "Extremely fast bundler written in Go.",
    "type": "bundler",
    "bestFor": "speed-critical builds",
    "officialUrl": "https://esbuild.github.io",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-09-28",
    "content": "# esbuild\n\n> Extremely fast bundler written in Go.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | speed-critical builds |\n| Official site | [esbuild.github.io](https://esbuild.github.io) |\n\n## Overview\n\nesbuild is an extremely fast JavaScript and TypeScript bundler and minifier written in Go — often 10–100× faster than older tools. Vite and many other tools use it internally.\n\n## Key features\n\n- **Extremely fast** bundling and minifying.\n- **TypeScript and JSX** out of the box.\n- **Simple CLI and JS API**.\n\n## Quick start\n\n```bash\nnpm install -D esbuild\n```\n\n## Example\n\n```bash\nnpx esbuild src/app.jsx --bundle --minify --sourcemap --outfile=dist/app.js\n```\n\n## When to choose it\n\n- Speed is critical, e.g. scripts, CLIs or simple bundles.\n\n## Think twice if\n\n- You need advanced features like rich HMR — use Vite, which uses esbuild inside.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://esbuild.github.io).*\n"
  },
  {
    "slug": "turbopack",
    "title": "Turbopack",
    "excerpt": "Rust-based incremental bundler built for Next.js.",
    "type": "bundler",
    "bestFor": "large Next.js apps",
    "officialUrl": "https://nextjs.org/docs/app/api-reference/turbopack",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-09-27",
    "content": "# Turbopack\n\n> Rust-based incremental bundler built for Next.js.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | large Next.js apps |\n| Official site | [nextjs.org/docs/app/api-reference/turbopack](https://nextjs.org/docs/app/api-reference/turbopack) |\n\n## Overview\n\nTurbopack is an incremental bundler written in Rust and built into Next.js by Vercel. It only recomputes what changed, which keeps dev servers and builds fast in very large apps. It is now the default bundler in recent Next.js versions.\n\n## Key features\n\n- **Incremental computation** — work is cached at function level.\n- **Fast HMR** in large codebases.\n- **Built into Next.js** — no separate install.\n\n## Quick start\n\n```bash\nnpx create-next-app@latest my-app\n# Turbopack is used by default in recent Next.js versions.\n# On older versions:  next dev --turbopack\n```\n\n## Example\n\n```json\n// package.json\n{\n  \"scripts\": {\n    \"dev\": \"next dev\",\n    \"build\": \"next build\"\n  }\n}\n```\n\n## When to choose it\n\n- You build large Next.js applications.\n\n## Think twice if\n\n- You are not using Next.js — it is not a general standalone bundler for other projects.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Rspack](#rspack) — Rust-based, webpack-compatible bundler.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://nextjs.org/docs/app/api-reference/turbopack).*\n"
  },
  {
    "slug": "rspack",
    "title": "Rspack",
    "excerpt": "Rust-based, webpack-compatible bundler.",
    "type": "bundler",
    "bestFor": "faster builds without rewriting webpack config",
    "officialUrl": "https://rspack.rs",
    "category": "build",
    "tags": [
      "Build Tools"
    ],
    "featured": false,
    "date": "2026-09-26",
    "content": "# Rspack\n\n> Rust-based, webpack-compatible bundler.\n\n| Field | Detail |\n|---|---|\n| Type | bundler |\n| Category | Frontend build tools |\n| Best for | faster builds without rewriting webpack config |\n| Official site | [rspack.rs](https://rspack.rs) |\n\n## Overview\n\nRspack is a Rust-based bundler from ByteDance that is compatible with most webpack configuration and loaders. It lets teams get much faster builds without rewriting their webpack setup. Rsbuild is its easy, batteries-included layer.\n\n## Key features\n\n- **webpack-compatible** config and most loaders/plugins.\n- **Much faster builds** thanks to Rust.\n- **Rsbuild** — simple zero-config layer on top.\n- **Module Federation** support.\n\n## Quick start\n\n```bash\nnpm create rspack@latest\n```\n\n## Example\n\n```js\n// rspack.config.js — looks just like webpack\nmodule.exports = {\n  entry: './src/index.js',\n  module: {\n    rules: [{ test: /\\.css$/, type: 'css' }],\n  },\n};\n```\n\n## When to choose it\n\n- You have a slow webpack project and want speed without a rewrite.\n\n## Think twice if\n\n- You are starting fresh with no webpack history — Vite may be simpler.\n\n## Related\n\n- [Vite](#vite) — Fast dev server and bundler using native ES modules.\n- [Webpack](#webpack) — Highly configurable module bundler with a vast plugin ecosystem.\n- [Parcel](#parcel) — Zero-configuration bundler.\n- [Rollup](#rollup) — ES-module bundler favoured for libraries.\n- [esbuild](#esbuild) — Extremely fast bundler written in Go.\n- [Turbopack](#turbopack) — Rust-based incremental bundler built for Next.js.\n\n---\n\n*Written for the MND Code library · November 2026. Versions change quickly — always confirm details in the [official documentation](https://rspack.rs).*\n"
  }
];

export default articles;
