/**
 * Social profiles. Replace each `url` with your real profile link.
 * Entries with an empty url are hidden automatically.
 * `icon` is a key in SOCIAL_ICONS in src/components/SocialLinks.jsx.
 */

const socials = [
  { name: 'GitHub', icon: 'github', url: 'https://github.com/' },
  { name: 'LinkedIn', icon: 'linkedin', url: 'https://www.linkedin.com/' },
  { name: 'Instagram', icon: 'instagram', url: 'https://www.instagram.com/' },
  { name: 'Facebook', icon: 'facebook', url: 'https://www.facebook.com/' },
  { name: 'X (Twitter)', icon: 'twitter', url: 'https://x.com/' },
];

export default socials.filter((s) => s.url);
