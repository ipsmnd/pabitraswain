/**
 * Work history and education for the /experience timeline.
 * Newest first. `type` is 'work' or 'education'.
 */

const experience = [
  {
    type: 'work',
    title: 'Freshina',
    role: 'UI/UX Designer',
    period: 'Jun 2022 – Present',
    description: 'Web application UI design for a milk & dairy product platform, currently in progress.',
    tag: 'UI/UX Design',
  },
  {
    type: 'work',
    title: 'Tenvents',
    role: 'UI/UX Designer',
    period: 'Jul 2022 – Aug 2023',
    description:
      'UI/UX design for an event management company based in Bhubaneswar, serving corporate and personal events across Eastern India.',
    tag: 'UI/UX Design',
  },
  {
    type: 'work',
    title: 'LSS Security Services',
    role: 'Web Designer',
    period: 'Apr – May 2023',
    description: 'Website design for a fully licensed security company — Taurus Protection Inc.',
    tag: 'Website Design',
  },
  {
    type: 'work',
    title: 'AKS Fast Food & Restaurant',
    role: 'Web Designer',
    period: 'Mar 2023',
    description: 'Website design showcasing culinary offerings in a warm, inviting ambiance.',
    tag: 'Website Design',
  },
  {
    type: 'work',
    title: 'Smartshopee',
    role: 'Web Designer & Developer',
    period: 'May – Oct 2022',
    description: 'E-commerce website UI design and development.',
    tag: 'Website Design',
  },
  {
    type: 'education',
    title: 'BCA, Berhampur University',
    role: "Bachelor's in Computer Application",
    period: '2016 – 2019',
    description: 'Programming, databases, web technologies and software engineering.',
    tag: 'Degree',
  },
  {
    type: 'education',
    title: '+2 Science',
    role: 'Higher Secondary, Odisha',
    period: '2014 – 2016',
    description: 'Science stream.',
    tag: 'Higher Secondary',
  },
  {
    type: 'education',
    title: 'Raghunatha High School',
    role: 'Secondary School',
    period: '2004 – 2014',
    description: 'Schooling.',
    tag: 'School',
  },
];

export default experience;
