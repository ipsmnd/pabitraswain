import { createContext, createElement, useCallback, useContext, useEffect, useState } from 'react';
import { THEME_STORAGE_KEY } from '../scripts/constants';

/**
 * Dark/light theme, saved in localStorage.
 * Wrap the app in <ThemeProvider> and call useTheme() anywhere.
 */
const ThemeContext = createContext({ theme: 'dark', toggleTheme: () => {} });

function getInitialTheme() {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {
    /* storage blocked — fall through */
  }
  // Default to dark (the site's signature look) unless the OS asks for light.
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(getInitialTheme);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.style.colorScheme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#070b1f' : '#eef1fb');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  const toggleTheme = useCallback(() => setTheme((t) => (t === 'dark' ? 'light' : 'dark')), []);

  return createElement(ThemeContext.Provider, { value: { theme, toggleTheme } }, children);
}

export default function useTheme() {
  return useContext(ThemeContext);
}
