import { useInView, useReducedMotion } from 'framer-motion';
import { useRef } from 'react';

/**
 * Scroll-reveal helper.
 *   const { ref, motionProps } = useScrollAnimation();
 *   <motion.div ref={ref} {...motionProps}>...</motion.div>
 * `inView` is also returned for things like progress bars and counters.
 */
export default function useScrollAnimation({ delay = 0, y = 40, once = true, amount = 0.15 } = {}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once, amount });
  const reduce = useReducedMotion();

  const motionProps = reduce
    ? {}
    : {
        initial: { opacity: 0, y, scale: 0.98 },
        animate: inView ? { opacity: 1, y: 0, scale: 1 } : {},
        transition: { duration: 0.8, delay, ease: [0.2, 0.8, 0.2, 1] },
      };

  return { ref, inView: reduce ? true : inView, motionProps };
}
