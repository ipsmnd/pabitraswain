import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { FiX } from 'react-icons/fi';

const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

/**
 * Accessible modal dialog.
 * - Escape and backdrop click close it
 * - Focus moves inside, stays trapped, and returns to the opener on close
 * - Page scroll is locked while open
 */
export default function Modal({ open, onClose, labelledBy, children, onKeyDown }) {
  const panelRef = useRef(null);
  // Keep the latest callbacks in refs so the effect below runs only on open/close.
  const closeRef = useRef(onClose);
  const keyRef = useRef(onKeyDown);
  closeRef.current = onClose;
  keyRef.current = onKeyDown;

  useEffect(() => {
    if (!open) return undefined;
    const opener = document.activeElement;
    document.body.style.overflow = 'hidden';
    // Focus the first focusable element after the enter animation starts.
    const id = requestAnimationFrame(() => panelRef.current?.querySelector(FOCUSABLE)?.focus());

    const onKey = (e) => {
      if (e.key === 'Escape') closeRef.current();
      if (e.key === 'Tab' && panelRef.current) {
        const nodes = [...panelRef.current.querySelectorAll(FOCUSABLE)];
        if (!nodes.length) return;
        const first = nodes[0];
        const last = nodes[nodes.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
      keyRef.current?.(e);
    };
    document.addEventListener('keydown', onKey);

    return () => {
      cancelAnimationFrame(id);
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      opener?.focus?.();
    };
  }, [open]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[60] grid place-items-center bg-night-950/75 p-4 backdrop-blur-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={labelledBy}
            className="glass-card relative max-h-[90vh] w-full max-w-2xl overflow-y-auto !bg-mist-50 dark:!bg-night-850"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 320, damping: 30 }}
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="icon-btn absolute right-3 top-3 z-10 !bg-night-900/70 !text-white backdrop-blur"
            >
              <FiX aria-hidden="true" />
            </button>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
