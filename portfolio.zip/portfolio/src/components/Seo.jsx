import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { SITE } from '../scripts/constants';

/** Create or update a <meta> tag in <head>. */
function setMeta(attr, key, content) {
  if (!content) return;
  let el = document.head.querySelector(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setCanonical(href) {
  let el = document.head.querySelector('link[rel="canonical"]');
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', 'canonical');
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

/**
 * Per-route page title, description and Open Graph tags.
 * <Seo title="Projects" description="..." />
 */
export default function Seo({ title, description = SITE.intro, image = '/og-avatar.webp', type = 'website' }) {
  const { pathname } = useLocation();

  useEffect(() => {
    const fullTitle = title ? `${title} | ${SITE.name}` : `${SITE.name} – ${SITE.title}`;
    const url = `${SITE.url}${pathname}`;
    const imageUrl = image.startsWith('http') ? image : `${SITE.url}${image}`;

    document.title = fullTitle;
    setMeta('name', 'description', description);
    setMeta('property', 'og:title', fullTitle);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:type', type);
    setMeta('property', 'og:url', url);
    setMeta('property', 'og:image', imageUrl);
    setMeta('name', 'twitter:title', fullTitle);
    setMeta('name', 'twitter:description', description);
    setCanonical(url);
  }, [title, description, image, type, pathname]);

  return null;
}
