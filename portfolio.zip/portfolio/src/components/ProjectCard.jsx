import { useRef } from 'react';
import { motion } from 'framer-motion';
import { FiMaximize2 } from 'react-icons/fi';

/**
 * Project thumbnail with a hover tilt and a caption that slides up.
 * The whole card is a button that opens the detail modal.
 */
export default function ProjectCard({ project, onOpen, index = 0 }) {
  const ref = useRef(null);

  // Subtle 3D tilt that follows the mouse (desktop only).
  const onMove = (e) => {
    if (e.pointerType !== 'mouse' || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `perspective(900px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg)`;
  };
  const onLeave = () => {
    if (ref.current) ref.current.style.transform = '';
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 50, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, delay: Math.min(index * 0.06, 0.4), ease: [0.2, 0.8, 0.2, 1] }}
    >
      <button
        type="button"
        onClick={() => onOpen(project)}
        onPointerMove={onMove}
        onPointerLeave={onLeave}
        aria-label={`Open details for ${project.title}`}
        className="group block w-full text-left"
      >
        <div
          ref={ref}
          className="relative aspect-[16/10] overflow-hidden rounded-3xl border border-night-800/10 bg-night-850 transition-[transform,box-shadow,border-color] duration-300 ease-out group-hover:border-primary-400 group-hover:shadow-glow group-focus-visible:border-primary-400 dark:border-white/10"
        >
          <img
            src={project.image}
            alt={`${project.title} — ${project.description}`}
            loading="lazy"
            decoding="async"
            width="900"
            height="563"
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          />
          <span className="absolute right-3 top-3 grid h-9 w-9 scale-100 place-items-center rounded-full bg-night-900/70 text-white backdrop-blur transition duration-300 group-hover:rotate-90 md:scale-0 md:group-hover:scale-100">
            <FiMaximize2 size={14} aria-hidden="true" />
          </span>
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-night-950/95 to-transparent px-4 pb-4 pt-10 text-white transition-transform duration-500 md:translate-y-[52%] md:group-hover:translate-y-0 md:group-focus-visible:translate-y-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-cyan-400">{project.kind}</p>
            <h3 className="font-display text-base font-bold">{project.title}</h3>
            <p className="mt-0.5 text-xs text-[#cdd3f5]">{project.description}</p>
            <ul className="mt-2 flex flex-wrap gap-1.5" aria-label="Tools used">
              {project.tech.slice(0, 4).map((t) => (
                <li key={t} className="rounded-lg bg-white/15 px-2 py-0.5 text-[10px] font-semibold">
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </button>
    </motion.article>
  );
}
