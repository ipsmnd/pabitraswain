/** Shown while a lazy-loaded page downloads. */
export default function Loader() {
  return (
    <div className="grid min-h-[60vh] place-items-center" role="status" aria-live="polite">
      <div className="flex flex-col items-center gap-4">
        <div className="relative h-14 w-14">
          <span className="absolute inset-0 rounded-full border-4 border-primary-500/20" />
          <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-primary-500 border-r-accent-500" />
        </div>
        <span className="muted text-xs font-semibold uppercase tracking-[0.2em]">Loading…</span>
      </div>
    </div>
  );
}
