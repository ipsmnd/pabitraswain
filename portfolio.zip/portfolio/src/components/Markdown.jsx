import { useState } from 'react';
import { Link } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { FiCheck, FiCopy } from 'react-icons/fi';
import { copyToClipboard, slugify } from '../scripts/utils';

/** Code block with a language label and a copy button. */
function CodeBlock({ language, code }) {
  const [copied, setCopied] = useState(false);
  const onCopy = async () => {
    if (await copyToClipboard(code)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }
  };
  return (
    <div className="not-prose my-5 overflow-hidden rounded-2xl border border-white/10 bg-[#0a0e24]">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
        <span className="flex items-center gap-1.5" aria-hidden="true">
          <i className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
          <i className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
          <i className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
        </span>
        <span className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-cyan-400">{language || 'code'}</span>
        <button
          type="button"
          onClick={onCopy}
          className="inline-flex items-center gap-1 rounded-lg border border-white/10 px-2 py-1 text-[11px] font-semibold text-[#cdd3f5] transition hover:bg-accent-500 hover:text-white"
          aria-label={copied ? 'Copied' : 'Copy code'}
        >
          {copied ? <FiCheck aria-hidden="true" /> : <FiCopy aria-hidden="true" />} {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-[13px] leading-relaxed text-[#cdd3f5]">
        <code>{code}</code>
      </pre>
    </div>
  );
}

const textOf = (children) =>
  [children]
    .flat()
    .map((c) => (typeof c === 'string' ? c : c?.props?.children ? textOf(c.props.children) : ''))
    .join('');

/**
 * Renders article Markdown.
 * Internal links like "[Vue.js](#vue-js)" become /articles/vue-js routes.
 */
export default function Markdown({ content }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        // The page already shows the title, so skip the Markdown H1.
        h1: () => null,
        h2: ({ children }) => (
          <h2 id={`s-${slugify(textOf(children))}`} className="scroll-mt-28">
            {children}
          </h2>
        ),
        a: ({ href = '', children }) => {
          if (href.startsWith('#')) return <Link to={`/articles/${href.slice(1)}`}>{children}</Link>;
          return (
            <a href={href} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          );
        },
        pre: ({ children }) => children,
        code: ({ className, children }) => {
          const match = /language-(\w+)/.exec(className || '');
          const code = String(children).replace(/\n$/, '');
          // Block code has a language class or spans several lines.
          if (match || code.includes('\n')) return <CodeBlock language={match?.[1]} code={code} />;
          return <code>{children}</code>;
        },
        table: ({ children }) => (
          <div className="overflow-x-auto">
            <table>{children}</table>
          </div>
        ),
      }}
    >
      {content}
    </ReactMarkdown>
  );
}
