import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowRight, FiDownload } from 'react-icons/fi';
import SocialLinks from './SocialLinks';
import Counter from './Counter';
import { SITE, TYPING_ROLES } from '../scripts/constants';
import { prefersReducedMotion } from '../scripts/utils';

/** Types, pauses, deletes and moves on to the next role. */
function useTypingText(words, { typeSpeed = 90, deleteSpeed = 45, pause = 2000 } = {}) {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (prefersReducedMotion()) {
      setText(words[0]);
      return undefined;
    }
    const word = words[index % words.length];
    let delay = deleting ? deleteSpeed : typeSpeed;

    if (!deleting && text === word) delay = pause;
    else if (deleting && text === '') delay = 300;

    const id = setTimeout(() => {
      if (!deleting && text === word) setDeleting(true);
      else if (deleting && text === '') {
        setDeleting(false);
        setIndex((i) => i + 1);
      } else setText(word.slice(0, text.length + (deleting ? -1 : 1)));
    }, delay);
    return () => clearTimeout(id);
  }, [text, deleting, index, words, typeSpeed, deleteSpeed, pause]);

  return text;
}

const item = {
  hidden: { opacity: 0, y: 24 },
  show: (i) => ({ opacity: 1, y: 0, transition: { delay: 0.1 * i, duration: 0.7, ease: [0.2, 0.8, 0.2, 1] } }),
};

export default function Hero() {
  const role = useTypingText(TYPING_ROLES);

  return (
    <section aria-labelledby="hero-title" className="glass-card grid min-h-[420px] overflow-hidden md:grid-cols-[1.1fr_1fr]">
      {/* Text */}
      <div className="relative z-10 px-6 py-10 sm:px-10 sm:py-12">
        <motion.span custom={0} variants={item} initial="hidden" animate="show" className="tag gap-2">
          <span className="h-2 w-2 rounded-full bg-emerald-400 motion-safe:animate-pulse-dot" aria-hidden="true" />
          {SITE.available ? 'Available for work' : 'Currently booked'}
        </motion.span>

        <motion.p custom={1} variants={item} initial="hidden" animate="show" className="muted mt-7 text-lg">
          Hey, I&apos;m
        </motion.p>
        <motion.h1
          id="hero-title"
          custom={2}
          variants={item}
          initial="hidden"
          animate="show"
          className="gradient-text font-display text-5xl font-black leading-[1.05] tracking-tighter drop-shadow-[0_0_18px_rgba(79,107,255,0.4)] sm:text-6xl lg:text-7xl"
        >
          {SITE.name}
        </motion.h1>

        <motion.p custom={3} variants={item} initial="hidden" animate="show" className="mt-5 min-h-[2rem] text-xl font-bold" aria-live="off">
          <span className="sr-only">{TYPING_ROLES.join(', ')}</span>
          <span aria-hidden="true">{role}</span>
          <span className="ml-1 inline-block h-5 w-0.5 translate-y-0.5 bg-cyan-500 motion-safe:animate-blink" aria-hidden="true" />
        </motion.p>

        <motion.p custom={4} variants={item} initial="hidden" animate="show" className="muted mt-3 max-w-sm text-sm">
          {SITE.intro}
        </motion.p>

        <motion.div custom={5} variants={item} initial="hidden" animate="show" className="mt-7 flex flex-wrap gap-3">
          <Link to="/projects" className="btn-primary flex-1 sm:flex-none">
            View Projects <FiArrowRight aria-hidden="true" />
          </Link>
          <a href={SITE.resumeUrl} download className="btn-ghost flex-1 sm:flex-none">
            <FiDownload aria-hidden="true" /> Download CV
          </a>
        </motion.div>

        <motion.div custom={6} variants={item} initial="hidden" animate="show" className="mt-7">
          <SocialLinks />
        </motion.div>
      </div>

      {/* Photo */}
      <div className="relative min-h-[340px]">
        <div
          className="absolute inset-[8%_6%_0] rounded-full bg-[radial-gradient(#4a3cff88,transparent_65%)] motion-safe:animate-float"
          aria-hidden="true"
        />
        <motion.img
          src={SITE.avatar}
          alt={`Portrait of ${SITE.name}`}
          width="700"
          height="560"
          fetchpriority="high"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="absolute inset-0 h-full w-full object-cover object-[center_20%] [mask-image:linear-gradient(180deg,transparent,#000_25%)] md:[mask-image:linear-gradient(90deg,transparent,#000_22%)]"
        />
        <div className="absolute bottom-5 right-5 flex items-center gap-2 rounded-2xl border border-white/10 bg-night-900/85 px-4 py-2.5 text-[10px] font-bold uppercase leading-tight text-white motion-safe:animate-float-fast">
          <b className="text-2xl text-primary-400">
            <Counter value={3.5} suffix="+" />
          </b>
          <span>
            Years of
            <br />
            Experience
          </span>
        </div>
      </div>
    </section>
  );
}
