import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { TESTIMONIALS } from '../scripts/constants';
import { cn } from '../scripts/utils';

/** Auto-advancing testimonial carousel (pauses on hover/focus). */
export default function Testimonials() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const total = TESTIMONIALS.length;

  const go = useCallback((dir) => setIndex((i) => (i + dir + total) % total), [total]);

  useEffect(() => {
    if (paused) return undefined;
    const id = setInterval(() => go(1), 5000);
    return () => clearInterval(id);
  }, [paused, go]);

  const t = TESTIMONIALS[index];

  return (
    <div
      className="glass-card mx-auto max-w-3xl p-8 text-center sm:p-12"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      role="region"
      aria-roledescription="carousel"
      aria-label="Testimonials"
    >
      <span className="font-display text-5xl font-black leading-none text-accent-500" aria-hidden="true">
        ❝
      </span>
      <div className="relative min-h-[130px]" aria-live="polite">
        <AnimatePresence mode="wait">
          <motion.figure
            key={index}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.4 }}
          >
            <p className="text-sm tracking-[2px] text-amber-400" aria-label="Rated 5 out of 5">
              ★★★★★
            </p>
            <blockquote className="mt-3 text-lg font-medium sm:text-xl">“{t.quote}”</blockquote>
            <figcaption className="mt-4 text-sm font-bold">
              {t.name}
              <span className="muted block text-xs font-medium">{t.role}</span>
            </figcaption>
          </motion.figure>
        </AnimatePresence>
      </div>

      <div className="mt-6 flex items-center justify-center gap-3">
        <button type="button" className="icon-btn" onClick={() => go(-1)} aria-label="Previous testimonial">
          <FiChevronLeft aria-hidden="true" />
        </button>
        <div className="flex gap-2">
          {TESTIMONIALS.map((item, i) => (
            <button
              key={item.name}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show testimonial ${i + 1}`}
              aria-current={i === index}
              className={cn('h-1.5 rounded-full transition-all', i === index ? 'w-5 bg-primary-500' : 'w-1.5 bg-night-800/25 dark:bg-white/25')}
            />
          ))}
        </div>
        <button type="button" className="icon-btn" onClick={() => go(1)} aria-label="Next testimonial">
          <FiChevronRight aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
