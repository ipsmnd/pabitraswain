import { Link } from 'react-router-dom';
import { FiMail, FiPhone } from 'react-icons/fi';
import SocialLinks from './SocialLinks';
import { NAV_LINKS, SITE } from '../scripts/constants';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-24 border-t border-night-800/10 dark:border-white/10">
      <div className="container-page grid gap-10 py-12 md:grid-cols-3">
        <div>
          <p className="font-display text-xl font-bold">{SITE.name}</p>
          <p className="muted mt-2 max-w-xs text-sm">{SITE.title}. Building clean, fast and friendly web experiences.</p>
          <SocialLinks className="mt-4" />
        </div>

        <nav aria-label="Footer">
          <p className="section-label mb-3">Pages</p>
          <ul className="grid grid-cols-2 gap-2 text-sm">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="muted transition hover:text-primary-600 dark:hover:text-cyan-400">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="section-label mb-3">Get in touch</p>
          <ul className="space-y-2 text-sm">
            <li>
              <a href={`mailto:${SITE.email}`} className="inline-flex items-center gap-2 hover:text-primary-600 dark:hover:text-cyan-400">
                <FiMail aria-hidden="true" /> {SITE.email}
              </a>
            </li>
            <li>
              <a href={`tel:${SITE.phone.replace(/\s/g, '')}`} className="inline-flex items-center gap-2 hover:text-primary-600 dark:hover:text-cyan-400">
                <FiPhone aria-hidden="true" /> {SITE.phone}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <p className="muted border-t border-night-800/10 py-6 text-center text-xs dark:border-white/10">
        © {year} <b className="text-night-800 dark:text-white">{SITE.brand}</b> — {SITE.tagline}
      </p>
    </footer>
  );
}
