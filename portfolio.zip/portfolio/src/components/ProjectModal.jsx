import { useCallback } from 'react';
import { FiChevronLeft, FiChevronRight, FiExternalLink, FiGithub } from 'react-icons/fi';
import Modal from './Modal';

/**
 * Project detail view inside <Modal>.
 * `list` is the currently visible projects, so Prev/Next (and ← →) follow the active filter.
 */
export default function ProjectModal({ project, list, onChange, onClose }) {
  const index = project ? list.findIndex((p) => p.id === project.id) : -1;

  const step = useCallback(
    (dir) => {
      if (index < 0 || list.length < 2) return;
      onChange(list[(index + dir + list.length) % list.length]);
    },
    [index, list, onChange],
  );

  const onKeyDown = useCallback(
    (e) => {
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    },
    [step],
  );

  return (
    <Modal open={Boolean(project)} onClose={onClose} labelledBy="project-modal-title" onKeyDown={onKeyDown}>
      {project && (
        <>
          <img src={project.image} alt={project.title} className="aspect-[16/9] w-full object-cover" width="900" height="506" />
          <div className="p-6 sm:p-8">
            <p className="section-label">{project.kind}</p>
            <h2 id="project-modal-title" className="mt-1 text-2xl font-extrabold">
              {project.title}
            </h2>
            <p className="muted mt-3 text-sm leading-relaxed">{project.details}</p>

            <h3 className="mt-6 text-xs font-bold uppercase tracking-[0.12em]">Tools &amp; tech</h3>
            <ul className="mt-2 flex flex-wrap gap-2">
              {project.tech.map((t) => (
                <li key={t} className="tag">
                  {t}
                </li>
              ))}
            </ul>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              {project.liveUrl && (
                <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="btn-primary">
                  <FiExternalLink aria-hidden="true" /> Live demo
                </a>
              )}
              {project.githubUrl && (
                <a href={project.githubUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                  <FiGithub aria-hidden="true" /> Source code
                </a>
              )}
              {list.length > 1 && (
                <div className="ml-auto flex items-center gap-2">
                  <span className="muted text-xs font-semibold">
                    {index + 1} / {list.length}
                  </span>
                  <button type="button" className="icon-btn" onClick={() => step(-1)} aria-label="Previous project">
                    <FiChevronLeft aria-hidden="true" />
                  </button>
                  <button type="button" className="icon-btn" onClick={() => step(1)} aria-label="Next project">
                    <FiChevronRight aria-hidden="true" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </Modal>
  );
}
