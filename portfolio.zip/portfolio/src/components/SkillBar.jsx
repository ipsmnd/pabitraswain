import { motion } from 'framer-motion';
import { FaBootstrap, FaFigma, FaHtml5, FaJs, FaWordpress } from 'react-icons/fa6';
import { SiJquery } from 'react-icons/si';
import { TbBrandAdobeIllustrator, TbBrandAdobePhotoshop } from 'react-icons/tb';
import { FiClock, FiMessageCircle, FiCode } from 'react-icons/fi';
import { LuBrainCircuit, LuPuzzle, LuBraces } from 'react-icons/lu';
import useScrollAnimation from '../hooks/useScrollAnimation';

/** Icon keys used in data/skills.js. Add a key here to use a new icon. */
export const SKILL_ICONS = {
  html: FaHtml5,
  bootstrap: FaBootstrap,
  js: FaJs,
  jquery: SiJquery,
  wordpress: FaWordpress,
  json: LuBraces,
  photoshop: TbBrandAdobePhotoshop,
  figma: FaFigma,
  illustrator: TbBrandAdobeIllustrator,
  chat: FiMessageCircle,
  idea: LuBrainCircuit,
  puzzle: LuPuzzle,
  clock: FiClock,
};

/**
 * One skill. With a `level` it renders an animated progress bar;
 * without one it renders as an icon card (soft skills).
 */
export default function SkillBar({ skill, index = 0 }) {
  const { ref, inView } = useScrollAnimation({ amount: 0.4 });
  const Icon = SKILL_ICONS[skill.icon] ?? FiCode;
  const hasLevel = typeof skill.level === 'number';

  return (
    <motion.div
      ref={ref}
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.3) }}
      className="glass-card glass-card-hover p-5"
    >
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-gradient text-white shadow-glow-sm">
          <Icon size={18} aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-2">
            <h3 className="truncate text-sm font-semibold">{skill.name}</h3>
            {hasLevel && <span className="muted text-xs font-semibold">{skill.level}%</span>}
          </div>
          {hasLevel ? (
            <div
              className="mt-2 h-1.5 overflow-hidden rounded-full bg-night-800/10 dark:bg-white/10"
              role="progressbar"
              aria-label={`${skill.name} proficiency`}
              aria-valuenow={skill.level}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <motion.span
                className="bar-shimmer relative block h-full rounded-full bg-gradient-to-r from-primary-500 to-cyan-400"
                initial={{ width: 0 }}
                animate={{ width: inView ? `${skill.level}%` : 0 }}
                transition={{ duration: 1.4, ease: [0.2, 0.8, 0.2, 1] }}
              />
            </div>
          ) : (
            <p className="muted mt-1 text-xs">Soft skill</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
