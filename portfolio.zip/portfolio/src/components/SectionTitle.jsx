import { motion } from 'framer-motion';
import useScrollAnimation from '../hooks/useScrollAnimation';
import { cn } from '../scripts/utils';

/**
 * Small label + heading + optional subtitle.
 * Use `as="h1"` for the main heading of a page.
 */
export default function SectionTitle({ label, title, subtitle, as: Heading = 'h2', align = 'left', className = '', children }) {
  const { ref, motionProps } = useScrollAnimation({ y: 24 });

  return (
    <motion.div ref={ref} {...motionProps} className={cn(align === 'center' && 'mx-auto text-center', 'max-w-2xl', className)}>
      {label && <p className="section-label">{label}</p>}
      <Heading
        className={cn(
          'mt-2 font-extrabold leading-tight',
          Heading === 'h1' ? 'text-4xl sm:text-5xl' : 'text-3xl sm:text-4xl',
        )}
      >
        {title}
      </Heading>
      {subtitle && <p className="muted mt-3 text-sm sm:text-base">{subtitle}</p>}
      {children}
    </motion.div>
  );
}
