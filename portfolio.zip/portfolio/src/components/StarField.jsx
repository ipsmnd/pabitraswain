import { useEffect, useRef } from 'react';
import useTheme from '../hooks/useTheme';
import { prefersReducedMotion } from '../scripts/utils';

/** Softly twinkling, slowly rising stars drawn on a fixed canvas. */
export default function StarField() {
  const canvasRef = useRef(null);
  const { theme } = useTheme();
  const themeRef = useRef(theme);
  themeRef.current = theme;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const still = prefersReducedMotion();
    let stars = [];
    let frame;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const count = window.innerWidth < 768 ? 60 : 110;
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.3 + 0.2,
        p: Math.random() * 6,
        v: Math.random() * 0.15 + 0.03,
      }));
    };

    const draw = (t) => {
      const light = themeRef.current === 'light';
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = light ? '#4a5aa8' : '#cfd8ff';
      stars.forEach((s) => {
        if (!still) {
          s.y -= s.v;
          if (s.y < 0) s.y = canvas.height;
        }
        ctx.globalAlpha = light ? 0.15 : 0.3 + 0.6 * Math.abs(Math.sin(t / 900 + s.p));
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      });
      if (!still) frame = requestAnimationFrame(draw);
    };

    resize();
    draw(0);
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />;
}
