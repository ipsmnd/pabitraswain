import { motion } from 'framer-motion';
import useScrollAnimation from '../hooks/useScrollAnimation';

/** Fades and lifts its children into view when scrolled to. */
export default function Reveal({ as = 'div', delay = 0, y = 40, className = '', children, ...rest }) {
  const { ref, motionProps } = useScrollAnimation({ delay, y });
  const Tag = motion[as] ?? motion.div;
  return (
    <Tag ref={ref} {...motionProps} className={className} {...rest}>
      {children}
    </Tag>
  );
}
