import { motion } from 'framer-motion';
import { FiCode, FiPenTool, FiTool } from 'react-icons/fi';
import { FaWordpress } from 'react-icons/fa6';
import { SERVICES } from '../scripts/constants';
import { cn } from '../scripts/utils';

const ICONS = { code: FiCode, design: FiPenTool, wordpress: FaWordpress, support: FiTool };

/** Four colourful service tiles. */
export default function Services() {
  return (
    <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {SERVICES.map((s, i) => {
        const Icon = ICONS[s.icon] ?? FiCode;
        return (
          <motion.li
            key={s.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            whileHover={{ y: -8, rotate: -1 }}
            className={cn('group rounded-3xl bg-gradient-to-br p-6 text-white/75', s.tone)}
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/20 text-white transition-transform duration-500 group-hover:rotate-[360deg]">
              <Icon aria-hidden="true" />
            </span>
            <h3 className="mt-4 text-base font-bold text-white">{s.title}</h3>
            <p className="mt-1 text-sm">{s.text}</p>
          </motion.li>
        );
      })}
    </ul>
  );
}
