import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { FiMenu, FiX } from 'react-icons/fi';
import ThemeToggle from './ThemeToggle';
import SocialLinks from './SocialLinks';
import { NAV_LINKS, SITE } from '../scripts/constants';
import { cn } from '../scripts/utils';

/** Spinning gold monogram used as the logo. */
function Logo() {
  return (
    <Link
      to="/"
      aria-label={`${SITE.name} — home`}
      className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-2 border-gold-500 bg-gradient-to-br from-night-700 to-[#0c1030] text-[11px] font-extrabold text-gold-300 motion-safe:animate-spin-slow"
    >
      <span className="motion-safe:animate-spin-slow [animation-direction:reverse]">{SITE.shortName}</span>
    </Link>
  );
}

const linkClass = ({ isActive }) =>
  cn(
    'rounded-full px-3.5 py-1.5 text-[13px] font-medium transition duration-300',
    isActive
      ? 'bg-primary-500/15 text-primary-700 dark:bg-primary-400/20 dark:text-white'
      : 'text-night-800/80 hover:bg-primary-500/10 dark:text-[#cdd3f5] dark:hover:bg-white/10',
  );

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  // Make the bar more solid once the page is scrolled.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close the mobile menu when the route changes.
  useEffect(() => setOpen(false), [pathname]);

  // Escape closes the menu; lock page scroll while it is open.
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header className="pointer-events-none fixed inset-x-0 top-0 z-40 flex justify-center px-3 pt-3">
      <motion.nav
        aria-label="Main"
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.2, 0.9, 0.3, 1] }}
        className={cn(
          'pointer-events-auto flex w-full max-w-5xl items-center justify-between rounded-full border backdrop-blur-xl transition-all duration-500',
          scrolled
            ? 'border-night-800/10 bg-white/85 px-4 py-2 shadow-soft dark:border-white/10 dark:bg-night-900/80 dark:shadow-glow'
            : 'border-night-800/10 bg-white/60 px-5 py-2.5 dark:border-white/10 dark:bg-night-800/50',
        )}
      >
        <Logo />

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((l) => (
            <li key={l.to}>
              <NavLink to={l.to} end={l.to === '/'} className={linkClass}>
                {l.label}
              </NavLink>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            type="button"
            className="icon-btn lg:hidden"
            aria-label="Open menu"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen(true)}
          >
            <FiMenu size={18} aria-hidden="true" />
          </button>
        </div>
      </motion.nav>

      {/* Mobile slide-in menu */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              key="overlay"
              className="pointer-events-auto fixed inset-0 z-40 bg-night-950/60 backdrop-blur-sm lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              aria-hidden="true"
            />
            <motion.aside
              key="panel"
              id="mobile-menu"
              role="dialog"
              aria-modal="true"
              aria-label="Menu"
              className="pointer-events-auto fixed inset-y-0 right-0 z-50 flex w-[80%] max-w-xs flex-col border-l border-night-800/10 bg-mist-50 p-6 dark:border-white/10 dark:bg-night-900 lg:hidden"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 34 }}
            >
              <div className="mb-8 flex items-center justify-between">
                <Logo />
                <button type="button" className="icon-btn" aria-label="Close menu" onClick={() => setOpen(false)} autoFocus>
                  <FiX size={18} aria-hidden="true" />
                </button>
              </div>
              <ul className="flex flex-col gap-1">
                {NAV_LINKS.map((l, i) => (
                  <motion.li
                    key={l.to}
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i + 0.1 }}
                  >
                    <NavLink
                      to={l.to}
                      end={l.to === '/'}
                      className={({ isActive }) =>
                        cn(
                          'block rounded-2xl px-4 py-3 text-base font-semibold transition',
                          isActive ? 'bg-brand-gradient text-white' : 'hover:bg-primary-500/10 dark:hover:bg-white/10',
                        )
                      }
                    >
                      {l.label}
                    </NavLink>
                  </motion.li>
                ))}
              </ul>
              <div className="mt-auto pt-6">
                <p className="section-label mb-3">Find me</p>
                <SocialLinks />
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
