import { motion, AnimatePresence } from 'framer-motion';
import { FiMoon, FiSun } from 'react-icons/fi';
import useTheme from '../hooks/useTheme';

/** Round button that flips between dark and light mode. */
export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      className="icon-btn overflow-hidden"
      aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      title={isDark ? 'Light mode' : 'Dark mode'}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={theme}
          initial={{ rotate: -90, opacity: 0, scale: 0.6 }}
          animate={{ rotate: 0, opacity: 1, scale: 1 }}
          exit={{ rotate: 90, opacity: 0, scale: 0.6 }}
          transition={{ duration: 0.25 }}
          className="grid place-items-center"
        >
          {isDark ? <FiMoon size={17} aria-hidden="true" /> : <FiSun size={17} aria-hidden="true" />}
        </motion.span>
      </AnimatePresence>
    </button>
  );
}
