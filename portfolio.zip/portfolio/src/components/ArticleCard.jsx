import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiCalendar, FiClock, FiStar } from 'react-icons/fi';
import { ARTICLE_CATEGORIES } from '../data/articles';
import { cn, formatDate, initials, readingTime } from '../scripts/utils';

/**
 * Generated cover: category gradient + monogram.
 * Swap for <img src={article.cover} /> if you add cover images to the data.
 */
export function ArticleCover({ article, className = '' }) {
  const cat = ARTICLE_CATEGORIES[article.category];
  return (
    <div className={cn('relative overflow-hidden bg-gradient-to-br', cat?.cover, className)} aria-hidden="true">
      <span className="absolute -right-6 -top-10 font-display text-[120px] font-black leading-none text-white/10">
        {initials(article.title)}
      </span>
      <span className="absolute bottom-4 left-4 grid h-11 w-11 place-items-center rounded-xl bg-white/20 font-display text-sm font-extrabold text-white backdrop-blur">
        {initials(article.title)}
      </span>
    </div>
  );
}

export default function ArticleCard({ article, index = 0 }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.04, 0.3) }}
      className="glass-card glass-card-hover group flex flex-col hover:-translate-y-1"
    >
      <Link to={`/articles/${article.slug}`} className="flex flex-1 flex-col focus-visible:ring-inset">
        <ArticleCover article={article} className="h-36 transition-transform duration-500 group-hover:scale-[1.03]" />
        <div className="flex flex-1 flex-col p-5">
          <div className="muted flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-medium">
            <span className="inline-flex items-center gap-1">
              <FiCalendar aria-hidden="true" />
              <time dateTime={article.date}>{formatDate(article.date)}</time>
            </span>
            <span className="inline-flex items-center gap-1">
              <FiClock aria-hidden="true" /> {readingTime(article.content)} min read
            </span>
            {article.featured && (
              <span className="inline-flex items-center gap-1 text-gold-500">
                <FiStar aria-hidden="true" /> Top pick
              </span>
            )}
          </div>
          <h3 className="mt-2 text-lg font-bold transition group-hover:text-primary-600 dark:group-hover:text-cyan-400">{article.title}</h3>
          <p className="muted mt-1 line-clamp-2 text-sm">{article.excerpt}</p>
          <ul className="mt-auto flex flex-wrap gap-1.5 pt-4" aria-label="Tags">
            <li className="tag">{article.type}</li>
            {article.tags.map((t) => (
              <li key={t} className="tag">
                {t}
              </li>
            ))}
          </ul>
        </div>
      </Link>
    </motion.article>
  );
}
