import { motion } from 'framer-motion';
import { FiBookOpen, FiBriefcase } from 'react-icons/fi';

/**
 * Vertical timeline. Alternates sides on large screens,
 * single column on phones. Each entry slides in as it scrolls into view.
 */
export default function Timeline({ items }) {
  return (
    <ol className="relative mx-auto max-w-4xl">
      {/* Centre / left line */}
      <span
        className="absolute bottom-0 left-4 top-0 w-px bg-gradient-to-b from-primary-500 via-accent-500 to-transparent lg:left-1/2"
        aria-hidden="true"
      />
      {items.map((item, i) => {
        const left = i % 2 === 0;
        const Icon = item.type === 'education' ? FiBookOpen : FiBriefcase;
        return (
          <li key={`${item.title}-${item.period}`} className="relative mb-8 pl-12 lg:grid lg:grid-cols-2 lg:gap-12 lg:pl-0">
            {/* Dot */}
            <span
              className="timeline-dot absolute left-4 top-6 z-10 grid h-8 w-8 -translate-x-1/2 place-items-center rounded-full bg-brand-gradient text-white lg:left-1/2"
              aria-hidden="true"
            >
              <Icon size={14} />
            </span>

            <motion.div
              initial={{ opacity: 0, x: left ? -40 : 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
              className={left ? 'lg:col-start-1 lg:text-right' : 'lg:col-start-2'}
            >
              <article className="glass-card glass-card-hover p-6">
                <p className="text-xs font-semibold text-primary-600 dark:text-cyan-400">{item.period}</p>
                <h3 className="mt-1 text-lg font-bold">{item.title}</h3>
                <p className="text-sm font-medium">{item.role}</p>
                <p className="muted mt-2 text-sm">{item.description}</p>
                <span className="mt-3 inline-block text-[10px] font-bold uppercase tracking-[0.1em] text-primary-500">{item.tag}</span>
              </article>
            </motion.div>
          </li>
        );
      })}
    </ol>
  );
}
