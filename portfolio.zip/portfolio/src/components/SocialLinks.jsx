import { FaFacebookF, FaGithub, FaInstagram, FaLinkedinIn, FaXTwitter } from 'react-icons/fa6';
import socials from '../data/socials';
import { cn } from '../scripts/utils';

/** Map of icon keys used in data/socials.js. Add more here if needed. */
export const SOCIAL_ICONS = {
  github: FaGithub,
  linkedin: FaLinkedinIn,
  instagram: FaInstagram,
  facebook: FaFacebookF,
  twitter: FaXTwitter,
};

/** Row of round social icon links. */
export default function SocialLinks({ className = '' }) {
  return (
    <ul className={cn('flex flex-wrap gap-2', className)}>
      {socials.map((s) => {
        const Icon = SOCIAL_ICONS[s.icon];
        return (
          <li key={s.name}>
            <a
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={s.name}
              title={s.name}
              className="icon-btn hover:-translate-y-1"
            >
              {Icon ? <Icon size={15} aria-hidden="true" /> : s.name[0]}
            </a>
          </li>
        );
      })}
    </ul>
  );
}
