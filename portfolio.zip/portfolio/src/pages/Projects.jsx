import { useMemo, useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { FiSearch } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import projects, { PROJECT_CATEGORIES } from '../data/projects';
import useDebounce from '../hooks/useDebounce';
import { cn, matchesQuery } from '../scripts/utils';

export default function Projects() {
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(null);
  const debounced = useDebounce(query);

  const visible = useMemo(
    () =>
      projects.filter(
        (p) =>
          (category === 'all' || p.category === category) &&
          matchesQuery(debounced, p.title, p.description, p.kind, p.tech),
      ),
    [category, debounced],
  );

  const count = (key) => (key === 'all' ? projects.length : projects.filter((p) => p.category === key).length);

  return (
    <PageTransition>
      <Seo title="Projects" description="Selected website and UI/UX design projects by Pabitra Swain." />
      <div className="container-page space-y-10">
        <SectionTitle
          as="h1"
          label="Selected works"
          title="Engineered for impact"
          subtitle="Fusing intuitive UI design and website development with robust web architecture to build seamless digital experiences."
        />

        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div role="group" aria-label="Filter by category" className="flex flex-wrap gap-2">
            {PROJECT_CATEGORIES.map((c) => (
              <button
                key={c.key}
                type="button"
                aria-pressed={category === c.key}
                onClick={() => setCategory(c.key)}
                className={cn('chip', category === c.key && 'chip-active')}
              >
                {c.label} <span className="opacity-70">({count(c.key)})</span>
              </button>
            ))}
          </div>
          <label className="relative block md:w-72">
            <span className="sr-only">Search projects</span>
            <FiSearch className="muted pointer-events-none absolute left-4 top-1/2 -translate-y-1/2" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search projects or tools…"
              className="field !rounded-full pl-10"
            />
          </label>
        </div>

        <p className="sr-only" aria-live="polite">
          {visible.length} projects shown
        </p>

        {visible.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence>
              {visible.map((p, i) => (
                <ProjectCard key={p.id} project={p} index={i} onOpen={setActive} />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <p className="muted glass-card p-10 text-center text-sm">No projects match “{query}”. Try another word or category.</p>
        )}
      </div>

      <ProjectModal project={active} list={visible} onChange={setActive} onClose={() => setActive(null)} />
    </PageTransition>
  );
}
