import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { FiSearch } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import ArticleCard from '../components/ArticleCard';
import articles, { ARTICLE_CATEGORIES } from '../data/articles';
import useDebounce from '../hooks/useDebounce';
import { ARTICLES_PAGE_SIZE } from '../scripts/constants';
import { cn, matchesQuery } from '../scripts/utils';

// Every tag used across articles, in first-seen order.
const ALL_TAGS = [...new Set(articles.flatMap((a) => a.tags))];

export default function Articles() {
  // Tag and search live in the URL, so filtered views can be shared.
  const [params, setParams] = useSearchParams();
  const tag = params.get('tag') || 'All';
  const [query, setQuery] = useState(params.get('q') || '');
  const [limit, setLimit] = useState(ARTICLES_PAGE_SIZE);
  const debounced = useDebounce(query);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (value && value !== 'All') next.set(key, value);
    else next.delete(key);
    setParams(next, { replace: true });
    setLimit(ARTICLES_PAGE_SIZE);
  };

  const filtered = useMemo(
    () =>
      articles.filter(
        (a) =>
          (tag === 'All' || (tag === 'Top picks' ? a.featured : a.tags.includes(tag))) &&
          matchesQuery(debounced, a.title, a.excerpt, a.type, a.tags, a.bestFor),
      ),
    [tag, debounced],
  );
  const visible = filtered.slice(0, limit);

  return (
    <PageTransition>
      <Seo
        title="Articles"
        description={`${articles.length} short guides to frontend frameworks, CSS systems and build tools — overview, install, example code and when to choose each.`}
      />
      <div className="container-page space-y-10">
        <SectionTitle
          as="h1"
          label="Articles"
          title="Frontend framework guides"
          subtitle={`${articles.length} short, practical guides — overview, install command, example code and when to choose each.`}
        />

        <div className="glass-card space-y-4 p-5">
          <label className="relative block">
            <span className="sr-only">Search articles</span>
            <FiSearch className="muted pointer-events-none absolute left-4 top-1/2 -translate-y-1/2" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                updateParam('q', e.target.value);
              }}
              placeholder="Search e.g. react, css, bundler…"
              className="field !rounded-full pl-10"
            />
          </label>
          <div role="group" aria-label="Filter by tag" className="flex flex-wrap gap-2">
            {['All', 'Top picks', ...ALL_TAGS].map((t) => (
              <button
                key={t}
                type="button"
                aria-pressed={tag === t}
                onClick={() => updateParam('tag', t)}
                className={cn('chip', tag === t && 'chip-active')}
              >
                {t === 'Top picks' ? '★ Top picks' : t}
              </button>
            ))}
          </div>
        </div>

        <p className="muted text-sm" aria-live="polite">
          Showing {visible.length} of {filtered.length} article{filtered.length === 1 ? '' : 's'}
          {tag !== 'All' && ` in ${tag}`}
        </p>

        {filtered.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence>
              {visible.map((a, i) => (
                <ArticleCard key={a.slug} article={a} index={i % ARTICLES_PAGE_SIZE} />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <p className="muted glass-card p-10 text-center text-sm">No article matches your search.</p>
        )}

        {visible.length < filtered.length && (
          <div className="text-center">
            <button type="button" className="btn-ghost" onClick={() => setLimit((l) => l + ARTICLES_PAGE_SIZE)}>
              Load more articles
            </button>
          </div>
        )}

        <p className="muted text-center text-xs">
          Categories: {Object.values(ARTICLE_CATEGORIES).map((c) => c.label).join(' · ')}. Some entries are libraries, CSS frameworks or
          build tools rather than application frameworks.
        </p>
      </div>
    </PageTransition>
  );
}
