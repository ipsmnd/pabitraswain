import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowLeft } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';

export default function NotFound() {
  return (
    <PageTransition>
      <Seo title="Page not found" description="The page you are looking for does not exist." />
      <div className="container-page grid min-h-[60vh] place-items-center text-center">
        <div>
          <motion.p
            className="gradient-text font-display text-[7rem] font-black leading-none sm:text-[10rem]"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            aria-hidden="true"
          >
            404
          </motion.p>
          <h1 className="mt-2 text-2xl font-bold sm:text-3xl">This page drifted off into space</h1>
          <p className="muted mx-auto mt-3 max-w-md text-sm">The link may be broken, or the page may have moved. Let&apos;s get you back on track.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/" className="btn-primary">
              <FiArrowLeft aria-hidden="true" /> Back home
            </Link>
            <Link to="/projects" className="btn-ghost">
              See projects
            </Link>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
