import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { FiAlertCircle, FiCheckCircle, FiMail, FiMapPin, FiPhone, FiSend } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import SocialLinks from '../components/SocialLinks';
import Reveal from '../components/Reveal';
import { INITIAL_FORM, validateField, validateForm } from '../scripts/formValidation';
import { isEmailConfigured, sendContactMessage } from '../scripts/emailService';
import { SITE } from '../scripts/constants';
import { cn } from '../scripts/utils';

const FIELDS = [
  { name: 'name', label: 'Name', type: 'text', autoComplete: 'name', half: true },
  { name: 'email', label: 'Email', type: 'email', autoComplete: 'email', half: true },
  { name: 'subject', label: 'Subject', type: 'text' },
  { name: 'message', label: 'Message', textarea: true },
];

export default function Contact() {
  const [values, setValues] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | success | error

  const onChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    // Re-validate as they type once a field has been visited.
    if (touched[name]) setErrors((er) => ({ ...er, [name]: validateField(name, value) }));
  };

  const onBlur = (e) => {
    const { name, value } = e.target;
    setTouched((t) => ({ ...t, [name]: true }));
    setErrors((er) => ({ ...er, [name]: validateField(name, value) }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const found = validateForm(values);
    setErrors(found);
    setTouched({ name: true, email: true, subject: true, message: true });
    if (Object.keys(found).length) {
      document.getElementById(`field-${Object.keys(found)[0]}`)?.focus();
      return;
    }
    setStatus('sending');
    try {
      await sendContactMessage(values);
      setStatus('success');
      setValues(INITIAL_FORM);
      setTouched({});
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <PageTransition>
      <Seo title="Contact" description={`Get in touch with ${SITE.name} about a website, web app or UI/UX project.`} />
      <div className="container-page space-y-10">
        <SectionTitle
          as="h1"
          label="Contact"
          title="Let's work together"
          subtitle="Tell me about your project, timeline and budget. I usually reply within a day."
        />

        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <Reveal className="glass-card p-6 sm:p-8">
            <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
              {FIELDS.map((f) => {
                const err = touched[f.name] && errors[f.name];
                const props = {
                  id: `field-${f.name}`,
                  name: f.name,
                  value: values[f.name],
                  onChange,
                  onBlur,
                  required: true,
                  'aria-invalid': Boolean(err),
                  'aria-describedby': err ? `err-${f.name}` : undefined,
                  className: cn('field', err && 'field-error'),
                };
                return (
                  <div key={f.name} className={f.half ? '' : 'sm:col-span-2'}>
                    <label htmlFor={props.id} className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.1em]">
                      {f.label}
                    </label>
                    {f.textarea ? <textarea rows={5} {...props} /> : <input type={f.type} autoComplete={f.autoComplete} {...props} />}
                    {err && (
                      <p id={`err-${f.name}`} className="mt-1.5 flex items-center gap-1 text-xs text-rose-500">
                        <FiAlertCircle aria-hidden="true" /> {err}
                      </p>
                    )}
                  </div>
                );
              })}

              <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
                <button type="submit" className="btn-primary" disabled={status === 'sending'}>
                  {status === 'sending' ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true" />
                      Sending…
                    </>
                  ) : (
                    <>
                      Send message <FiSend aria-hidden="true" />
                    </>
                  )}
                </button>
                {!isEmailConfigured && <span className="muted text-xs">Opens your email app to send.</span>}
              </div>

              <div className="sm:col-span-2" aria-live="polite">
                <AnimatePresence>
                  {status === 'success' && (
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-600 dark:text-emerald-400"
                    >
                      <FiCheckCircle aria-hidden="true" />
                      {isEmailConfigured ? 'Thanks! Your message was sent — I’ll reply soon.' : 'Your email app should now be open with the message ready to send.'}
                    </motion.p>
                  )}
                  {status === 'error' && (
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-600 dark:text-rose-400"
                    >
                      <FiAlertCircle aria-hidden="true" />
                      Something went wrong. Please try again, or email me at {SITE.email}.
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </form>
          </Reveal>

          <Reveal delay={0.1} className="glass-card h-fit p-6 sm:p-8">
            <p className="section-label">Get in touch</p>
            <ul className="mt-5 space-y-4 text-sm">
              <li>
                <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 hover:text-primary-600 dark:hover:text-cyan-400">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-gradient text-white">
                    <FiMail aria-hidden="true" />
                  </span>
                  {SITE.email}
                </a>
              </li>
              <li>
                <a href={`tel:${SITE.phone.replace(/\s/g, '')}`} className="flex items-center gap-3 hover:text-primary-600 dark:hover:text-cyan-400">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-gradient text-white">
                    <FiPhone aria-hidden="true" />
                  </span>
                  {SITE.phone}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-gradient text-white">
                  <FiMapPin aria-hidden="true" />
                </span>
                {SITE.location}
              </li>
            </ul>
            <p className="section-label mt-8">Find me</p>
            <SocialLinks className="mt-3" />
          </Reveal>
        </div>
      </div>
    </PageTransition>
  );
}
