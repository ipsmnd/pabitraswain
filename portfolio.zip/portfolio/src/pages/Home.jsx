import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiArrowRight } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import Hero from '../components/Hero';
import SectionTitle from '../components/SectionTitle';
import Services from '../components/Services';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import ArticleCard from '../components/ArticleCard';
import Testimonials from '../components/Testimonials';
import Reveal from '../components/Reveal';
import projects from '../data/projects';
import articles from '../data/articles';
import skills from '../data/skills';
import { SITE } from '../scripts/constants';

const featuredProjects = projects.filter((p) => p.featured).slice(0, 3);
const featuredArticles = articles.filter((a) => a.featured).slice(0, 3);
const marqueeItems = skills.filter((s) => s.level).map((s) => s.name);

/** Landing page: hero, services, featured work, articles, testimonials, CTA. */
export default function Home() {
  const [active, setActive] = useState(null);

  return (
    <PageTransition>
      <Seo description={`${SITE.name} — ${SITE.title}. ${SITE.intro}`} />
      <div className="container-page space-y-24">
        <Hero />

        {/* Skills marquee */}
        <div className="marquee-mask -mt-14 overflow-hidden" aria-hidden="true">
          <div className="flex w-max gap-3 animate-marquee">
            {[...marqueeItems, ...marqueeItems].map((s, i) => (
              <span key={i} className="tag gap-2 whitespace-nowrap px-4 py-2">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-500" />
                {s}
              </span>
            ))}
          </div>
        </div>

        <section aria-labelledby="services-title" className="space-y-8">
          <SectionTitle label="What I do" title={<span id="services-title">Design &amp; development, end to end</span>} />
          <Services />
        </section>

        <section className="space-y-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <SectionTitle
              label="Selected work"
              title="Engineered for impact"
              subtitle="Fusing intuitive UI design and website development with robust web architecture."
            />
            <Link to="/projects" className="btn-ghost">
              All projects <FiArrowRight aria-hidden="true" />
            </Link>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featuredProjects.map((p, i) => (
              <ProjectCard key={p.id} project={p} index={i} onOpen={setActive} />
            ))}
          </div>
        </section>

        <section className="space-y-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <SectionTitle
              label="Articles"
              title="Frontend framework guides"
              subtitle="Short, practical guides to frameworks, CSS systems and build tools."
            />
            <Link to="/articles" className="btn-ghost">
              All articles <FiArrowRight aria-hidden="true" />
            </Link>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featuredArticles.map((a, i) => (
              <ArticleCard key={a.slug} article={a} index={i} />
            ))}
          </div>
        </section>

        <section className="space-y-8">
          <SectionTitle label="Testimonials" title="What people say" align="center" />
          <Testimonials />
        </section>

        <Reveal className="glass-card flex flex-col items-center gap-5 p-10 text-center sm:p-14">
          <p className="section-label">Have a project in mind?</p>
          <h2 className="max-w-xl text-3xl font-extrabold sm:text-4xl">Let&apos;s build something people enjoy using.</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/contact" className="btn-primary">
              Start a conversation <FiArrowRight aria-hidden="true" />
            </Link>
            <Link to="/about" className="btn-ghost">
              More about me
            </Link>
          </div>
        </Reveal>
      </div>

      <ProjectModal project={active} list={featuredProjects} onChange={setActive} onClose={() => setActive(null)} />
    </PageTransition>
  );
}
