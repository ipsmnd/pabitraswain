import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion, useScroll, useSpring } from 'framer-motion';
import { FiArrowLeft, FiArrowRight, FiCalendar, FiClock, FiCopy, FiDownload, FiExternalLink, FiFileText } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import Markdown from '../components/Markdown';
import { ArticleCover } from '../components/ArticleCard';
import NotFound from './NotFound';
import articles, { ARTICLE_CATEGORIES } from '../data/articles';
import { cn, copyToClipboard, downloadText, formatDate, readingTime, slugify } from '../scripts/utils';

/** "## Heading" lines -> table of contents entries. */
const getToc = (md) =>
  md
    .split('\n')
    .filter((l) => l.startsWith('## '))
    .map((l) => {
      const text = l.slice(3).trim();
      return { id: `s-${slugify(text)}`, text };
    });

export default function ArticleDetail() {
  const { slug } = useParams();
  const index = articles.findIndex((a) => a.slug === slug);
  const article = articles[index];
  const [showSource, setShowSource] = useState(false);
  const [toast, setToast] = useState('');
  const [activeId, setActiveId] = useState('');

  // Reading progress bar
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });

  const toc = useMemo(() => (article ? getToc(article.content) : []), [article]);

  // Highlight the TOC entry for the section on screen.
  useEffect(() => {
    if (!toc.length || showSource) return undefined;
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActiveId(e.target.id)),
      { rootMargin: '-100px 0px -65% 0px' },
    );
    toc.forEach((t) => {
      const el = document.getElementById(t.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [toc, showSource]);

  useEffect(() => setShowSource(false), [slug]);

  if (!article) return <NotFound />;

  const prev = articles[(index - 1 + articles.length) % articles.length];
  const next = articles[(index + 1) % articles.length];
  const related = articles.filter((a) => a.slug !== slug && a.category === article.category).slice(0, 5);
  const cat = ARTICLE_CATEGORIES[article.category];

  const flash = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 1800);
  };

  return (
    <PageTransition>
      <Seo title={`${article.title} guide`} description={article.excerpt} type="article" />
      <motion.div className="fixed inset-x-0 top-0 z-50 h-[3px] origin-left bg-gradient-to-r from-primary-500 via-accent-500 to-cyan-400" style={{ scaleX: progress }} />

      <div className="container-page grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_270px]">
        <article className="glass-card overflow-hidden">
          <ArticleCover article={article} className="h-40 sm:h-48" />
          <div className="p-6 sm:p-10">
            <nav aria-label="Breadcrumb" className="muted text-xs">
              <Link to="/articles" className="hover:text-primary-600 dark:hover:text-cyan-400">
                Articles
              </Link>{' '}
              /{' '}
              <Link to={`/articles?tag=${encodeURIComponent(cat.label)}`} className="hover:text-primary-600 dark:hover:text-cyan-400">
                {cat.label}
              </Link>{' '}
              / <span aria-current="page">{article.title}</span>
            </nav>

            <h1 className="gradient-text mt-3 text-4xl font-black leading-tight sm:text-5xl">{article.title}</h1>
            <p className="muted mt-3 text-base">{article.excerpt}</p>

            <div className="muted mt-4 flex flex-wrap items-center gap-2 text-xs">
              <span className="tag gap-1">
                <FiCalendar aria-hidden="true" /> <time dateTime={article.date}>{formatDate(article.date)}</time>
              </span>
              <span className="tag gap-1">
                <FiClock aria-hidden="true" /> {readingTime(article.content)} min read
              </span>
              <span className="tag">{article.type}</span>
              {article.tags.map((t) => (
                <Link key={t} to={`/articles?tag=${encodeURIComponent(t)}`} className="tag hover:border-primary-400">
                  #{t}
                </Link>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              <button type="button" className="btn-ghost !px-4 !py-2 text-xs" onClick={() => setShowSource((s) => !s)} aria-pressed={showSource}>
                <FiFileText aria-hidden="true" /> {showSource ? 'View article' : 'View .md source'}
              </button>
              <button
                type="button"
                className="btn-ghost !px-4 !py-2 text-xs"
                onClick={async () => flash((await copyToClipboard(article.content)) ? 'Copied to clipboard ✓' : 'Copy failed')}
              >
                <FiCopy aria-hidden="true" /> Copy .md
              </button>
              <button
                type="button"
                className="btn-ghost !px-4 !py-2 text-xs"
                onClick={() => {
                  downloadText(`${article.slug}.md`, article.content);
                  flash(`Downloading ${article.slug}.md`);
                }}
              >
                <FiDownload aria-hidden="true" /> Download .md
              </button>
              <a href={article.officialUrl} target="_blank" rel="noopener noreferrer" className="btn-primary !px-4 !py-2 text-xs">
                Official docs <FiExternalLink aria-hidden="true" />
              </a>
            </div>

            <div className="mt-8">
              {showSource ? (
                <pre className="overflow-x-auto rounded-2xl border border-white/10 bg-[#0a0e24] p-5 text-[13px] leading-relaxed text-[#cdd3f5]">
                  <code>{article.content}</code>
                </pre>
              ) : (
                <div className="prose prose-slate max-w-none prose-headings:font-display prose-a:text-primary-600 prose-a:no-underline hover:prose-a:underline prose-code:rounded-md prose-code:bg-night-800/10 prose-code:px-1.5 prose-code:py-0.5 prose-code:before:content-none prose-code:after:content-none prose-blockquote:border-primary-500 prose-th:text-left dark:prose-invert dark:prose-a:text-cyan-400 dark:prose-code:bg-white/10">
                  <Markdown content={article.content} />
                </div>
              )}
            </div>

            <nav aria-label="More articles" className="mt-10 grid gap-3 sm:grid-cols-2">
              <Link to={`/articles/${prev.slug}`} className="glass-card glass-card-hover block p-4">
                <span className="muted inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.1em]">
                  <FiArrowLeft aria-hidden="true" /> Previous
                </span>
                <span className="block font-semibold">{prev.title}</span>
              </Link>
              <Link to={`/articles/${next.slug}`} className="glass-card glass-card-hover block p-4 sm:text-right">
                <span className="muted inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.1em]">
                  Next <FiArrowRight aria-hidden="true" />
                </span>
                <span className="block font-semibold">{next.title}</span>
              </Link>
            </nav>
          </div>
        </article>

        <aside className="space-y-6 lg:sticky lg:top-28">
          {!showSource && toc.length > 0 && (
            <nav aria-label="On this page" className="glass-card p-5">
              <p className="section-label">On this page</p>
              <ul className="mt-3 space-y-0.5">
                {toc.map((t) => (
                  <li key={t.id}>
                    <a
                      href={`#${t.id}`}
                      onClick={(e) => {
                        e.preventDefault();
                        document.getElementById(t.id)?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className={cn(
                        'block rounded-lg border-l-2 px-3 py-1.5 text-[13px] transition',
                        activeId === t.id
                          ? 'border-cyan-500 bg-primary-500/10 font-semibold'
                          : 'muted border-transparent hover:bg-primary-500/5',
                      )}
                    >
                      {t.text}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          )}
          {related.length > 0 && (
            <nav aria-label="Related articles" className="glass-card p-5">
              <p className="section-label">Related</p>
              <ul className="mt-3 space-y-2">
                {related.map((r) => (
                  <li key={r.slug}>
                    <Link
                      to={`/articles/${r.slug}`}
                      className="block rounded-xl border border-night-800/10 px-3 py-2 text-[13px] font-semibold transition hover:translate-x-1 hover:border-primary-400 dark:border-white/10"
                    >
                      {r.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          )}
        </aside>
      </div>

      {/* Toast */}
      <div
        role="status"
        aria-live="polite"
        className={cn(
          'fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-2xl bg-brand-gradient px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition-all duration-300',
          toast ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-6 opacity-0',
        )}
      >
        {toast}
      </div>
    </PageTransition>
  );
}
