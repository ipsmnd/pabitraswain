import { FiDownload, FiMapPin, FiMail } from 'react-icons/fi';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import Reveal from '../components/Reveal';
import Counter from '../components/Counter';
import Services from '../components/Services';
import { INTERESTS, SITE, STATS } from '../scripts/constants';
import { DESIGN_STYLES } from '../data/skills';

export default function About() {
  return (
    <PageTransition>
      <Seo title="About" description={`About ${SITE.name}: ${SITE.bio[0]}`} />
      <div className="container-page space-y-16">
        <div className="grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          {/* Photo */}
          <Reveal className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-4 -z-10 rounded-[2.5rem] bg-brand-gradient opacity-40 blur-2xl" aria-hidden="true" />
            <div className="glass-card overflow-hidden !rounded-[2rem]">
              <img
                src={SITE.avatar}
                alt={`Portrait of ${SITE.name}`}
                width="700"
                height="560"
                loading="lazy"
                className="aspect-[4/5] w-full object-cover object-[60%_20%]"
              />
            </div>
            <span className="absolute -bottom-4 left-6 grid h-14 w-14 place-items-center rounded-full border-2 border-gold-500 bg-night-900 font-extrabold text-gold-300 motion-safe:animate-float-fast">
              {SITE.shortName}
            </span>
          </Reveal>

          {/* Bio */}
          <div>
            <SectionTitle as="h1" label="About me" title="Creative developer & UI/UX designer" />
            <Reveal delay={0.1} className="muted mt-5 space-y-4 text-[15px] leading-relaxed">
              {SITE.bio.map((p) => (
                <p key={p.slice(0, 20)}>{p}</p>
              ))}
            </Reveal>
            <Reveal delay={0.15} className="muted mt-5 flex flex-wrap gap-x-6 gap-y-2 text-sm">
              <span className="inline-flex items-center gap-2">
                <FiMapPin aria-hidden="true" /> {SITE.location}
              </span>
              <a href={`mailto:${SITE.email}`} className="inline-flex items-center gap-2 hover:text-primary-600 dark:hover:text-cyan-400">
                <FiMail aria-hidden="true" /> {SITE.email}
              </a>
            </Reveal>

            <Reveal delay={0.2} as="dl" className="mt-8 grid grid-cols-3 gap-4">
              {STATS.map((s) => (
                <div key={s.label} className="glass-card flex flex-col p-4 text-center">
                  <dt className="muted order-2 text-[10px] font-semibold uppercase tracking-wider">{s.label}</dt>
                  <dd className="font-display text-2xl font-extrabold text-primary-600 dark:text-primary-400 sm:text-3xl">
                    <Counter value={s.value} suffix={s.suffix} />
                  </dd>
                </div>
              ))}
            </Reveal>

            <Reveal delay={0.25} className="mt-8">
              <a href={SITE.resumeUrl} download className="btn-primary">
                <FiDownload aria-hidden="true" /> Download resume
              </a>
            </Reveal>
          </div>
        </div>

        <section className="grid gap-6 md:grid-cols-2">
          <Reveal className="glass-card p-7">
            <p className="section-label">Interests</p>
            <h2 className="mt-2 text-xl font-bold">Outside client work</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {INTERESTS.map((i) => (
                <li key={i} className="tag">
                  {i}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={0.1} className="glass-card p-7">
            <p className="section-label">Design styles</p>
            <h2 className="mt-2 text-xl font-bold">Visual languages I work in</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {DESIGN_STYLES.map((s) => (
                <li key={s} className="tag transition hover:-translate-y-1 hover:bg-primary-500/20">
                  {s}
                </li>
              ))}
            </ul>
          </Reveal>
        </section>

        <section className="space-y-8">
          <SectionTitle label="Services" title="How I can help" />
          <Services />
        </section>
      </div>
    </PageTransition>
  );
}
