import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import SkillBar from '../components/SkillBar';
import Reveal from '../components/Reveal';
import skills, { DESIGN_STYLES, SKILL_CATEGORIES } from '../data/skills';
import { cn } from '../scripts/utils';

export default function Skills() {
  const [active, setActive] = useState('all');

  const visible = useMemo(() => (active === 'all' ? skills : skills.filter((s) => s.category === active)), [active]);

  return (
    <PageTransition>
      <Seo title="Skills" description="Frontend, CMS, design tools and soft skills — with proficiency levels." />
      <div className="container-page space-y-10">
        <SectionTitle
          as="h1"
          label="Skills"
          title="Design & development toolkit"
          subtitle="The tools I reach for every day, and how comfortable I am with each."
        />

        {/* Filter tabs */}
        <div role="tablist" aria-label="Skill categories" className="flex flex-wrap gap-2">
          {SKILL_CATEGORIES.map((c) => (
            <button
              key={c.key}
              type="button"
              role="tab"
              aria-selected={active === c.key}
              aria-controls="skills-panel"
              onClick={() => setActive(c.key)}
              className={cn('chip', active === c.key && 'chip-active')}
            >
              {c.label}
            </button>
          ))}
        </div>

        <motion.div id="skills-panel" role="tabpanel" layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence>
            {visible.map((s, i) => (
              <SkillBar key={s.name} skill={s} index={i} />
            ))}
          </AnimatePresence>
        </motion.div>

        <Reveal className="glass-card p-7">
          <p className="section-label">Design styles</p>
          <h2 className="mt-2 text-xl font-bold">UI trends I design with</h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {DESIGN_STYLES.map((s) => (
              <li key={s} className="tag transition hover:-translate-y-1 hover:bg-primary-500/20">
                {s}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </PageTransition>
  );
}
