import { useState } from 'react';
import Seo from '../components/Seo';
import PageTransition from '../components/PageTransition';
import SectionTitle from '../components/SectionTitle';
import Timeline from '../components/Timeline';
import experience from '../data/experience';
import { cn } from '../scripts/utils';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'work', label: 'Work' },
  { key: 'education', label: 'Education' },
];

export default function Experience() {
  const [filter, setFilter] = useState('all');
  const items = filter === 'all' ? experience : experience.filter((e) => e.type === filter);

  return (
    <PageTransition>
      <Seo title="Experience" description="Freelance work history and education of Pabitra Swain." />
      <div className="container-page space-y-10">
        <SectionTitle
          as="h1"
          label="Career"
          title="Experience & education"
          subtitle="Freelance projects for businesses across Odisha and beyond, and the studies behind them."
          align="center"
        />
        <div role="group" aria-label="Filter timeline" className="flex justify-center gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              type="button"
              aria-pressed={filter === f.key}
              onClick={() => setFilter(f.key)}
              className={cn('chip', filter === f.key && 'chip-active')}
            >
              {f.label}
            </button>
          ))}
        </div>
        {/* key resets the entrance animations when the filter changes */}
        <Timeline key={filter} items={items} />
      </div>
    </PageTransition>
  );
}
