import typography from '@tailwindcss/typography';

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  // Dark mode is driven by a `dark` class on <html> (see src/hooks/useTheme.js)
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Bold accent — electric blue
        primary: {
          50: '#eef5ff',
          100: '#d9e8ff',
          200: '#bcd6ff',
          300: '#8cb8ff',
          400: '#5b8cff',
          500: '#2f8bff',
          600: '#1f6cf0',
          700: '#1a56d6',
          800: '#1c47ad',
          900: '#1d3f86',
          950: '#152852',
        },
        // Secondary accent — violet
        accent: {
          300: '#b9a7ff',
          400: '#9b84ff',
          500: '#7c5cff',
          600: '#6a42f0',
          700: '#5a2fd1',
        },
        cyan: { 400: '#22d3ee', 500: '#1ec8e8' },
        gold: { 300: '#f0d78c', 500: '#c9a24a' },
        // Dark-mode surfaces (deep navy)
        night: {
          700: '#1c2250',
          800: '#141833',
          850: '#0f1329',
          900: '#0b1026',
          950: '#070b1f',
        },
        // Light-mode surfaces
        mist: {
          50: '#f7f8fe',
          100: '#eef1fb',
          200: '#e2e7f7',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Poppins', 'Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 10px 40px -15px rgba(20, 30, 80, 0.25)',
        glow: '0 20px 50px -20px rgba(60, 90, 255, 0.45)',
        'glow-sm': '0 8px 24px -8px #5b6cff',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(90deg, #2f8bff, #7c5cff)',
        'name-gradient': 'linear-gradient(90deg, #5b6cff, #22d3ee, #9b6bff, #5b6cff)',
      },
      keyframes: {
        shine: { to: { backgroundPosition: '300% 0' } },
        marquee: { to: { transform: 'translateX(-50%)' } },
        blink: { '50%': { opacity: '0' } },
        float: { '50%': { transform: 'translateY(-8px)' } },
        pulseDot: { '70%': { boxShadow: '0 0 0 9px transparent' } },
      },
      animation: {
        shine: 'shine 5s linear infinite',
        marquee: 'marquee 32s linear infinite',
        blink: 'blink 1s steps(1) infinite',
        float: 'float 6s ease-in-out infinite',
        'float-fast': 'float 4s ease-in-out infinite',
        'pulse-dot': 'pulseDot 1.8s infinite',
        'spin-slow': 'spin 8s linear infinite',
      },
    },
  },
  plugins: [typography],
};
